import os
from pathlib import Path
from urllib.parse import urlsplit
from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent
LOCAL = os.environ.get('CHEMEX_LOCAL') == '1'
DEBUG = False
SECRET_KEY = os.environ.get('SECRET_KEY', 'local-development-only-not-for-production' if LOCAL else '')
if not LOCAL and (len(SECRET_KEY) < 50 or SECRET_KEY.startswith('REPLACE')):
    raise ImproperlyConfigured('Set a random SECRET_KEY of at least 50 characters.')
BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8000' if LOCAL else '')
parsed = urlsplit(BASE_URL)
if not parsed.hostname or parsed.path or parsed.query or parsed.fragment or parsed.username or parsed.password:
    raise ImproperlyConfigured('BASE_URL must be an origin without a trailing slash.')
if parsed.scheme != 'https' and not (LOCAL and parsed.hostname in ('localhost', '127.0.0.1', 'testserver')):
    raise ImproperlyConfigured('HTTPS required outside local development.')
ALLOWED_HOSTS = [parsed.hostname]
CSRF_TRUSTED_ORIGINS = [BASE_URL]
CSRF_HEADER_NAME = 'HTTP_X_CSRF_TOKEN'
CSRF_FAILURE_VIEW = 'marketplace.views.csrf_failure'
CSRF_USE_SESSIONS = True
SESSION_COOKIE_NAME = 'CHEMEXPYSESSION'
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SECURE = not LOCAL
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_AGE = 28800
SESSION_SAVE_EVERY_REQUEST = True
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SECURE_SSL_REDIRECT = not LOCAL
SECURE_HSTS_SECONDS = 31536000 if not LOCAL else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = 'same-origin'
X_FRAME_OPTIONS = 'DENY'
# Enable only behind the bundled private reverse proxy. Gunicorn has no published port.
if os.environ.get('TRUST_PROXY') == '1':
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
INSTALLED_APPS = ['django.contrib.contenttypes', 'django.contrib.auth', 'django.contrib.sessions', 'marketplace']
MIDDLEWARE = ['django.middleware.security.SecurityMiddleware',
              'django.contrib.sessions.middleware.SessionMiddleware',
              'django.middleware.csrf.CsrfViewMiddleware',
              'django.middleware.clickjacking.XFrameOptionsMiddleware',
              'marketplace.views.ResponseHeaders']
ROOT_URLCONF = 'config.urls'
WSGI_APPLICATION = 'config.wsgi.application'
TEMPLATES = [{'BACKEND': 'django.template.backends.django.DjangoTemplates', 'APP_DIRS': True}]
if LOCAL:
    DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': BASE_DIR / 'local.sqlite3', 'OPTIONS': {'timeout': 20}}}
else:
    DATABASES = {'default': {'ENGINE': 'django.db.backends.postgresql', 'NAME': os.environ.get('POSTGRES_DB', 'chemex'),
        'USER': os.environ.get('POSTGRES_USER', 'chemex'), 'PASSWORD': os.environ['POSTGRES_PASSWORD'],
        'HOST': os.environ.get('POSTGRES_HOST', 'db'), 'PORT': os.environ.get('POSTGRES_PORT', '5432'),
        'CONN_MAX_AGE': 60}}
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
USE_TZ = True
TIME_ZONE = 'UTC'
LANGUAGE_CODE = 'ru'
DATA_UPLOAD_MAX_MEMORY_SIZE = 9 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 1024 * 1024
DATA_UPLOAD_MAX_NUMBER_FILES = 1
DOCUMENT_ROOT = Path(os.environ.get('DOCUMENT_ROOT', str(BASE_DIR / 'data' / 'documents')))
REGISTRATION_ENABLED = os.environ.get('REGISTRATION_ENABLED', '1') == '1'
