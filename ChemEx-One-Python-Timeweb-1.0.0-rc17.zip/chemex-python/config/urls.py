from django.urls import path, re_path
from marketplace import views

urlpatterns = [path('', views.index), path('api/<str:name>', views.api),
    path('login', views.auth_page, {'mode': 'login'}), path('register', views.auth_page, {'mode': 'register'}),
    path('logout', views.auth_page, {'mode': 'logout'}),
    path('signin-with-chatgpt', views.auth_page, {'mode': 'login'}),
    path('signout-with-chatgpt', views.auth_page, {'mode': 'logout'}),
    re_path(r'^(?P<filename>[\w-]+\.(?:js|css|svg))$', views.asset)]
