import json
import os
import urllib.request
from urllib.parse import urlsplit

request=urllib.request.Request('http://127.0.0.1:8000/api/health',headers={
    'Host':urlsplit(os.environ['BASE_URL']).netloc,'X-Forwarded-Proto':'https'})
with urllib.request.urlopen(request,timeout=5) as response:
    if not json.load(response).get('ok'): raise SystemExit(1)
