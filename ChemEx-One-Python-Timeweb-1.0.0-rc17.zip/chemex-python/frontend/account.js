let account=null;
window.accountReady=false;
async function api(url, options={}){
 const response=await fetch(url,{method:options.method||'GET',headers:{'Content-Type':'application/json'},credentials:'same-origin',...(options.body?{body:JSON.stringify(options.body)}:{})});
 let data;try{data=await response.json()}catch{throw new Error('Не удалось получить ответ сервера. Обновите страницу.');}
 if(!response.ok)throw new Error(data.error||'Сервис временно недоступен.');return data;
}
const roleNames={buyer:'Покупатель',supplier:'Поставщик',both:'Покупатель и поставщик'};
const legacyRenderOther=renderOther;
renderOther=function(view){
 legacyRenderOther(view);
 if(view==='company')renderCompany();
 if(view==='orders')renderRequests();
 if(view==='analytics'){
  $('#other-content').innerHTML=`<div class="stats-grid"><div class="stat"><span class="stat-icon cyan">✉</span><div><small>Ваши запросы</small><strong>${requests.length}</strong><span>сохранены в аккаунте</span></div></div><div class="stat"><span class="stat-icon purple">♡</span><div><small>Избранное</small><strong>${saved.size}</strong><span>сохранено в аккаунте</span></div></div></div><div class="dashboard-panel"><b>Ваше рабочее пространство</b><p>Здесь отображаются реальные данные вашего аккаунта. В каталоге отмечены демонстрационные карточки. Переписка доступна участникам отправленных запросов.</p></div>`;
 }
};
function updateAccount(){
 const adminNav=$('[data-view=admin]');if(adminNav)adminNav.hidden=!account.isSuperAdmin;
 const p=account.profile;const name=p?.contactName||account.user.displayName;
 $('#account-name').textContent=name;$('#account-role').textContent=p?roleNames[p.role]+' · '+p.companyName:'Профиль компании не заполнен';
 const initials=name.split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase();$('#account-initials').textContent=initials;$('#top-initials').textContent=initials;
 $('#account-state').textContent=p?p.companyName:'Мой аккаунт';
 $('#account-notice').innerHTML=p?'✓ Аккаунт подключён · Профиль, избранное и запросы сохраняются на сервере. <span>Карточки «Демо» — учебные примеры.</span>':'Добро пожаловать в ChemEx.One. <button id="complete-profile">Заполните профиль компании →</button>';
 $('#complete-profile')?.addEventListener('click',()=>renderOther('company'));
}
function renderCompany(){
 const content=$('#other-content');if(!account){content.innerHTML='<div class="dashboard-panel">Аккаунт загружается. Если загрузка не завершится, обновите страницу.</div>';return;}
 const p=account.profile||{};
 content.innerHTML=`${account.publicationRestriction?`<div class="compare-warning"><b>Публикации компании приостановлены</b><p>${esc(account.publicationRestriction.reason)}</p><small>Профиль и история сделок сохранены.</small></div>`:''}<div class="profile-layout"><section class="dashboard-panel"><div class="panel-title">${account.profile?'Профиль компании':'Создайте профиль компании'}</div><p class="profile-muted">Укажите данные организации и вашу роль на площадке.</p><form id="company-form"><div class="profile-fields">${[['companyName','Название компании',160],['country','Страна регистрации',100],['registrationNumber','Регистрационный номер / ИНН',100],['contactName','Контактное лицо',120],['contactEmail','Рабочий email',254],['website','Сайт компании',300]].map(([key,label,max])=>`<label class="profile-label">${label}<input name="${key}" type="${key==='contactEmail'?'email':key==='website'?'url':'text'}" maxlength="${max}" ${['registrationNumber','website'].includes(key)?'':'required minlength="2"'} ${key==='website'?'placeholder="https://example.com"':''} value="${esc(p[key]||(key==='contactEmail'?account.user.email:key==='contactName'?account.user.displayName:''))}"></label>`).join('')}</div><fieldset class="role-options"><legend>Как вы будете использовать ChemEx.One?</legend>${Object.entries(roleNames).map(([value,label])=>`<label><input type="radio" name="role" value="${value}" ${(p.role||'buyer')===value?'checked':''}><span>${label}</span></label>`).join('')}</fieldset><label class="profile-label">О компании<textarea name="description" rows="4" maxlength="2000" placeholder="Направления деятельности, продукция, рынки">${esc(p.description||'')}</textarea></label><div id="profile-error" role="alert" class="profile-error"></div><div class="profile-footer"><button class="primary" type="submit">Сохранить профиль</button><span id="profile-saved">${p.updatedAt?'Обновлено '+esc(new Date(p.updatedAt).toLocaleString('ru-RU')):''}</span></div></form></section><aside><div class="company-card"><div class="supplier-emblem">${esc((p.companyName||'CO').slice(0,2).toUpperCase())}</div><h3>${esc(p.companyName||'Ваша компания')}</h3><p>${esc(p.country||'Страна не указана')}</p><span class="status">Статус проверки — в разделе «Проверка компании»</span><p>Подтверждение расчётного счёта выполняется после сверки платежа администратором. Изменение юридических реквизитов требует новой проверки.</p></div><div class="company-card" style="margin-top:18px"><h3>Ваш аккаунт</h3><p>${esc(account.user.email)}</p><p>Вход по email и паролю. При публикации предложения название компании и страна отображаются в каталоге. Контактные и регистрационные данные доступны вам и суперадминистратору для модерации.</p><a href="/logout" target="_top">Выйти из аккаунта ↗</a></div></aside></div>`;
 $('#company-form').addEventListener('submit',async e=>{e.preventDefault();const button=e.target.querySelector('button[type="submit"]');button.disabled=true;button.textContent='Сохраняем…';$('#profile-error').textContent='';try{const result=await api('/api/profile',{method:'PUT',body:Object.fromEntries(new FormData(e.target))});account.profile=result.profile;updateAccount();renderCompany();toast('Профиль компании сохранён.');}catch(err){$('#profile-error').textContent=err.message;button.disabled=false;button.textContent='Сохранить профиль';}});
}
function renderRequests(){
 $('#other-content').innerHTML=`<div class="dashboard-panel"><div class="panel-title">Мои запросы</div><p class="profile-muted">Личные черновики сохранены на сервере. Поставщикам они пока не отправляются.</p>${requests.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Товар</th><th>Количество</th><th>Страна</th><th>Дата</th><th>Статус</th><th></th></tr></thead><tbody>${requests.map(r=>`<tr><td><b>${esc(r.product)}</b><br><small>CAS ${esc(r.cas)}</small>${r.message?`<details><summary>Требования</summary><p>${esc(r.message)}</p></details>`:''}</td><td>${esc(r.quantity)} ${esc(r.unit)}</td><td>${esc(r.destination)}</td><td>${esc(new Date(r.createdAt).toLocaleDateString('ru-RU'))}</td><td><span class="status">Черновик</span></td><td><button class="delete-request" data-id="${esc(r.id)}" aria-label="Удалить черновик">Удалить</button></td></tr>`).join('')}</tbody></table></div>`:'<p>Создайте запрос из карточки товара в каталоге.</p>'}<button class="primary" id="requests-catalog">Перейти в каталог →</button></div>`;
 $('#requests-catalog').onclick=()=>renderOther('market');
 $$('.delete-request').forEach(b=>b.onclick=async()=>{if(!confirm('Удалить этот черновик запроса?'))return;b.disabled=true;try{await api('/api/requests',{method:'DELETE',body:{id:b.dataset.id}});requests=requests.filter(r=>r.id!==b.dataset.id);$('#request-count').textContent=requests.length;renderRequests();toast('Черновик удалён.');}catch(e){toast(e.message);b.disabled=false;}});
}
const legacyOpenRfq=openRfq;
openRfq=function(id){if(!window.accountReady){toast('Дождитесь подключения аккаунта.');return;}if(!account.profile){renderOther('company');toast('Сначала заполните профиль компании.');return;}if(account.profile.role==='supplier'){renderOther('company');toast('Для закупок выберите обе роли в профиле.');return;}legacyOpenRfq(id);$('#rfq-email').value=account.profile.contactEmail;};
async function connectAccount(){
 try{const [a,f,r]=await Promise.all([api('/api/profile'),api('/api/favorites'),api('/api/requests')]);account=a;saved=new Set(f.favorites);requests=r.requests;window.accountReady=true;updateAccount();$('#request-count').textContent=requests.length;renderProducts();if(!account.profile)renderOther('company');}
 catch(e){$('#account-state').textContent='Гость';$('#account-name').textContent='Гость';$('#account-role').textContent='Войдите для работы с компанией';$('#request-count').textContent='0';$('#account-notice').innerHTML=esc(e.message)+' <a href="/login">Войти</a> · <a href="/register">Регистрация</a>';}
}
connectAccount();
