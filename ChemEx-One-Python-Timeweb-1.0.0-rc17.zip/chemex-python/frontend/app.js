function documentLinks(documents){return (documents||[]).length?documents.map(d=>`<div class="product-document"><a class="document-link" href="${esc(d.url)}" target="_blank" rel="noopener noreferrer">${esc(d.type)} · ${esc(d.language)}${d.version?' · Редакция '+esc(d.version):''} ↗</a><small>${d.date?'Дата редакции: '+esc(d.date):'Дата редакции не указана'}${d.batch?' · Партия '+esc(d.batch):''}</small>${d.sourceName?`<small>Источник: ${esc(d.sourceName)}</small>`:''}</div>`).join(''):'<small>Документы не предоставлены.</small>';}

const products = [
 {id:1,name:"Ацетон",formula:"C₃H₆O",cas:"67-64-1",category:"Растворители",purity:99.9,price:1.42,unit:"кг",moq:"200 кг",region:"Европа",supplier:"NordChem GmbH",country:"Германия",initials:"NC",verified:true,visual:"",shape:"⚗️",tone:"blue-tone",badge:"В наличии",lead:"2–4 недели"},
 {id:2,name:"Лимонная кислота",formula:"C₆H₈O₇",cas:"77-92-9",category:"Кислоты",purity:99.8,price:1.85,unit:"кг",moq:"500 кг",region:"Азия",supplier:"Oriental Materials Co.",country:"Китай",initials:"OM",verified:true,shape:"◈",tone:"violet-tone",badge:"Популярное",lead:"3–5 недель"},
 {id:3,name:"Гидроксид натрия",formula:"NaOH",cas:"1310-73-2",category:"Неорганические вещества",purity:99,price:0.78,unit:"кг",moq:"1 т",region:"Европа",supplier:"Baltic Industrial Supply",country:"Польша",initials:"BI",verified:true,shape:"❄",tone:"green-tone",badge:"В наличии",lead:"1–2 недели"},
 {id:4,name:"Этанол",formula:"C₂H₆O",cas:"64-17-5",category:"Растворители",purity:99.9,price:1.96,unit:"л",moq:"200 л",region:"Северная Америка",supplier:"Meridian Specialty Chemicals",country:"США",initials:"MS",verified:false,shape:"◉",tone:"amber-tone",badge:"Новое",lead:"По запросу"},
 {id:5,name:"Диоксид титана",formula:"TiO₂",cas:"13463-67-7",category:"Неорганические вещества",purity:99,price:2.45,unit:"кг",moq:"1 т",region:"Азия",supplier:"Pacific Pigments Ltd.",country:"Южная Корея",initials:"PP",verified:true,shape:"✧",tone:"rose-tone",badge:"В наличии",lead:"2–3 недели"},
 {id:6,name:"Полиэтилен низкого давления",formula:"(C₂H₄)n",cas:"9002-88-4",category:"Полимеры",purity:99,price:1.32,unit:"кг",moq:"5 т",region:"Ближний Восток",supplier:"Gulf Polymer Trading",country:"ОАЭ",initials:"GP",verified:true,shape:"⬡",tone:"blue-tone",badge:"Оптовая цена",lead:"3–6 недель"},
 {id:7,name:"Серная кислота",formula:"H₂SO₄",cas:"7664-93-9",category:"Кислоты",purity:98,price:0.63,unit:"кг",moq:"1 т",region:"Европа",supplier:"EuroAcid Solutions",country:"Чехия",initials:"EA",verified:true,shape:"◉",tone:"amber-tone",badge:"В наличии",lead:"1–3 недели"},
 {id:8,name:"Глицерин фарм. качества",formula:"C₃H₈O₃",cas:"56-81-5",category:"Специальная химия",purity:99.9,price:2.7,unit:"кг",moq:"200 кг",region:"Азия",supplier:"Shenzhen Fine Ingredients",country:"Китай",initials:"SF",verified:true,shape:"✥",tone:"green-tone",badge:"Высокая чистота",lead:"2–4 недели"}
];
products.forEach(p=>p.verified=false);
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let activeCategory = "", activeProduct = null, saved = new Set();
let requests = [];
let catalogLoadState="loading";
const esc = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),3200)}
function getFiltered(){
 const q=$("#search-input").value.trim().toLowerCase(), region=$("#region-filter").value, purity=$("#purity-filter").value, sort=$("#sort-filter").value;
 const cats=$$('input[name="category"]:checked').map(x=>x.value);
 const evidence={document:$("#catalog-document").value,verifiedOnly:$("#catalog-verified").checked};
 let arr=ChemexCatalog.bySource(products,$("#catalog-source").value).filter(p=>ChemexCatalog.matchesEvidence(p,evidence)&&(!q||[p.name,p.formula,p.cas,p.category,p.supplier,p.country,p.manufacturer,p.grade,p.chemexId].join(" ").toLowerCase().includes(q))&&(!activeCategory||p.category===activeCategory)&&(!cats.length||cats.includes(p.category))&&(!region||p.region===region)&&(!purity||p.purity>=Number(purity)));
 if(sort==="low")arr.sort((a,b)=>a.price-b.price);if(sort==="high")arr.sort((a,b)=>b.price-a.price);if(sort==="name")arr.sort((a,b)=>a.name.localeCompare(b.name,"ru"));
 return arr;
}
function renderProducts(){
 const counts=ChemexCatalog.summary(products),known=catalogLoadState==='loaded';
 for(const [id,key] of [['catalog-live-count','offers'],['catalog-products-count','products'],['catalog-countries-count','countries']])$('#'+id).textContent=known?counts[key]:'—';
 $('#catalog-demo-count').textContent=counts.demo;
 const categories=ChemexCatalog.categories(products,$('#catalog-source').value);
 $$('input[name="category"]').forEach(input=>input.closest('label').querySelector('span').textContent=categories[input.value]||0);

 const arr=getFiltered();const shown=ChemexCatalog.summary(arr);$("#results-count").textContent=`Найдено: ${arr.length} · от компаний: ${shown.offers} · учебных: ${shown.demo}`;
 $("#product-grid").innerHTML=arr.map(p=>`<article class="product-card">
 <div class="product-visual ${p.tone}"><span class="product-flag ${p.verified?"verified":""}">${p.live?(p.verified?"Счёт подтверждён":"Предложение компании"):"Демо"}</span><button class="save-btn ${saved.has(p.id)?"saved":""}" data-save="${p.id}" title="В избранное">${saved.has(p.id)?"♥":"♡"}</button><span class="chem-shape">${p.shape}</span></div>
 <div class="product-body"><div class="product-category">${esc(p.category)}</div><h3>${esc(p.name)}</h3><div class="formula">${esc(p.formula)} · CAS ${esc(p.cas)}</div>
 ${p.live?`<p class="chemex-code">ChemEx ID: ${esc(p.chemexId||"не присвоен — укажите производителя и марку")}</p><small>Производитель: ${esc(p.manufacturer||"не указан")} · ${esc(p.grade||"")}</small>`:""}
 ${p.live?`<div class="catalog-doc-tags">${ChemexCatalog.documentTypes(p).map(type=>`<span>${esc(type)}</span>`).join('')||'<small>Документы не добавлены</small>'}</div>`:''}
 <div class="product-specs"><span class="spec">Чистота ${p.purity}%</span><span class="spec">Мин. ${esc(p.moq)}</span><span class="spec">${esc(p.region)}</span></div>
 <div class="supplier-line"><div class="supplier-logo">${esc(p.initials)}</div><div><b>${esc(p.supplier)}</b><small>${esc(p.country)} · ${p.live?(p.verified?"Расчётный счёт подтверждён":"Счёт не подтверждён"):"Демонстрационная компания"}</small></div>${p.verified?'<span class="verified-check">✓</span>':""}</div>
 ${p.live?`<details class="offer-details"><summary>Характеристики, применение и документы</summary>${technicalDetails(p.technical)}<h4>Документы</h4>${documentLinks(p.documents)}<p>Упаковка: ${esc(p.packaging)}<br>Срок: ${esc(p.lead)}<br>Базис: ${esc(p.incoterm)}</p><p>${esc(p.description)}</p></details>`:""}
 <div class="price-line"><div><small>Ориентировочная цена</small><br><strong>€${p.price.toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:4})}</strong> <small>/ ${p.unit}</small></div></div>
 <button class="rfq-btn" data-rfq="${p.id}">Запросить предложение ↗</button>${p.live?`<button data-partner-add-product="${p.id}">＋ В мои поставщики</button>`:""}</div></article>`).join("");
 $("#empty-state").classList.toggle("hidden",arr.length!==0);$("#product-grid").classList.toggle("hidden",arr.length===0);
 $$("[data-save]").forEach(b=>b.addEventListener("click",async()=>{const id=Number(b.dataset.save);if(!window.accountReady){toast("Дождитесь подключения аккаунта.");return;}b.disabled=true;try{await api('/api/favorites',{method:'PUT',body:{productId:id,saved:!saved.has(id)}});saved.has(id)?saved.delete(id):saved.add(id);renderProducts();toast(saved.has(id)?"Сохранено в аккаунте":"Удалено из избранного")}catch(e){toast(e.message);b.disabled=false;}}));
 $$("[data-rfq]").forEach(b=>b.addEventListener("click",()=>openRfq(Number(b.dataset.rfq))));
}
function resetFilters(){ $("#catalog-document").value="";$("#catalog-verified").checked=false; $("#catalog-source").value=""; $("#search-input").value="";$("#region-filter").value="";$("#purity-filter").value="";$("#sort-filter").value="recommended";$$('input[name="category"]').forEach(x=>x.checked=false);activeCategory="";$$(".chip").forEach(c=>c.classList.toggle("selected",!c.dataset.category));renderProducts()}
function openRfq(id){activeProduct=products.find(p=>p.id===id);$("#modal-product-name").textContent=`${activeProduct.name} · CAS ${activeProduct.cas} · ${activeProduct.supplier}`;$("#modal").classList.remove("hidden");$("#rfq-quantity").focus()}
function closeRfq(){$("#modal").classList.add("hidden")}
const viewInfo={
 market:["Маркетплейс","Находите химическое сырьё и сравнивайте предложения."],
 orders:["Мои запросы","История запросов коммерческих предложений и статусы переговоров."],
 suppliers:["Поставщики","Компании, предлагающие химическое сырьё на международном рынке."],
 company:["Профиль компании","Управляйте данными организации и настройками профиля поставщика."],
 messages:["Сообщения","Переписка по запросам между покупателями и поставщиками."],
 saved:["Избранное","Сохранённые предложения для быстрого сравнения."],
 analytics:["Аналитика","Обзор активности в демонстрационном рабочем пространстве."]
};
function renderOther(view){
 const [title,desc]=viewInfo[view]||viewInfo.market;$("#breadcrumb").textContent=title;$("#other-title").textContent=title;$("#other-description").textContent=desc;
 $("#market-view").classList.toggle("hidden",view!=="market");$("#other-view").classList.toggle("hidden",view==="market");
 $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
 const content=$("#other-content");
 if(view==="orders"){
  content.innerHTML=`<div class="dashboard-panel"><div class="panel-title">Запросы коммерческих предложений</div>${requests.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Товар</th><th>Количество</th><th>Страна доставки</th><th>Дата</th><th>Статус</th></tr></thead><tbody>${requests.map(r=>`<tr><td><b>${esc(r.product)}</b><br><small>CAS ${esc(r.cas)}</small></td><td>${esc(r.quantity)} ${esc(r.unit)}</td><td>${esc(r.destination)}</td><td>${esc(r.date)}</td><td><span class="status">Ожидает ответа</span></td></tr>`).join("")}</tbody></table></div>`:'<p>Пока нет запросов. Перейдите в каталог и запросите предложение у поставщика.</p><button class="primary" data-view="market">Открыть каталог →</button>'}</div>`;
 }else if(view==="suppliers"){
  content.innerHTML=`<div class="dashboard-panel"><div class="panel-title">Поставщики в каталоге</div>${[...new Map(products.map(p=>[p.supplier,p])).values()].map(p=>`<div class="supplier-row"><div class="supplier-emblem">${esc(p.initials)}</div><div class="supplier-details"><b>${esc(p.supplier)} ${p.verified?'<span class="verified-check">✓ Счёт подтверждён</span>':''}</b><p>${esc(p.country)} · ${esc(p.region)} · ${esc(p.category)}</p></div><button data-supplier-rfq="${p.id}">Связаться ↗</button></div>`).join("")}</div>`;
 }else if(view==="company"){
  content.innerHTML=`<div class="company-grid"><div class="company-card"><div class="supplier-emblem">DC</div><h3>Demo Corp.</h3><p>Покупатель · Международная торговля</p><span class="status">Профиль не верифицирован</span><p>Добавьте корпоративные данные, регистрационные документы и рабочие контакты, чтобы повысить доверие поставщиков.</p><button class="primary" data-action="company-profile">Заполнить профиль →</button></div><div class="company-card"><h3>Стать поставщиком</h3><p>Создайте витрину компании, добавьте продукцию, спецификации, сертификаты анализа и условия поставки.</p><p><b>Что понадобится:</b><br>• Регистрационные данные компании<br>• Контактное лицо и корпоративная почта<br>• Документация на товары<br>• Информация о логистике и рынках</p><button class="primary" data-action="supplier-profile">Начать регистрацию →</button></div></div>`;
 }else if(view==="messages"){
  content.innerHTML='<div class="dashboard-panel" role="status">Загружаем переписку…</div>';
 }else if(view==="saved"){
  const list=products.filter(p=>saved.has(p.id));content.innerHTML=`<div class="dashboard-panel"><div class="panel-title">Избранные товары</div>${list.length?list.map(p=>`<div class="supplier-row"><div class="supplier-emblem">${esc(p.initials)}</div><div class="supplier-details"><b>${esc(p.name)}</b><p>CAS ${esc(p.cas)} · €${p.price.toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:4})}/${p.unit} · ${esc(p.supplier)}</p></div><button data-supplier-rfq="${p.id}">Запросить цену</button></div>`).join(""):'<p>Вы пока не сохранили товары. Нажмите ♡ в карточке товара, чтобы добавить его сюда.</p>'}</div>`;
 }else if(view==="analytics"){
  content.innerHTML=`<div class="stats-grid"><div class="stat"><span class="stat-icon cyan">↗</span><div><small>Просмотрено предложений</small><strong>128</strong><span>демо-данные</span></div></div><div class="stat"><span class="stat-icon purple">✉</span><div><small>Отправлено запросов</small><strong>${requests.length}</strong><span>в этом браузере</span></div></div><div class="stat"><span class="stat-icon green">♡</span><div><small>Избранное</small><strong>${saved.size}</strong><span>товаров</span></div></div><div class="stat"><span class="stat-icon orange">◎</span><div><small>Поставщики</small><strong>8</strong><span>в демо-каталоге</span></div></div></div><div class="dashboard-panel"><b>Следующий этап</b><p>После подключения backend аналитика сможет отображать реальные просмотры, конверсию запросов, активность поставщиков и динамику цен.</p></div>`;
 }else{
  content.innerHTML=`<div class="dashboard-panel"><div class="panel-title">Рабочее пространство</div><p>Эта функция представлена в интерфейсе концепции. Для production-версии подключим API, базу данных и систему прав доступа.</p><button class="primary" data-view="market">Вернуться в маркетплейс →</button></div>`;
 }
 content.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>renderOther(b.dataset.view)));
 content.querySelectorAll("[data-supplier-rfq]").forEach(b=>b.addEventListener("click",()=>openRfq(Number(b.dataset.supplierRfq))));
 content.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>toast("Демо: этот процесс подключается на backend-этапе.")));
}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>renderOther(b.dataset.view)));
$$("[data-view]").forEach(b=>{if(!b.classList.contains("nav-item"))b.addEventListener("click",()=>renderOther(b.dataset.view))});
$("#catalog-document").addEventListener("change",renderProducts);$("#catalog-verified").addEventListener("change",renderProducts);$("#catalog-source").addEventListener("change",renderProducts);$("#search-input").addEventListener("input",renderProducts);$("#region-filter").addEventListener("change",renderProducts);$("#purity-filter").addEventListener("change",renderProducts);$("#sort-filter").addEventListener("change",renderProducts);
$$('input[name="category"]').forEach(x=>x.addEventListener("change",()=>{activeCategory="";$$(".chip").forEach(c=>c.classList.toggle("selected",!c.dataset.category));renderProducts()}));
$$(".chip").forEach(c=>c.addEventListener("click",()=>{activeCategory=c.dataset.category;$$(".chip").forEach(x=>x.classList.toggle("selected",x===c));$$('input[name="category"]').forEach(x=>x.checked=x.value===activeCategory);renderProducts()}));
$("#reset-filters").addEventListener("click",resetFilters);$("#clear-filters").addEventListener("click",resetFilters);$("#empty-reset").addEventListener("click",resetFilters);
$("#hero-search").addEventListener("click",()=>{$("#catalog").scrollIntoView({behavior:"smooth"});setTimeout(()=>$("#search-input").focus(),350)});
$("#modal-close").addEventListener("click",closeRfq);$("#modal").addEventListener("click",e=>{if(e.target===$("#modal"))closeRfq()});document.addEventListener("keydown",e=>{if(e.key==="Escape")closeRfq()});
$("#rfq-form").addEventListener("submit",async e=>{e.preventDefault();const button=e.target.querySelector('button[type="submit"]');button.disabled=true;try{const result=await api('/api/requests',{method:'POST',body:{productId:activeProduct.id,quantity:$("#rfq-quantity").value,unit:$("#rfq-unit").value,destination:$("#rfq-destination").value,email:$("#rfq-email").value,message:$("#rfq-message").value,specification:$("#rfq-specification").value,requestedDocuments:[...e.target.querySelectorAll('[name="requested-document"]:checked')].map(el=>el.value)}});requests.unshift(result.request);$("#request-count").textContent=requests.length;closeRfq();e.target.reset();toast("Черновик запроса сохранён в аккаунте.");renderOther('orders');}catch(err){toast(err.message)}finally{button.disabled=false;}});
$("#request-count").textContent='0';
renderProducts();
