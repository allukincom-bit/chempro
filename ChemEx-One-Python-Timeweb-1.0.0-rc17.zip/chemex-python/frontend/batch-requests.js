function drawBatchRequest(g){
 const candidates=g.suppliers.filter(s=>s.eligible),seen=new Set(),defaults=new Set();
 candidates.forEach((s,i)=>{if(!seen.has(s.supplierId)&&seen.size<10){seen.add(s.supplierId);defaults.add(i);}});
 let submitted=null;
 $('#other-content').innerHTML=`<section class="dashboard-panel"><button id="batch-back">← Таблица снабжения</button><h2>Запрос цены нескольким поставщикам</h2><h3>${esc(g.name)}</h3>${productIdentity(g)}<p>Создадим от 2 до 10 отдельных личных черновиков с одинаковым объёмом и требованиями. Каждая компания получит только свой запрос после отдельной отправки в «Моих запросах». Это запрос альтернативных предложений, не распределение объёма закупки.</p><form id="batch-request-form"><fieldset id="batch-fields"><legend>Поставщики и общие требования</legend>${candidates.map((s,i)=>`<label class="compare-check"><input type="checkbox" name="target" value="${i}" ${defaults.has(i)?'checked':''}> ${esc(s.companyName)} · ${esc(supplyRoles[s.role])} · предложение №${s.offerId}</label>`).join('')}<p class="profile-muted">Выберите только одну карточку каждой компании. Прошлые цены и личные условия сотрудничества не переносятся.</p><div class="profile-fields">${offerInput('quantity','Количество для каждого запроса','','number','required min="0.001" max="999999999" step="0.001"')}${offerSelect('unit','Единица',['кг','т','л','шт.'],'кг')}${offerInput('destination','Место поставки','','text','required minlength="2" maxlength="150"')}${offerInput('email','Ваш рабочий email',account?.profile?.contactEmail||'','email','required maxlength="254"')}</div><label class="profile-label">Требования к сырью<textarea name="specification" rows="3" maxlength="2000"></textarea></label><fieldset><legend>Документы</legend>${['SDS','TDS','COA'].map(t=>`<label class="compare-check"><input type="checkbox" name="requestedDocuments" value="${t}"> ${t}</label>`).join('')}</fieldset><label class="profile-label">Дополнительные условия<textarea name="message" rows="3" maxlength="3000"></textarea></label></fieldset><p id="batch-error" class="profile-error" role="alert"></p><button id="batch-submit" class="primary">Создать отдельные черновики</button><p id="batch-status" role="status"></p></form></section>`;
 $('#batch-back').onclick=()=>{if(confirm('Вернуться к таблице? Если отправляли создание пакета, сначала проверьте «Мои запросы».'))loadSupplyMatrix();};
 $('#batch-request-form').onsubmit=async e=>{
  e.preventDefault();const f=e.target,b=$('#batch-submit'),error=$('#batch-error');error.textContent='';
  if(!submitted){
   const selected=[...f.querySelectorAll('[name=target]:checked')].map(el=>candidates[Number(el.value)]);
   if(selected.length<2||selected.length>10){error.textContent='Выберите от 2 до 10 поставщиков.';return;}
   if(new Set(selected.map(s=>s.supplierId)).size!==selected.length){error.textContent='Выберите только одну карточку каждой компании.';return;}
   const form=new FormData(f);submitted={action:'batch_requests',clientId:crypto.randomUUID(),targets:selected.map(s=>({partnerId:s.partnerId,revision:s.revision,offerId:s.offerId})),identity:{chemexId:g.chemexId,cas:g.cas,manufacturer:g.manufacturer,grade:g.grade},...Object.fromEntries(['quantity','unit','destination','email','specification','message'].map(k=>[k,form.get(k)])),requestedDocuments:form.getAll('requestedDocuments')};
  }
  b.disabled=true;$('#batch-fields').disabled=true;$('#batch-status').textContent='Проверяем предложения и создаём черновики…';
  try{
   const data=await api('/api/partners',{method:'POST',body:submitted});if(!f.isConnected)return;
   for(const r of data.requests){const i=requests.findIndex(x=>x.id===r.id);if(i<0)requests.unshift(r);else requests[i]=r;}
   $('#request-count').textContent=requests.length;
   f.innerHTML=`<h3>${data.replayed?'Пакет уже был создан':'Черновики созданы'}: ${data.requests.length}</h3><ul>${data.requests.map(r=>`<li>${esc(r.batchSupplierName||r.product)} · ${esc(requestStatus[r.status]||r.status)}</li>`).join('')}</ul><p>Поставщикам ничего не отправлено этим действием. Проверьте и отправьте каждый нужный черновик отдельно. Повторное нажатие не создаёт копии.</p>${data.missingCount?`<p>Ранее удалено запросов из пакета: ${data.missingCount}. Они не восстановлены.</p>`:''}<button type="button" id="batch-track">Открыть пакет</button><button type="button" id="batch-orders">Открыть «Мои запросы»</button>`;
   $('#batch-track').onclick=()=>loadBatchTracking(data.batchId);
   $('#batch-orders').onclick=()=>renderOther('orders');
  }catch(err){if(f.isConnected){error.textContent=err.message;$('#batch-status').textContent='Можно повторить тот же пакет без создания копий. Для изменения выбора вернитесь к таблице и сначала проверьте «Мои запросы».';b.textContent='Повторить тот же пакет';b.disabled=false;}}
 };
}
