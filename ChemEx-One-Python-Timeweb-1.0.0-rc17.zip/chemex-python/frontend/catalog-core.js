(function(root){
 'use strict';
 function bySource(items,source=''){return items.filter(p=>source==='live'?p.live===true:source==='demo'?p.live!==true:true);}
 function documentTypes(p){
  const types=new Set();
  for(const doc of Array.isArray(p.documents)?p.documents:[]){
   if(!doc||!['SDS','TDS','COA'].includes(doc.type))continue;
   try{const u=new URL(doc.url);if(u.protocol==='https:'&&!u.username&&!u.password)types.add(doc.type);}catch{}
  }
  return [...types];
 }
 function matchesEvidence(p,{document='',verifiedOnly=false}={}){
  if(verifiedOnly&&(p.live!==true||p.verified!==true))return false;
  if(!document)return true;
  if(p.live!==true)return false;
  const types=documentTypes(p);
  return document==='all'?['SDS','TDS','COA'].every(t=>types.includes(t)):types.includes(document);
 }
 function summary(items){
  const live=bySource(items,'live');
  const unique=key=>new Set(live.map(p=>String(p[key]||'').trim().toLocaleLowerCase('ru-RU')).filter(Boolean)).size;
  return {offers:live.length,products:unique('chemexId'),countries:unique('country'),demo:items.length-live.length};
 }
 function categories(items,source=''){const counts={};for(const p of bySource(items,source))counts[p.category]=(counts[p.category]||0)+1;return counts;}
 root.ChemexCatalog={bySource,summary,categories,documentTypes,matchesEvidence};
})(globalThis);
