(function(root){
 'use strict';
 function decode(request){
  if(request.status!=='quoted'||!request.quotation)return null;
  try{const quote=JSON.parse(request.quotation);if(!quote||!Number.isFinite(Number(quote.price))||Number(quote.price)<=0||!['EUR','USD','CNY','RUB'].includes(quote.currency)||!['кг','т','л','шт.'].includes(quote.unit)||!/^\d{4}-\d{2}-\d{2}$/.test(quote.validUntil))return null;return {...request,quote};}catch{return null;}
 }
 function expired(item,today=new Date().toISOString().slice(0,10)){return item.quote.validUntil<today;}
 function same(items,value){return new Set(items.map(value)).size<=1;}
 function vatKey(q){if(q.vatMode==='not_applicable'&&!q.vatRate)return 'not_applicable';if(['included','excluded'].includes(q.vatMode)&&typeof q.vatRate==='string'&&/^\d{1,3}(\.\d{1,2})?$/.test(q.vatRate)&&Number(q.vatRate)<=100)return q.vatMode+'|'+Number(q.vatRate);return null;}
 function vatLabel(q){if(q.vatMode==='not_applicable')return 'НДС не применяется (по данным поставщика)';if(vatKey(q))return (q.vatMode==='included'?'Включён в цену':'Не включён в цену')+' · '+q.vatRate+'%';return 'Условия НДС не указаны';}
 function priceComparable(items){return items.length>=2&&same(items,x=>x.cas)&&same(items,x=>x.quote.currency)&&same(items,x=>x.quote.unit)&&items.every(x=>vatKey(x.quote)!==null)&&same(items,x=>vatKey(x.quote));}
 function filterItems(items,{query='',identity='',activeOnly=false}={},today){
  const q=query.trim().toLocaleLowerCase('ru-RU');
  return items.filter(r=>(!q||[r.product,r.cas,r.supplierCompany,r.chemexId,r.manufacturer,r.grade].join(' ').toLocaleLowerCase('ru-RU').includes(q))&&(!identity||(identity==='__unknown__'?!r.chemexId:r.chemexId===identity))&&(!activeOnly||!expired(r,today)));
 }
 function identityOptions(items){
  const groups=new Map();
  for(const r of items){if(!r.chemexId)continue;const group=groups.get(r.chemexId);if(group)group.count++;else groups.set(r.chemexId,{id:r.chemexId,label:[r.manufacturer,r.grade,r.chemexId].filter(Boolean).join(' · '),count:1});}
  return [...groups.values()].sort((a,b)=>a.label.localeCompare(b.label,'ru'));
 }
 function warnings(items){
  const result=[];
  if(items.some(x=>!x.chemexId))result.push('У части предложений нет сохранённого ChemEx ID. Проверьте производителя и марку.');
  else if(!same(items,x=>x.chemexId))result.push('ChemEx ID различаются: производитель или марка могут отличаться. Одинаковый CAS не подтверждает одинаковое качество сырья.');
  if(items.some(x=>vatKey(x.quote)===null))result.push('Условия НДС не уточнены: сортировка цен недоступна.');
  else if(!same(items,x=>vatKey(x.quote)))result.push('Условия или ставки НДС различаются: сортировка цен недоступна.');
  if(!same(items,x=>(x.quote.moqQuantity||'')+'|'+(x.quote.moqUnit||'')))result.push('Минимальные партии различаются. Проверьте соответствие объёму закупки.');
  if(!same(items,x=>(x.quote.paymentTerms||'').trim()))result.push('Условия оплаты различаются.');
  if(!same(items,x=>x.cas))result.push('Выбраны разные вещества (CAS).');
  if(!same(items,x=>x.quote.currency))result.push('Валюты различаются. Пересчёт курсов не выполняется.');
  if(!same(items,x=>x.quote.unit))result.push('Единицы цены различаются. Пересчёт между кг, тоннами и литрами не выполняется.');
  if(!same(items,x=>x.quote.incoterm))result.push('Базисы поставки различаются: состав расходов может отличаться.');
  if(!same(items,x=>String(Number(x.quantity))+'|'+x.unit))result.push('Предложения получены на разные объёмы закупки.');
  if(!same(items,x=>x.destination.trim().toLowerCase()))result.push('Страны доставки различаются.');
  return result;
 }
 function toggle(selected,id){const next=new Set(selected);if(next.has(id))next.delete(id);else if(next.size<4)next.add(id);return next;}
 // Quote every cell and neutralize spreadsheet formulas, including leading controls.
 function csvCell(value){
  let text=String(value??'');
  if(/^[\s\u0000-\u001f]*[=+@-]/u.test(text)||/^[\t\r\n]/.test(text))text="'"+text;
  return '"'+text.replace(/"/g,'""')+'"';
 }
 function exportCsv(items,rows,notes,generatedAt=new Date().toISOString()){
  if(items.length<2||items.length>4)throw new Error('Выберите от 2 до 4 предложений.');
  const data=[
   ['ChemEx.One — сравнение предложений'],
   ['Выгружено (UTC)',generatedAt],
   ['Примечание','Снимок выбранных ответов. Итоговая стоимость с доставкой, налогами и пошлинами не рассчитана.'],
   ...notes.map(note=>['Предупреждение',note]),
   ['Параметр',...items.map(r=>r.supplierCompany||'Поставщик')],
   ['ID запроса',...items.map(r=>r.id)],
   ...rows.map(([label,value])=>[label,...items.map(value)])
  ];
  return '\uFEFF'+data.map(row=>row.map(csvCell).join(';')).join('\r\n')+'\r\n';
 }
 root.ChemexCompare={decode,expired,priceComparable,warnings,toggle,vatLabel,exportCsv,filterItems,identityOptions};
})(globalThis);
