viewInfo.compare=['Сравнение предложений','Сопоставьте ответы поставщиков перед дальнейшими переговорами.'];
const compareRenderOther=renderOther;
renderOther=function(view){compareRenderOther(view);if(view==='compare')loadComparison();};
let compareItems=[],compareSelected=new Set(),compareQuery='',compareIdentity='',compareActiveOnly=false,compareSequence=0,compareSort=false;
async function loadComparison(){
 const seq=++compareSequence;$('#other-content').innerHTML='<div class="dashboard-panel" role="status">Загружаем коммерческие предложения…</div>';
 try{const data=await api('/api/requests');if(seq!==compareSequence||window.currentView!=='compare')return;
 requests=data.requests;$('#request-count').textContent=requests.length;
 compareItems=requests.map(ChemexCompare.decode).filter(Boolean);
 compareSelected=new Set([...compareSelected].filter(id=>compareItems.some(r=>r.id===id)));
 drawComparison();
 }catch(e){if(seq!==compareSequence||window.currentView!=='compare')return;$('#other-content').innerHTML=`<div class="dashboard-panel"><p role="alert">${esc(e.message)}</p><button id="retry-compare" class="primary">Повторить</button></div>`;$('#retry-compare').onclick=loadComparison;}
}
function drawComparison(){
 const identities=ChemexCompare.identityOptions(compareItems);
 if(compareIdentity&&compareIdentity!=='__unknown__'&&!identities.some(x=>x.id===compareIdentity))compareIdentity='';
 const valid=compareItems.filter(x=>!ChemexCompare.expired(x)).length;
 $('#other-content').innerHTML=`<div class="dashboard-panel"><div class="offers-toolbar"><div><h3>Ответы поставщиков</h3><p class="profile-muted">${compareItems.length} получено · ${valid} действуют · ${compareItems.length-valid} истекли</p></div><button id="refresh-compare">Обновить ↻</button></div>${compareItems.length?`<div class="compare-filters"><label class="profile-label">Поиск по товару, CAS, ChemEx ID, компании или марке<input id="compare-search" type="search" value="${esc(compareQuery)}" placeholder="Например, лимонная кислота"></label><label class="profile-label">Продукт (ChemEx ID)<select id="compare-identity"><option value="">Все продукты</option>${identities.map(x=>`<option value="${esc(x.id)}" ${compareIdentity===x.id?'selected':''}>${esc(x.label)} (${x.count})</option>`).join('')}<option value="__unknown__" ${compareIdentity==='__unknown__'?'selected':''}>Без сохранённого ChemEx ID</option></select></label><label class="compare-check"><input type="checkbox" id="compare-active" ${compareActiveOnly?'checked':''}> Только действующие</label><button id="reset-compare-filters">Сбросить фильтры</button></div><div id="compare-options"></div><div class="compare-actions"><span id="compare-count" role="status"></span><button id="clear-compare">Снять выбор</button></div><div id="compare-table"></div>`:`<div class="offers-empty"><h3>Пока нечего сравнивать</h3><p>Отправьте запросы поставщикам из раздела «Мои запросы». Полученные ответы появятся здесь автоматически при открытии раздела.</p><button class="primary" id="compare-requests">Мои запросы →</button></div>`}</div>`;
 $('#refresh-compare').onclick=loadComparison;
 $('#compare-requests')?.addEventListener('click',()=>renderOther('orders'));
 if(!compareItems.length)return;
 $('#compare-search').oninput=e=>{compareQuery=e.target.value;drawComparisonOptions();};
 $('#compare-identity').onchange=e=>{compareIdentity=e.target.value;drawComparisonOptions();};
 $('#reset-compare-filters').onclick=()=>{compareQuery='';compareIdentity='';compareActiveOnly=false;drawComparison();};
 $('#compare-active').onchange=e=>{compareActiveOnly=e.target.checked;drawComparisonOptions();};
 $('#clear-compare').onclick=()=>{compareSelected.clear();compareSort=false;drawComparisonOptions();};
 drawComparisonOptions();
}
function drawComparisonOptions(){
 const visible=ChemexCompare.filterItems(compareItems,{query:compareQuery,identity:compareIdentity,activeOnly:compareActiveOnly});
 $('#compare-options').innerHTML=visible.length?`<div class="compare-options">${visible.map(r=>`<label class="compare-option ${compareSelected.has(r.id)?'selected':''}"><input type="checkbox" data-compare-id="${esc(r.id)}" ${compareSelected.has(r.id)?'checked':''} ${compareSelected.size>=4&&!compareSelected.has(r.id)?'disabled':''}><span><b>${esc(r.supplierCompany||'Поставщик')}</b><span>${esc(r.product)} · CAS ${esc(r.cas)}</span><small>${esc(r.manufacturer||'Производитель не сохранён')} · ${esc(r.grade||'Марка не сохранена')}</small><small>ChemEx ID: ${esc(r.chemexId||'не сохранён')}</small><strong>${esc(r.quote.price)} ${esc(r.quote.currency)} / ${esc(r.quote.unit)}</strong><small>${esc(r.quantity)} ${esc(r.unit)} → ${esc(r.destination)} · ${ChemexCompare.expired(r)?'Срок истёк':'До '+esc(r.quote.validUntil)}</small></span></label>`).join('')}</div>`:'<p class="profile-muted">По этим условиям ничего не найдено. Измените поиск или отключите фильтр срока действия.</p>';
 $$('[data-compare-id]').forEach(b=>b.onchange=()=>{compareSelected=ChemexCompare.toggle(compareSelected,b.dataset.compareId);drawComparisonOptions();});
 $('#compare-count').textContent=`Найдено ${visible.length} из ${compareItems.length} · выбрано ${compareSelected.size} из 4${[...compareSelected].some(id=>!visible.some(r=>r.id===id))?' · часть выбранных скрыта фильтром':''}`;
 $('#clear-compare').disabled=!compareSelected.size;
 drawComparisonTable();
}
function drawComparisonTable(){
 let selected=[...compareSelected].map(id=>compareItems.find(r=>r.id===id)).filter(Boolean);
 const host=$('#compare-table');
 if(selected.length<2){host.innerHTML='<div class="offers-empty"><h3>Выберите от 2 до 4 предложений</h3><p>Таблица покажет цену, объём, условия и комментарии каждого поставщика.</p></div>';return;}
 const comparable=ChemexCompare.priceComparable(selected);if(!comparable)compareSort=false;
 if(compareSort)selected.sort((a,b)=>Number(a.quote.price)-Number(b.quote.price));
 const warnings=ChemexCompare.warnings(selected);
 if(selected.some(r=>ChemexCompare.expired(r)))warnings.push('Среди выбранных есть предложения с истёкшим сроком действия. Уточните актуальность у поставщика.');
 const rows=[
 ['Товар',r=>r.product],['ChemEx ID',r=>r.chemexId||'Не сохранён в запросе'],['Производитель',r=>r.manufacturer||'Не сохранён'],['Марка',r=>r.grade||'Не сохранена'],['CAS',r=>r.cas],['Цена за единицу',r=>`${r.quote.price} ${r.quote.currency} / ${r.quote.unit}`],
 ['НДС',r=>ChemexCompare.vatLabel(r.quote)],['Минимальная партия',r=>r.quote.moqQuantity?r.quote.moqQuantity+' '+r.quote.moqUnit:'Не указана'],['Условия оплаты',r=>r.quote.paymentTerms||'Не указаны'],['Упаковка',r=>r.quote.packaging||'Не указана'],
 ['Запрошенный объём',r=>`${r.quantity} ${r.unit}`],['Страна доставки',r=>r.destination],['Базис поставки',r=>r.quote.incoterm],
 ['Срок поставки',r=>r.quote.lead],['Действует по (UTC)',r=>r.quote.validUntil+(ChemexCompare.expired(r)?' — истёк':'')],
 ['Требования к сырью',r=>r.specification||'Не указаны'],['Запрошенные документы',r=>(r.requestedDocuments||[]).join(', ')||'Не указаны'],['Комментарий покупателя',r=>r.message||'Не указан'],['Условия поставщика',r=>r.quote.message||'Не указаны'],
 ['Ответ получен',r=>new Date(r.repliedAt).toLocaleString('ru-RU')]
 ];
 host.innerHTML=`${warnings.length?`<div class="compare-warning" role="status"><b>Учитывайте различия</b><ul>${warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul></div>`:''}<div class="compare-actions"><h3>Сравнение условий</h3><button id="export-compare">Скачать CSV</button><label class="compare-check"><input id="compare-sort" type="checkbox" ${compareSort?'checked':''} ${comparable?'':'disabled'}> По возрастанию цены</label></div><p class="profile-muted">${comparable?'Сортировка сравнивает только цену за указанную единицу.':'Сортировка цены доступна для одинаковых CAS, валюты, единицы цены и известных одинаковых условий НДС.'} Итоговая стоимость с доставкой, налогами и пошлинами не рассчитана. Проверьте чистоту, качество и упаковку в требованиях и условиях поставщика.</p><div class="comparison-scroll" tabindex="0" role="region" aria-label="Таблица сравнения, прокручивается горизонтально"><table class="comparison-table" style="min-width:${160+selected.length*230}px"><caption>Коммерческие предложения поставщиков</caption><thead><tr><th scope="col">Параметр</th>${selected.map(r=>`<th scope="col"><b>${esc(r.supplierCompany||'Поставщик')}</b><button data-remove-compare="${esc(r.id)}" aria-label="Убрать ${esc(r.supplierCompany||'предложение')} из сравнения">Убрать ×</button></th>`).join('')}</tr></thead><tbody>${rows.map(([label,value])=>`<tr><th scope="row">${label}</th>${selected.map(r=>`<td class="preserve-lines">${esc(value(r))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
 $('#export-compare').onclick=()=>{
  const csv=ChemexCompare.exportCsv(selected,rows,warnings);
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));
  const link=document.createElement('a');link.href=url;link.download='ChemEx-comparison-'+new Date().toISOString().slice(0,10)+'.csv';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('CSV содержит выбранные предложения, включая скрытые фильтром.');
 };
 $('#compare-sort').onchange=e=>{compareSort=e.target.checked;drawComparisonTable();};
 $$('[data-remove-compare]').forEach(b=>b.onclick=()=>{compareSelected.delete(b.dataset.removeCompare);drawComparisonOptions();});
}
// Shortcut from a received quotation; data is refreshed from the authenticated API.
document.addEventListener('click',e=>{const button=e.target.closest('[data-compare-request]');if(!button)return;const id=button.dataset.compareRequest;if(!compareSelected.has(id)&&compareSelected.size>=4){toast('В сравнении уже 4 предложения. Уберите одно из них.');return;}compareSelected.add(id);renderOther('compare');});
