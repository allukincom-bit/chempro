/* Python hosting; the endpoint enforces superadministrator access. */
adminSections.hosting='Диагностика хостинга';
const hostingPreviousRender=renderSuperAdmin;
renderSuperAdmin=async function(section='overview'){
 await hostingPreviousRender(section);if(section!=='hosting'||window.currentView!=='admin'||adminSection!==section)return;
 const body=document.querySelector('#admin-body'),ticket=adminGeneration;if(!body)return;
 body.innerHTML='<section class="dashboard-panel" role="status">Проверяем окружение хостинга…</section>';
 try{
  const d=await api('/api/diagnostics');if(!body.isConnected||ticket!==adminGeneration)return;
  body.innerHTML=`<section class="dashboard-panel"><h3>Диагностика хостинга</h3><p>Ошибок: <b>${d.failures}</b> · Предупреждений: <b>${d.warnings}</b> · ${esc(adminDate(d.generatedAt))}</p><p>${esc(d.notice)}</p><div class="admin-records">${d.checks.map(c=>`<article class="admin-record"><span class="admin-badge ${c.status==='pass'?'':'warning'}">${({pass:'Готово',warn:'Проверьте',fail:'Ошибка'})[c.status]}</span><p>${esc(c.message)}</p><small>${esc(c.id)}</small></article>`).join('')}</div><div class="profile-footer"><button data-hosting-refresh>Повторить проверку</button><button data-hosting-report>Скачать отчёт JSON</button></div></section>`;
  body.querySelector('[data-hosting-refresh]').onclick=()=>renderSuperAdmin('hosting');
  body.querySelector('[data-hosting-report]').onclick=()=>laboratoryDownload('chemex-hosting-diagnostics.json',d);
 }catch(e){if(body.isConnected&&ticket===adminGeneration)body.innerHTML=`<div class="dashboard-panel" role="alert">${esc(e.message)}</div>`;}
};
