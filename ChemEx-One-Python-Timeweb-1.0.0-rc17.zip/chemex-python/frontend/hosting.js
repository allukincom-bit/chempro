// Same-origin CSRF protection for the existing JSON and PDF clients.
(() => {
 const nativeFetch=window.fetch.bind(window);
 window.fetch=(input,options={})=>{
  const url=new URL(input instanceof Request?input.url:String(input),location.href);
  const method=(options.method||(input instanceof Request?input.method:'GET')).toUpperCase();
  if(url.origin===location.origin&&!['GET','HEAD','OPTIONS'].includes(method)){
   const headers=new Headers(options.headers||(input instanceof Request?input.headers:undefined));
   headers.set('X-CSRF-Token',document.querySelector('meta[name="csrf-token"]')?.content||'');
   options={...options,headers};
  }
  return nativeFetch(input,options);
 };
})();
