/* Shared CSV/JSON import logic. No network or DOM dependency. */
(function(root){
 const fields=['name','manufacturer','grade','cas','category','sourceName','sourceUrl','note','applications','originCountry','checkedAt','documents'];
 const required=['name','grade','category','sourceName','sourceUrl','note','checkedAt'];
 function csv(text,delimiter){
  const rows=[];let cells=[],value='',quoted=false,closed=false,line=1,start=1;
  const cell=()=>{cells.push(value);value='';closed=false;};
  const row=()=>{cell();if(cells.some(c=>c.trim()))rows.push({cells,line:start});cells=[];start=line+1;};
  for(let i=0;i<text.length;i++){
   const c=text[i];
   if(quoted){if(c==='"'){if(text[i+1]==='"'){value+='"';i++;}else{quoted=false;closed=true;}}else{value+=c;if(c==='\n')line++;}continue;}
   if(c==='"'){if(value||closed)throw new Error('Строка '+line+': лишняя кавычка.');quoted=true;continue;}
   if(c===delimiter){cell();continue;}
   if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row();line++;continue;}
   if(closed)throw new Error('Строка '+line+': символ после закрывающей кавычки.');value+=c;
  }
  if(quoted)throw new Error('Строка '+start+': незакрытая кавычка.');
  if(value||cells.length||closed)row();return rows;
 }
 function parse(text,filename){
  text=text.replace(/^\uFEFF/,'');let entries;
  if(/\.csv$/i.test(filename)){
   const header=text.split(/\r?\n/,1)[0],delimiter=header.includes(';')?';':',';
   const rows=csv(text,delimiter);if(!rows.length)throw new Error('Пустой CSV.');
   const keys=rows.shift().cells.map(s=>s.trim());
   if(new Set(keys).size!==keys.length||keys.some(k=>!fields.includes(k)))throw new Error('Неизвестные или повторяющиеся столбцы CSV. Используйте шаблон.');
   if(required.some(k=>!keys.includes(k)))throw new Error('В CSV отсутствуют обязательные столбцы: '+required.filter(k=>!keys.includes(k)).join(', '));
   entries=rows.map(r=>{if(r.cells.length!==keys.length)throw new Error('Строка '+r.line+': число ячеек не совпадает с заголовком.');const product={};keys.forEach((k,i)=>{product[k]=r.cells[i].trim();});try{product.documents=product.documents?JSON.parse(product.documents):[];}catch{throw new Error('Строка '+r.line+': documents должен содержать JSON-массив.');}return {product,row:r.line};});
  }else{let products;try{products=JSON.parse(text);}catch{throw new Error('Некорректный JSON.');}if(!Array.isArray(products))throw new Error('JSON должен содержать массив карточек.');entries=products.map((product,i)=>({product,row:i+1}));}
  if(!entries.length||entries.length>1000)throw new Error('Допустимо от 1 до 1 000 записей.');
  return entries;
 }
 function inspectCsv(text,delimiter='auto'){
  text=text.replace(/^\uFEFF/,'');
  if(delimiter==='auto'){
   const candidates=[';',',','\t'].map(d=>{try{const rows=csv(text,d);return rows.length&&rows.every(r=>r.cells.length===rows[0].cells.length)?{d,count:rows[0].cells.length}:null;}catch{return null;}}).filter(Boolean).sort((a,b)=>b.count-a.count);
   if(!candidates.length)throw new Error('Не удалось прочитать CSV. Проверьте разделитель и кавычки.');
   if(candidates.length>1&&candidates[0].count===candidates[1].count)throw new Error('Выберите разделитель CSV вручную.');
   delimiter=candidates[0].d;
  }
  if(![';',',','\t'].includes(delimiter))throw new Error('Неизвестный разделитель.');
  const rows=csv(text,delimiter);if(rows.length<2||rows.length>1001)throw new Error('Нужен заголовок и от 1 до 1 000 записей.');
  const headers=rows.shift().cells.map(s=>s.trim());if(headers.length>100)throw new Error('Допустимо до 100 столбцов.');
  for(const r of rows)if(r.cells.length!==headers.length)throw new Error('Строка '+r.line+': число ячеек не совпадает с заголовком.');
  return {headers,rows,delimiter};
 }
 function mappedCsv(table,mapping,defaults={}){
  const used=new Set();
  for(const field of fields){const index=mapping[field];if(index!==undefined&&index!==null&&index!==''){
   if(!Number.isInteger(index)||index<0||index>=table.headers.length)throw new Error('Выберите столбец для '+field);
   if(used.has(index))throw new Error('Один столбец нельзя назначить двум полям.');used.add(index);
  }else if(required.includes(field)&&!String(defaults[field]??'').trim())throw new Error('Сопоставьте обязательное поле '+field+' или задайте общее значение.');}
  return table.rows.map(r=>{const product={};for(const field of fields){const index=mapping[field];product[field]=(Number.isInteger(index)?r.cells[index]:String(defaults[field]??'')).trim();}
   try{product.documents=product.documents?JSON.parse(product.documents):[];}catch{throw new Error('Строка '+r.line+': documents должен содержать JSON-массив.');}
   if(!Array.isArray(product.documents))throw new Error('Строка '+r.line+': documents должен содержать JSON-массив.');return {product,row:r.line};});
 }
 function chunks(entries){
  const result=[];let chunk=[];
  const length=items=>new TextEncoder().encode(JSON.stringify({action:'preview',reviewed:true,products:items.map(x=>x.product)})).length;
  for(const entry of entries){if(length([entry])>15000)throw new Error('Строка '+entry.row+': карточка слишком большая.');if(chunk.length===10||length([...chunk,entry])>15000){result.push(chunk);chunk=[];}chunk.push(entry);}if(chunk.length)result.push(chunk);return result;
 }
 function escapeCell(value){let s=String(value??'');if(/^[\s]*[=+\-@]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
 function exportCsv(rows){return '\uFEFF'+rows.map(r=>r.map(escapeCell).join(';')).join('\r\n');}
 root.ChemExImport={parse,chunks,exportCsv,fields,required,inspectCsv,mappedCsv};
})(globalThis);
