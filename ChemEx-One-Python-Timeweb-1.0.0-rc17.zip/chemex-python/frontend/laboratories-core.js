/* Shared, dependency-free directory validation, search and export. */
(() => {
 const normalize=v=>String(v??'').normalize('NFKC').toLocaleLowerCase('ru-RU').replace(/ё/g,'е').replace(/\s+/g,' ').trim();
 const url=v=>{try{const u=new URL(v);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password;}catch{return false;}};
 const date=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&!isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;
 const key=r=>normalize(r.accreditationNumber).replace(/\s/g,'')+'|'+normalize(r.address);
 function validate(data){
  if(data?.schemaVersion!==1||!Array.isArray(data.laboratories)||data.laboratories.length>50000)throw Error('Некорректный формат справочника.');
  if(!data.coverage||data.coverage.complete!==false)throw Error('Полноту реестра нельзя подтвердить простой загрузкой списка.');
  const ids=new Set(),keys=new Set(),today=new Date().toISOString().slice(0,10);
  for(const r of data.laboratories){
   if(!r||!/^LAB-RU-[A-Z0-9-]{1,80}$/.test(r.id)||ids.has(r.id))throw Error('Некорректный или повторяющийся ID лаборатории.');ids.add(r.id);
   for(const field of ['name','region','city','address','addressKind','accreditationNumber'])if(typeof r[field]!=='string'||!r[field].trim()||r[field].length>600)throw Error('Заполните поле '+field+' в '+r.id);
   if(typeof r.addressNote!=='string'||r.addressNote.length>2000)throw Error('Проверьте примечание адреса.');
   for(const field of ['phones','emails','tags','services','sourceUrls'])if(!Array.isArray(r[field])||r[field].length>30||r[field].some(v=>typeof v!=='string'||!v.trim()||v.length>1500))throw Error('Проверьте '+field+' в '+r.id);
   if(!r.services.length||!r.sourceUrls.length)throw Error('Нужны услуги и источники.');
   if(r.phones.some(v=>!/^\+?[\d ()-]{5,40}$/.test(v))||r.emails.some(v=>! /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(v)))throw Error('Проверьте контакты.');
   if(!url(r.website)||!url(r.accreditationSourceUrl)||!url(r.registryUrl)||r.sourceUrls.some(v=>!url(v))||(r.scopeUrl!==null&&!url(r.scopeUrl)))throw Error('Небезопасная или некорректная ссылка.');
   if(new URL(r.registryUrl).hostname!=='pub.fsa.gov.ru')throw Error('Ссылка РАЛ должна вести на официальный реестр.');
   if(!date(r.sourceCheckedAt)||r.sourceCheckedAt>today)throw Error('Некорректная дата проверки источника.');
   if(!['not_checked','active','suspended','terminated','partly_suspended'].includes(r.registryStatus))throw Error('Некорректный статус.');
   if(r.registryStatus!=='not_checked'&&(!date(r.registryCheckedAt)||r.registryCheckedAt>today||!new URL(r.registryUrl).pathname.startsWith('/ral/view/')||!url(r.scopeUrl)))throw Error('Статус требует даты, карточки РАЛ и ссылки на область аккредитации.');
   if(r.registryStatus==='not_checked'&&r.registryCheckedAt!==null)throw Error('Непроверенному статусу нельзя назначить дату проверки РАЛ.');
   if(keys.has(key(r)))throw Error('Дубль: номер аккредитации и адрес.');keys.add(key(r));
  }return data;
 }
 function status(r,today=new Date().toISOString().slice(0,10)){
  if(r.registryStatus==='not_checked')return 'Статус РАЛ не проверен';
  const label={active:'Действовала по РАЛ',suspended:'Приостановлена по РАЛ',terminated:'Прекращена по РАЛ',partly_suspended:'Частично приостановлена по РАЛ'}[r.registryStatus];
  const stale=Date.parse(today)-Date.parse(r.registryCheckedAt)>30*86400000;
  return `${label} на ${r.registryCheckedAt}${stale?' · требуется обновление':''}`;
 }
 function filter(rows,{q='',region='',tag='',status:state=''}={}){
  const tokens=normalize(q).split(' ').filter(Boolean);
  return rows.filter(r=>(!region||r.region===region)&&(!tag||r.tags.includes(tag))&&(!state||r.registryStatus===state)&&tokens.every(t=>normalize([r.name,r.accreditationNumber,r.region,r.city,r.address,...r.services,...r.tags].join(' ')).includes(t)||normalize(r.accreditationNumber).replace(/\s/g,'').includes(t.replace(/\s/g,''))));
 }
 function csv(rows){
  const fields=['Название','Регион','Город','Адрес','Тип адреса','Примечание','Телефоны','Email','Услуги по сайту','Номер аккредитации по сайту','Статус РАЛ','Дата проверки РАЛ','Дата проверки сайта','Сайт','РАЛ','Источники'];
  const cell=v=>{let s=String(v??'');if(/^\s*[=+@-]|^[\t\r\n]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};
  return '\ufeff'+[fields,...rows.map(r=>[r.name,r.region,r.city,r.address,r.addressKind,r.addressNote,r.phones.join('; '),r.emails.join('; '),r.services.join('; '),r.accreditationNumber,status(r),r.registryCheckedAt||'',r.sourceCheckedAt,r.website,r.registryUrl,r.sourceUrls.join('; ')])].map(row=>row.map(cell).join(';')).join('\r\n');
 }
 globalThis.ChemExLabs={normalize,url,date,key,validate,status,filter,csv};
})();
