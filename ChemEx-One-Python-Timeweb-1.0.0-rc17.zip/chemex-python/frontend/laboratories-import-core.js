/* New-record import only. Existing cards are never overwritten by this workflow. */
(() => {
 const C=globalThis.ChemExLabs, MAX_ROWS=200, MAX_BYTES=2*1024*1024;
 function parse(text){
  if(new TextEncoder().encode(text).length>MAX_BYTES)throw Error('Файл больше 2 МБ. Разделите его на части.');
  let data;try{data=JSON.parse(text.replace(/^\uFEFF/,''));}catch{throw Error('Не удалось прочитать JSON. Проверьте формат файла.');}
  if(data?.schemaVersion!==1||data?.coverage?.complete!==false||!Array.isArray(data.laboratories)||!data.laboratories.length||data.laboratories.length>MAX_ROWS)throw Error('Нужен JSON schemaVersion: 1, coverage.complete: false и от 1 до 200 laboratories.');
  return data;
 }
 function plan(data,existing){
  const ids=new Map(existing.map(x=>[x.record.id,x])),keys=new Map(existing.map(x=>[C.key(x.record),x]));
  const seenIds=new Set(),seenKeys=new Set();
  return data.laboratories.map((record,index)=>{
   const row={line:index+1,id:record?.id||'',name:record?.name||'',record,status:'new',message:'Будет добавлена скрытая карточка'};
   try{
    C.validate({schemaVersion:1,coverage:{complete:false},laboratories:[record]});
    const key=C.key(record);
    if(seenIds.has(record.id)||seenKeys.has(key))throw Error('Дубль ID или сочетания номера и адреса внутри файла.');
    seenIds.add(record.id);seenKeys.add(key);
    if(ids.has(record.id)||keys.has(key)){row.status='skip';row.message='Уже есть в базе; изменения не применяются. Для правок используйте редактор.';}
   }catch(e){row.status='invalid';row.message=e.message;}
   return row;
  });
 }
 async function run(rows,{reason,reviewed=false,create,stopped=()=>false,progress=()=>{}}){
  if(rows.some(x=>x.status==='invalid'))throw Error('Сначала исправьте все ошибки файла.');
  if(typeof reason!=='string'||reason.trim().length<5||reason.trim().length>1000)throw Error('Укажите причину импорта: от 5 до 1000 символов.');
  if(rows.some(x=>x.status==='new'&&x.record.registryStatus!=='not_checked')&&!reviewed)throw Error('Подтвердите ручную сверку статусов в РАЛ.');
  const results=rows.map(x=>({line:x.line,id:x.id,name:x.name,status:x.status==='skip'?'skipped':'pending',message:x.status==='skip'?x.message:'Не отправлена'}));
  // Preflight all requests against both UTF-8 PHP and Sites limits before any write.
  const payloads=rows.map(x=>({record:x.record,revision:0,hidden:true,reason:reason.trim(),registryReviewed:reviewed}));
  for(let i=0;i<rows.length;i++)if(rows[i].status==='new'&&new TextEncoder().encode(JSON.stringify(payloads[i])).length>16000)throw Error('Строка '+rows[i].line+': карточка превышает 16 КБ. Сократите текст или ссылки.');
  for(let i=0;i<rows.length;i++){
   if(rows[i].status!=='new')continue;
   if(stopped())break;
   try{await create(payloads[i]);results[i].status='created';results[i].message='Добавлена скрытая карточка';}
   catch(e){results[i].status='check';results[i].message='Требуется повторная сверка с базой: '+e.message;progress(results);break;}
   progress(results);
  }
  return results;
 }
 globalThis.ChemExLabImport={parse,plan,run,MAX_ROWS,MAX_BYTES};
})();
