let labImportBusy=false,labImportReport=null;
function laboratoryDownload(name,data){
 const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json;charset=utf-8'}));
 const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function renderLaboratoryImporter(host,existing){
 const target=host.querySelector('#lab-editor');
 if(labImportBusy){toast('Дождитесь завершения текущей загрузки.');return;}
 target.innerHTML=`<section class="admin-decision-form"><h3>Массовая загрузка лабораторий</h3><p>JSON до 2 МБ, от 1 до 200 карточек. Новые записи сохраняются скрытыми: проверьте их и опубликуйте через редактор. Совпадения ID или номера с адресом пропускаются.</p><p>Импорт не проверяет официальный реестр автоматически и не подтверждает полноту справочника.</p><div class="profile-footer"><button type="button" data-template>Скачать образец JSON</button><button type="button" data-report ${labImportReport?'':'disabled'}>Скачать последний отчёт</button></div><label class="profile-label">Файл JSON<input type="file" accept=".json,application/json" data-file></label><button type="button" data-preview>Проверить и показать предпросмотр</button><div data-error role="alert"></div><div data-preview-result></div><div data-live role="status"></div></section>`;
 target.scrollIntoView({behavior:'smooth',block:'start'});
 const panel=target.firstElementChild;
 const file=target.querySelector('[data-file]'),preview=target.querySelector('[data-preview]'),error=target.querySelector('[data-error]'),result=target.querySelector('[data-preview-result]'),live=target.querySelector('[data-live]'),report=target.querySelector('[data-report]');
 let rows=null,stop=false,filename='';
 target.querySelector('[data-template]').onclick=()=>{if(!existing.length){toast('Сначала создайте одну карточку как образец.');return;}laboratoryDownload('chemex-laboratories-example.json',{schemaVersion:1,coverage:{complete:false},laboratories:[existing[0].record]});};
 report.onclick=()=>labImportReport&&laboratoryDownload('chemex-laboratories-import-report.json',labImportReport);
 file.onchange=()=>{rows=null;result.innerHTML='';error.textContent='';live.textContent='';};
 preview.onclick=async()=>{
  error.textContent='';result.innerHTML='';rows=null;const selected=file.files[0];if(!selected){error.textContent='Выберите JSON-файл.';return;}
  preview.disabled=true;file.disabled=true;
  try{
   if(selected.size>ChemExLabImport.MAX_BYTES)throw Error('Файл больше 2 МБ.');
   const parsed=ChemExLabImport.parse(await selected.text());
   const fresh=await api('/api/laboratories?admin=1');if(!panel.isConnected)return;
   rows=ChemExLabImport.plan(parsed,fresh.items);filename=selected.name;
   labImportReport={createdAt:new Date().toISOString(),filename,stage:'preview',results:rows.map(({line,id,name,status,message})=>({line,id,name,status,message}))};report.disabled=false;
   const count=s=>rows.filter(r=>r.status===s).length;
   result.innerHTML=`<p><b>Новых: ${count('new')}</b> · Пропущено: ${count('skip')} · Ошибок: ${count('invalid')}</p><p>Образец содержит существующую карточку. Для новой площадки укажите уникальный ID вида LAB-RU-…, номер и адрес. Существующие карточки здесь не обновляются.</p><div class="lab-import-scroll"><table class="lab-import-table"><thead><tr><th>Строка</th><th>Лаборатория</th><th>Результат проверки</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r.line}</td><td>${esc(r.name)}<br><small>${esc(r.id)}</small></td><td>${esc(r.message)}</td></tr>`).join('')}</tbody></table></div><form data-commit><label class="profile-label">Причина импорта<textarea name="reason" minlength="5" maxlength="1000" required rows="2"></textarea></label><label class="compare-check"><input type="checkbox" name="reviewed"> Я вручную сверил в РАЛ все записи файла с указанным проверенным статусом.</label><p>Карточки сохраняются последовательно. При ошибке или остановке уже сохранённые записи остаются; повторный предпросмотр сверит файл с базой.</p><div class="profile-footer"><button class="primary" type="submit" ${count('invalid')||!count('new')?'disabled':''}>Загрузить ${count('new')} скрытых карточек</button><button type="button" data-stop disabled>Остановить после текущей карточки</button></div></form>`;
   const form=result.querySelector('form'),stopButton=form.querySelector('[data-stop]');
   stopButton.onclick=()=>{stop=true;stopButton.disabled=true;live.textContent='Завершаем текущий запрос…';};
   form.onsubmit=async e=>{
    e.preventDefault();if(labImportBusy)return;labImportBusy=true;stop=false;error.textContent='';preview.disabled=true;file.disabled=true;form.querySelector('[type=submit]').disabled=true;stopButton.disabled=false;
    const update=items=>{labImportReport={createdAt:new Date().toISOString(),filename,stage:'import',results:items.map(x=>({...x}))};if(panel.isConnected){report.disabled=false;live.textContent=`Добавлено: ${items.filter(x=>x.status==='created').length}. Пропущено: ${items.filter(x=>x.status==='skipped').length}. Не отправлено: ${items.filter(x=>x.status==='pending').length}.`;}};
    try{
     const items=await ChemExLabImport.run(rows,{reason:form.elements.reason.value,reviewed:form.elements.reviewed.checked,create:body=>api('/api/laboratories',{method:'POST',body}),stopped:()=>stop||!panel.isConnected,progress:update});
     update(items);labsCache=null;if(panel.isConnected)live.textContent+=' Загрузка завершена или остановлена. Скачайте отчёт. Для продолжения повторите предпросмотр; для публикации откройте карточки в списке.';
    }catch(err){if(panel.isConnected)error.textContent=err.message;}
    finally{labImportBusy=false;if(panel.isConnected){preview.disabled=false;file.disabled=false;stopButton.disabled=true;}}
   };
  }catch(err){if(panel.isConnected)error.textContent=err.message;}
  finally{if(panel.isConnected){preview.disabled=false;file.disabled=false;}}
 };
}
