const partnerTaskStates={overdue:"Просрочено",today:"Сегодня",planned:"Запланировано"};
const partnerTaskActions={scheduled:"Назначено",changed:"Изменено",cancelled:"Снято",rescheduled:"Перенесено",completed:"Выполнено",linked:"Связь изменена"};
function taskEventMarkup(e){
 return `<article class="trade-card"><div class="offers-toolbar"><b>${esc(partnerTaskActions[e.action]||e.action)}</b><small>${esc(new Date(e.createdAt).toLocaleString('ru-RU'))}</small></div>${e.title?`<p class="preserve-lines">${esc(e.title)} · срок ${esc(e.dueDate)}</p>`:''}${e.nextAction?`<p class="preserve-lines">${e.action==='completed'?'Следующее действие':'План'}: ${esc(e.nextAction)} · ${esc(e.nextDate)}</p>`:''}${e.note?`<p class="preserve-lines"><b>Комментарий:</b> ${esc(e.note)}</p>`:''}</article>`;
}

function drawLegacyPartnerTasks(p){
 const editable=!p.archived&&!!p.nextDate;
 $('#partner-content').innerHTML=`<h3>Следующее действие</h3>${p.nextDate?`<div class="trade-card"><h4>${esc(p.nextAction)}</h4><p>Срок: ${esc(p.nextDate)} (UTC) · ${p.archived?'Поставщик в архиве':partnerTaskStates[p.taskState]}</p></div>`:'<p>Открытой задачи нет. Задайте действие и дату во вкладке «Контакты и заметки».</p>'}${editable?`<div class="partner-grid"><form id="partner-task-complete" class="trade-card"><h4>Зафиксировать выполнение</h4><label class="profile-label">Результат или комментарий<textarea name="note" rows="3" maxlength="1000" placeholder="Например, получена новая спецификация"></textarea></label><p class="profile-muted">При необходимости сразу назначьте следующее действие.</p>${offerInput('nextAction','Следующее действие','','text','maxlength="300"')}${offerInput('nextDate','Следующая дата (UTC)','','date','')}<p class="profile-error" role="alert"></p><button class="primary" type="submit">Отметить выполненным</button></form><form id="partner-task-reschedule" class="trade-card"><h4>Перенести срок</h4>${offerInput('nextDate','Новая дата (UTC)',p.nextDate,'date','required')}<label class="profile-label">Причина переноса<textarea name="note" rows="3" minlength="3" maxlength="1000" required></textarea></label><p class="profile-error" role="alert"></p><button type="submit">Сохранить перенос</button></form></div>`:p.archived?'<p>Для изменения задачи восстановите поставщика из архива.</p>':''}<h3>История задач</h3><p class="profile-muted">История доступна только вам. Выполнение фиксирует вашу отметку, а не подтверждение поставки. События, произошедшие до обновления rc3, автоматически не восстанавливаются.</p><div id="partner-task-history" class="trade-list">${(p.taskEvents||[]).map(taskEventMarkup).join('')||'<p>История пока пуста.</p>'}</div><p id="partner-task-history-error" role="alert" class="profile-error"></p><button id="partner-task-older" ${p.taskBefore?'':'hidden'}>Более ранние события</button>`;
 for(const [id,action] of [['partner-task-complete','complete_task'],['partner-task-reschedule','reschedule_task']]){
  const f=document.getElementById(id);if(!f)continue;
  f.onsubmit=async e=>{e.preventDefault();const b=f.querySelector('button'),error=f.querySelector('[role=alert]');b.disabled=true;error.textContent='';
   try{await changePartner({action,...Object.fromEntries(new FormData(f))});toast(action==='complete_task'?'Выполнение сохранено.':'Срок задачи перенесён.');}
   catch(err){if(f.isConnected)error.textContent=err.message;}finally{b.disabled=false;}
  };
 }
 $('#partner-task-older').onclick=async e=>{
  const b=e.currentTarget,ticket=partnersGeneration; b.disabled=true;$('#partner-task-history-error').textContent='';
  try{const data=await api('/api/partners?id='+encodeURIComponent(p.id)+'&taskBefore='+p.taskBefore);
   if(ticket!==partnersGeneration||partnersSelected!==p.id||partnerTab!=='tasks'||!b.isConnected)return;
   p.taskEvents.push(...data.partner.taskEvents);p.taskBefore=data.partner.taskBefore;
   $('#partner-task-history').insertAdjacentHTML('beforeend',data.partner.taskEvents.map(taskEventMarkup).join(''));b.hidden=!p.taskBefore;
  }catch(err){if(b.isConnected)$('#partner-task-history-error').textContent=err.message;}finally{b.disabled=false;}
 };
}
