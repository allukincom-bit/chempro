async function openTaskRecord(p,kind,id,returnTab='tasks'){
 const host=$('#partner-content'),ticket=++partnersGeneration;
 host.innerHTML='<p role="status">Загружаем связанную запись…</p>';
 try{const data=await api((kind==='delivery'?'/api/deliveries':'/api/delivery-issues')+'?id='+encodeURIComponent(id));if(!host.isConnected||ticket!==partnersGeneration||partnersSelected!==p.id)return;
 const v=kind==='delivery'?data.delivery:data.issue;
 host.innerHTML=`<button id="linked-task-back">← ${returnTab==='documents'?'Документы':'Задачи'}</button><h3>${kind==='delivery'?'Связанная поставка':'Связанное замечание'}</h3>${kind==='delivery'?deliverySummary(v):issueSummary(v)}<p class="profile-muted">Текущее состояние записи. Задача завершается отдельно — закрытие замечания или получение поставки не завершает её автоматически.</p><button id="linked-task-section">Открыть раздел ${kind==='delivery'?'поставок':'замечаний'}</button>`;
 $('#linked-task-back').onclick=()=>{partnerTab=returnTab;loadPartners();};$('#linked-task-section').onclick=()=>{partnerTab=kind==='delivery'?'deliveries':'issues';if(kind==='issue'){issueFocus=id;issueFilter='all';}loadPartners();};
 }catch(err){if(host.isConnected&&ticket===partnersGeneration){host.innerHTML=`<p role="alert">${esc(err.message)}</p><button id="linked-task-back">Назад</button>`;$('#linked-task-back').onclick=()=>{partnerTab=returnTab;loadPartners();};}}
}
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-linked-task-kind]');if(!b)return;
 const pid=partnersSelected,ticket=++partnersGeneration;b.disabled=true;
 try{const data=await api('/api/partners?id='+encodeURIComponent(pid));if(!b.isConnected||ticket!==partnersGeneration||partnersSelected!==pid)return;
 partnerDetail=data.partner;const kind=b.dataset.linkedTaskKind,id=b.dataset.linkedTaskId;
 const target=(kind==='delivery'?partnerDetail.linkDeliveries:partnerDetail.linkIssues).find(v=>v.id===id);if(!target)throw new Error('Запись недоступна.');
 partnerTab='tasks';drawPartner();editSupplierTask(partnerDetail,null,{kind,id,title:target.title});
 }catch(err){if(b.isConnected)toast(err.message);}finally{b.disabled=false;}
});
