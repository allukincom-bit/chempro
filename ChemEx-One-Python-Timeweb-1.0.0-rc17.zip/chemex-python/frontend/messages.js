viewInfo.messages=['Сообщения','Переписка с контрагентами по отправленным запросам.'];
const messagesRenderOther=renderOther;
renderOther=function(view){messagesRenderOther(view);if(view==='messages')loadMessages();};
let messageConversations=[],messageSelected=null,messageQuery='',messageLoadSequence=0,messageThreadSequence=0,messageHistory=[],messageBefore=null;
const messageDrafts=new Map(),messageSending=new Set();
function messageBubbles(){return messageHistory.map(m=>`<article class="chat-bubble ${m.mine?'mine':''}"><small>${m.mine?'Вы':'Контрагент'} · ${esc(new Date(m.createdAt).toLocaleString('ru-RU'))}</small><p class="preserve-lines">${esc(m.body)}</p></article>`).join('');}
async function loadMessages(){
 const seq=++messageLoadSequence;$('#other-content').innerHTML='<div class="dashboard-panel" role="status">Загружаем диалоги…</div>';
 try{const data=await api('/api/messages');if(seq!==messageLoadSequence||window.currentView!=='messages')return;messageConversations=data.conversations;
 if(messageSelected&&!messageConversations.some(r=>r.id===messageSelected))messageSelected=null;
 $('#other-content').innerHTML=`<div class="messages-toolbar"><p class="profile-muted">Сообщения сохраняются на сервере. Чтобы увидеть новые ответы, нажмите «Обновить». Email-уведомления пока не отправляются.</p><button id="refresh-dialogs">Обновить список ↻</button></div>${messageConversations.length?`<div class="messages-layout"><aside class="conversation-panel"><label class="profile-label">Найти диалог<input id="message-search" type="search" value="${esc(messageQuery)}" placeholder="Компания, товар или CAS"></label><div id="conversation-list"></div></aside><section class="dashboard-panel message-panel" id="message-thread"><div class="offers-empty"><h3>Выберите диалог</h3><p>Переписка доступна покупателю и поставщику по отправленному запросу.</p></div></section></div>`:`<div class="dashboard-panel offers-empty"><h3>Диалогов пока нет</h3><p>Отправьте запрос поставщику или получите запрос покупателя. После этого здесь появится переписка.</p><button class="primary" id="messages-requests">Мои запросы →</button></div>`}`;
 $('#refresh-dialogs').onclick=loadMessages;$('#messages-requests')?.addEventListener('click',()=>renderOther('orders'));
 if(!messageConversations.length)return;
 $('#message-search').oninput=e=>{messageQuery=e.target.value;drawConversations();};drawConversations();if(messageSelected)openMessageThread(messageSelected);
 }catch(e){if(seq!==messageLoadSequence||window.currentView!=='messages')return;$('#other-content').innerHTML=`<div class="dashboard-panel"><p role="alert">${esc(e.message)}</p><button id="retry-messages" class="primary">Повторить</button></div>`;$('#retry-messages').onclick=loadMessages;}
}
function drawConversations(){
 const q=messageQuery.trim().toLowerCase(),list=messageConversations.filter(r=>[r.product,r.partner,r.cas].join(' ').toLowerCase().includes(q));
 $('#conversation-list').innerHTML=list.length?list.map(r=>`<button class="conversation-item ${r.id===messageSelected?'active':''}" data-conversation="${esc(r.id)}" ${r.id===messageSelected?'aria-current="true"':''}><b>${esc(r.partner||'Контрагент')}</b><span>${esc(r.product)}</span><small>CAS ${esc(r.cas)} · ${r.messageCount} сообщений</small><small>${esc(requestStatus[r.status]||r.status)}</small></button>`).join(''):'<p>Диалоги не найдены.</p>';
 $$('[data-conversation]').forEach(b=>b.onclick=()=>openMessageThread(b.dataset.conversation));
}
async function openMessageThread(id){
 messageSelected=id;const seq=++messageThreadSequence;drawConversations();$('#message-thread').innerHTML='<p role="status">Загружаем историю…</p>';
 try{const data=await api('/api/messages?requestId='+encodeURIComponent(id));if(seq!==messageThreadSequence||window.currentView!=='messages'||messageSelected!==id||!$('#message-thread'))return;
 messageHistory=data.messages;messageBefore=data.before;drawMessageThread(data.conversation);
 }catch(e){if(seq!==messageThreadSequence||window.currentView!=='messages'||messageSelected!==id||!$('#message-thread'))return;$('#message-thread').innerHTML=`<p role="alert">${esc(e.message)}</p><button id="retry-thread">Повторить</button>`;$('#retry-thread').onclick=()=>openMessageThread(id);}
}
function drawMessageThread(r){
 const draft=messageDrafts.get(r.id)?.body||'',sending=messageSending.has(r.id);
 $('#message-thread').innerHTML=`<div class="offers-toolbar"><div><h3>${esc(r.partner||'Контрагент')}</h3><small>${esc(r.product)} · CAS ${esc(r.cas)}</small></div><button id="refresh-thread">Обновить ↻</button></div>${r.canAddSupplier?`<button class="compare-shortcut" data-partner-add-request="${esc(r.id)}">＋ В мои поставщики</button>`:''}<details class="message-context"><summary>Контекст запроса</summary>${requestRequirements(r)}<p>${esc(r.quantity)} ${esc(r.unit)} · ${esc(r.destination)}</p><p class="preserve-lines">${esc(r.requirements||'Без дополнительных требований')}</p><small>Переписка не изменяет ранее отправленное коммерческое предложение.</small></details><button id="older-messages" ${messageBefore?'':'hidden'}>Загрузить предыдущие сообщения</button><div id="history-error" class="profile-error" role="alert"></div><div id="message-history" class="message-history" role="log" aria-label="История переписки">${messageHistory.length?messageBubbles():'<p class="profile-muted">Сообщений пока нет. Уточните требования или условия поставки.</p>'}</div><form id="message-form"><label class="profile-label" for="message-body">Сообщение контрагенту</label><textarea id="message-body" maxlength="3000" rows="4" required placeholder="Уточните чистоту, упаковку или срок поставки…" ${sending?'disabled':''}>${esc(draft)}</textarea><div id="message-error" class="profile-error" role="alert"></div><div class="profile-footer"><button type="submit" class="primary" ${sending?'disabled':''}>${sending?'Отправляем…':'Отправить сообщение'}</button><small id="message-length">${draft.length} / 3000</small></div></form>`;
 const history=$('#message-history');history.scrollTop=history.scrollHeight;
 $('#refresh-thread').onclick=()=>openMessageThread(r.id);
 $('#message-body').oninput=e=>{messageDrafts.set(r.id,{body:e.target.value,clientId:crypto.randomUUID()});$('#message-length').textContent=e.target.value.length+' / 3000';};
 $('#older-messages').onclick=async e=>{const b=e.target,seq=messageThreadSequence;b.disabled=true;$('#history-error').textContent='';try{const data=await api('/api/messages?requestId='+encodeURIComponent(r.id)+'&before='+messageBefore);if(window.currentView!=='messages'||messageSelected!==r.id||seq!==messageThreadSequence)return;const h=$('#message-history'),oldHeight=h.scrollHeight,oldTop=h.scrollTop;messageHistory=[...data.messages,...messageHistory];messageBefore=data.before;h.innerHTML=messageBubbles();h.scrollTop=oldTop+h.scrollHeight-oldHeight;b.hidden=!messageBefore;}catch(err){if(window.currentView==='messages'&&messageSelected===r.id&&seq===messageThreadSequence)$('#history-error').textContent=err.message;}finally{b.disabled=false;}};
 $('#message-form').onsubmit=async e=>{
  e.preventDefault();if(messageSending.has(r.id))return;const form=e.target,input=form.querySelector('textarea'),b=form.querySelector('[type="submit"]'),body=input.value.trim();
  if(!body){$('#message-error').textContent='Введите текст сообщения.';return;}
  let d=messageDrafts.get(r.id);if(!d||d.body.trim()!==body)d={body,clientId:crypto.randomUUID()};messageDrafts.set(r.id,d);messageSending.add(r.id);input.disabled=true;b.disabled=true;b.textContent='Отправляем…';$('#message-error').textContent='';
  try{await api('/api/messages',{method:'POST',body:{requestId:r.id,clientId:d.clientId,body}});if(messageDrafts.get(r.id)?.clientId===d.clientId)messageDrafts.delete(r.id);toast('Сообщение сохранено в диалоге.');}
  catch(err){if(window.currentView==='messages'&&messageSelected===r.id&&$('#message-error')){$('#message-error').textContent=err.message+' Текст сохранён в форме — можно повторить отправку.';}else toast(err.message);}
  finally{messageSending.delete(r.id);if(window.currentView==='messages'&&messageSelected===r.id&&$('#message-form')){$('#message-body').disabled=false;const currentButton=$('#message-form').querySelector('[type="submit"]');currentButton.disabled=false;currentButton.textContent='Отправить сообщение';}if(!messageDrafts.has(r.id)&&window.currentView==='messages'&&messageSelected===r.id)openMessageThread(r.id);}
 };
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-open-conversation]');if(!b)return;messageSelected=b.dataset.openConversation;renderOther('messages');});
