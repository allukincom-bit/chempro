(() => {
 const sidebar=document.querySelector('#site-navigation'),main=document.querySelector('#main-content');
 const toggle=document.querySelector('#mobile-menu-toggle'),close=document.querySelector('#mobile-menu-close'),backdrop=document.querySelector('#mobile-menu-backdrop');
 const filters=document.querySelector('.filters'),filterToggle=document.querySelector('#mobile-filter-toggle'),details=document.querySelector('#catalog-filter-details');
 const viewport=matchMedia('(max-width:900px)');let opened=false,expanded=false;
 const focusable=()=>[...sidebar.querySelectorAll('button,a[href],input,select,textarea,[tabindex]')].filter(el=>!el.disabled&&!el.hidden&&el.tabIndex!==-1&&el.getClientRects().length);
 function menu(value,restore=true){
  opened=value&&viewport.matches;
  document.body.classList.toggle('mobile-menu-open',opened);toggle.setAttribute('aria-expanded',String(opened));
  backdrop.hidden=!opened;main.inert=opened;sidebar.inert=viewport.matches&&!opened;
  if(viewport.matches){sidebar.setAttribute('aria-hidden',String(!opened));if(opened){sidebar.setAttribute('role','dialog');sidebar.setAttribute('aria-modal','true');}else{sidebar.removeAttribute('role');sidebar.removeAttribute('aria-modal');}}
  else{sidebar.removeAttribute('aria-hidden');sidebar.removeAttribute('role');sidebar.removeAttribute('aria-modal');}
  if(opened)close.focus();else if(restore&&viewport.matches)toggle.focus();
 }
 function filterState(){
  const collapsed=viewport.matches&&!expanded;
  if(collapsed&&details.contains(document.activeElement))filterToggle.focus();
  filters.classList.toggle('filters-expanded',expanded);details.inert=collapsed;
  details.setAttribute('aria-hidden',String(collapsed));filterToggle.setAttribute('aria-expanded',String(!collapsed));
  const count=filters.querySelectorAll('input[type=checkbox]:checked').length+['region-filter','purity-filter'].filter(id=>document.getElementById(id).value).length+(document.getElementById('sort-filter').value==='recommended'?0:1);
  filterToggle.textContent=(expanded?'Скрыть фильтры':'Показать фильтры')+(count?' · '+count:'');
 }
 toggle.addEventListener('click',()=>menu(!opened));close.addEventListener('click',()=>menu(false));backdrop.addEventListener('click',()=>menu(false));
 sidebar.addEventListener('click',e=>{if(opened&&e.target.closest('[data-view],.brand'))menu(false);});
 document.addEventListener('keydown',e=>{
  if(!opened)return;
  if(e.key==='Escape'){e.preventDefault();menu(false);return;}
  if(e.key==='Tab'){const items=focusable(),first=items[0],last=items[items.length-1];if(!first){e.preventDefault();return;}if(e.shiftKey&&(document.activeElement===first||!sidebar.contains(document.activeElement))){e.preventDefault();last.focus();}else if(!e.shiftKey&&(document.activeElement===last||!sidebar.contains(document.activeElement))){e.preventDefault();first.focus();}}
 });
 filterToggle.addEventListener('click',()=>{expanded=!expanded;filterState();});filters.addEventListener('change',filterState);
 for(const id of ['reset-filters','clear-filters','empty-reset'])document.getElementById(id)?.addEventListener('click',()=>queueMicrotask(filterState));
 viewport.addEventListener('change',()=>{const hadFocus=sidebar.contains(document.activeElement);menu(false,false);filterState();if(viewport.matches&&hadFocus)toggle.focus();});
 menu(false,false);filterState();
})();
