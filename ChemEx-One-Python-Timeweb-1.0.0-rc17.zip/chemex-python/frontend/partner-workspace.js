/* All feed items and references are supplied by the owner-scoped API. */
const attentionLabels={supplier_task:'Задача',issue_review:'Проверка замечания',delivery_overdue:'Получение просрочено',terms_expiry:'Срок условий',terms_review:'Проверка условий',task:'Задача',waiting:'Ожидается ответ',quote_expired:'Предложение истекло',quote_expiring:'Предложение заканчивается',document_expired:'Документ истёк',document_expiring:'Документ заканчивается'};
const supplyRoles={none:'Не назначен',primary:'Основной',backup:'Резервный'};
let attentionFilter='all';
const workspaceDrawPartners=drawPartners;
drawPartners=function(){
 workspaceDrawPartners();
 const panel=document.createElement('section');panel.className='dashboard-panel';
 const rows=partnersData.flatMap(p=>(p.attention||[]).map(a=>({...a,partner:p})));
 panel.innerHTML=`<h3>Требует внимания</h3><p class="profile-muted">Предложения — ближайшие 7 дней, документы и условия — 30 дней, включая истёкшие. Ожидание ответа само по себе не означает просрочку. Даты — UTC; срок действия включителен. Архивные поставщики исключены.</p><label class="profile-label">События<select id="attention-filter"><option value="all">Все</option>${Object.entries(attentionLabels).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label><div id="attention-list"></div>`;
 $('#other-content').prepend(panel);$('#attention-filter').value=attentionFilter;
 function draw(){
  const filtered=rows.filter(a=>attentionFilter==='all'||a.kind===attentionFilter).sort((a,b)=>a.date.localeCompare(b.date));
  $('#attention-list').innerHTML=`<p role="status">Событий: ${filtered.length}</p>`+filtered.map(a=>`<article class="trade-card"><b>${esc(a.partner.companyName)}</b><p>${esc(attentionLabels[a.kind])} · ${esc(a.date)}</p><p>${esc(a.title)}</p><button data-attention-partner="${esc(a.partner.id)}" data-kind="${a.kind}" data-target="${esc(a.targetId)}">${a.kind==='supplier_task'?'Открыть задачи':a.kind==='issue_review'?'Открыть замечания':a.kind==='delivery_overdue'?'Открыть поставки':a.kind.startsWith('terms')?'Открыть условия':a.kind==='task'?'Открыть задачу':a.kind.startsWith('document')?'Открыть документ':'Открыть переписку'}</button></article>`).join('');
  panel.querySelectorAll('[data-attention-partner]').forEach(b=>b.onclick=async()=>{
   const kind=b.dataset.kind;
   if(kind==='waiting'||kind.startsWith('quote')){messageSelected=b.dataset.target;renderOther('messages');return;}
   if(kind==='issue_review'){issueFocus=b.dataset.target;issueFilter='all';}
   partnersSelected=b.dataset.attentionPartner;partnerTab=kind==='supplier_task'?'tasks':kind==='issue_review'?'issues':kind==='delivery_overdue'?'deliveries':kind.startsWith('terms')?'terms':kind==='task'?'tasks':'documents';partnerDocumentFocus=kind.startsWith('document')?b.dataset.target:null;partnerDocumentFilter='all';await loadPartners();
  });
 }
 $('#attention-filter').onchange=e=>{attentionFilter=e.target.value;draw();};draw();
};

const workspaceDrawProducts=drawPartnerProducts;
drawPartnerProducts=function(p){
 workspaceDrawProducts(p);
 $('#partner-content').insertAdjacentHTML('afterbegin','<p class="profile-muted">Роль назначается для ChemEx ID. Допустим один основной источник и несколько резервных. Архивирование сохраняет отметку; для переназначения снимите её вручную. Недоступность товара не отменяет ваш выбор автоматически.</p>');
 for(const o of p.products){
  const card=document.querySelector(`[data-partner-unpin="${o.id}"]`)?.closest('article');if(!card)continue;
  const form=document.createElement('form');form.innerHTML=`<label class="profile-label">Роль в снабжении<select name="supplyRole">${Object.entries(supplyRoles).map(([k,v])=>`<option value="${k}" ${(o.supplyRole||'none')===k?'selected':''}>${v}</option>`).join('')}</select></label><button>Сохранить роль</button><p role="alert" class="profile-error"></p>`;
  card.append(form);form.onsubmit=async e=>{e.preventDefault();const b=form.querySelector('button');b.disabled=true;try{await changePartner({action:'supply_role',offerId:o.id,supplyRole:form.elements.supplyRole.value});}catch(err){if(form.isConnected)form.querySelector('[role=alert]').textContent=err.message;}finally{b.disabled=false;}};
 }
};
