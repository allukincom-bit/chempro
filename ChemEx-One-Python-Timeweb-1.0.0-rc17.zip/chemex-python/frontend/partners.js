/* Personal supplier workspace: all persistent data comes from owner-scoped API. */
viewInfo.partners=['Мои поставщики','Постоянные контакты, закреплённое сырьё и повторные закупки.'];
const partnerStatuses={trial:'На испытании',regular:'Постоянный',reserve:'Резервный',paused:'Приостановлен'};
const partnersPreviousRender=renderOther;
let partnersSelected=null,partnersGeneration=0,partnersData=[],partnerDetail=null,partnerTab='overview';
const partnerFilters={q:'',status:'',archive:'active',due:false};
renderOther=function(view){partnersPreviousRender(view);if(view==='partners')loadPartners();else partnersGeneration++;};
const partnerDate=v=>v?new Date(v).toLocaleDateString('ru-RU'):'—';
const partnerBadges=p=>`<div class="partner-badges"><span class="status">${esc(partnerStatuses[p.status])}${p.archived?' · Архив':''}</span><span class="status ${p.approved?'green-status':''}">${p.approved?'Одобрен мной':'Внутреннего одобрения нет'}</span><span class="status ${p.bankConfirmed?'green-status':''}">${p.bankConfirmed?'Расчётный счёт подтверждён':'Счёт не подтверждён'}</span></div>`;

async function loadPartners(){
 const ticket=++partnersGeneration,host=$('#other-content');
 host.innerHTML='<section class="dashboard-panel" role="status">Загружаем поставщиков…</section>';
 try{
  const data=await api('/api/partners'+(partnersSelected?'?id='+encodeURIComponent(partnersSelected):''));
  if(ticket!==partnersGeneration||window.currentView!=='partners')return;
  if(partnersSelected){partnerDetail=data.partner;drawPartner();}
  else{partnersData=data.partners;drawPartners();}
 }catch(e){if(ticket!==partnersGeneration||window.currentView!=='partners')return;
  host.innerHTML=`<section class="dashboard-panel"><p role="alert">${esc(e.message)}</p><button id="partner-retry">Повторить</button> <button id="partner-reset">К списку</button></section>`;
  $('#partner-retry').onclick=loadPartners;$('#partner-reset').onclick=()=>{partnersSelected=null;loadPartners();};
 }
}

function drawPartners(){
 const active=partnersData.filter(p=>!p.archived);
 $('#other-content').innerHTML=`<section class="dashboard-panel"><div class="offers-toolbar"><div><h3>Ваш круг поставщиков</h3><p>${active.length} в работе · ${active.filter(p=>p.actionDue).length} действий на сегодня или ранее</p></div><button id="partners-refresh">Обновить ↻</button></div><p class="profile-muted">Статусы, контакты и заметки доступны только вашему аккаунту. «Одобрен мной» — ваша оценка, а подтверждение счёта — отдельная проверка ChemEx. Оба признака не заменяют проверку качества сырья.</p><div class="compare-filters"><label class="profile-label">Компания, сырьё, CAS, ChemEx ID или метка<input id="partners-search" type="search" value="${esc(partnerFilters.q)}"></label><label class="profile-label">Статус<select id="partners-status"><option value="">Все статусы</option>${Object.entries(partnerStatuses).map(([v,l])=>`<option value="${v}" ${partnerFilters.status===v?'selected':''}>${l}</option>`).join('')}</select></label><label class="profile-label">Список<select id="partners-archive">${[['active','В работе'],['archived','В архиве'],['all','Все']].map(([v,l])=>`<option value="${v}" ${partnerFilters.archive===v?'selected':''}>${l}</option>`).join('')}</select></label></div><label class="compare-check"><input id="partners-due" type="checkbox" ${partnerFilters.due?'checked':''}> Есть действие на сегодня или ранее (UTC)</label><p id="partners-count" role="status"></p><div class="partner-grid">${partnersData.map(p=>`<article class="trade-card" data-partner-row="${esc(p.id)}"><h3>${esc(p.companyName)}</h3><p>${esc(p.country)}</p>${partnerBadges(p)}<p>${p.tags.map(t=>`<span class="partner-tag">${esc(t)}</span>`).join(' ')}</p><p>Закреплено товаров: ${p.products.length} · Отправленных запросов: ${p.requestCount}</p><p>Последнее взаимодействие: ${esc(partnerDate(p.lastInteraction))}</p>${p.nextDate?`<p class="${p.actionDue?'partner-due':''}"><b>${esc(p.nextDate)}</b> · ${esc(p.nextAction)}</p>`:`<p>Открытых задач: ${p.openTaskCount||0} · на сегодня и ранее: ${p.dueTaskCount||0}</p>`}<button class="primary" data-partner-open="${esc(p.id)}">Открыть карточку →</button></article>`).join('')}</div><div id="partners-empty" class="offers-empty" hidden><h3>Поставщики не найдены</h3><p>Добавьте компанию из предложения в каталоге или из отправленного запроса. Для существующих записей проверьте фильтры.</p></div><button id="partners-catalog">Найти поставщика в каталоге →</button></section>`;
 $('#partners-refresh').onclick=loadPartners;$('#partners-catalog').onclick=()=>renderOther('market');
 $('#partners-search').oninput=e=>{partnerFilters.q=e.target.value;filterPartners();};
 $('#partners-status').onchange=e=>{partnerFilters.status=e.target.value;filterPartners();};
 $('#partners-archive').onchange=e=>{partnerFilters.archive=e.target.value;filterPartners();};
 $('#partners-due').onchange=e=>{partnerFilters.due=e.target.checked;filterPartners();};
 $$('[data-partner-open]').forEach(b=>b.onclick=()=>{partnersSelected=b.dataset.partnerOpen;partnerTab='overview';loadPartners();});
 filterPartners();
}

function filterPartners(){
 const q=partnerFilters.q.trim().toLocaleLowerCase('ru');let count=0;
 for(const p of partnersData){
  const text=[p.companyName,p.country,p.contactName,...p.tags,...p.products.flatMap(o=>[o.name,o.cas,o.chemexId,o.manufacturer,o.grade])].join(' ').toLocaleLowerCase('ru');
  const show=(!q||text.includes(q))&&(!partnerFilters.status||p.status===partnerFilters.status)&&(partnerFilters.archive==='all'||p.archived===(partnerFilters.archive==='archived'))&&(!partnerFilters.due||p.actionDue);
  const row=document.querySelector(`[data-partner-row="${p.id}"]`);if(row)row.hidden=!show;if(show)count++;
 }
 $('#partners-count').textContent=`Показано ${count} из ${partnersData.length}`;$('#partners-empty').hidden=count>0;
}

function partnerFields(p){
 return `<label class="profile-label">Статус<select name="status">${Object.entries(partnerStatuses).map(([v,l])=>`<option value="${v}" ${p.status===v?'selected':''}>${l}</option>`).join('')}</select></label><label class="compare-check"><input name="approved" type="checkbox" ${p.approved?'checked':''}> Я одобряю этого поставщика для работы</label><p class="profile-muted">Личная отметка. Не публикуется и не изменяет банковскую проверку.${p.approvedAt?' Отмечено '+esc(partnerDate(p.approvedAt))+'.':''}</p><label class="profile-label">Метки через запятую (до 10)<input name="tags" maxlength="409" value="${esc(p.tags.join(', '))}" placeholder="Растворители, отсрочка, резерв"></label><div class="profile-fields">${offerInput('contactName','Ваш контакт у поставщика',p.contactName,'text','maxlength="120"')}${offerInput('contactEmail','Email контакта',p.contactEmail,'email','maxlength="254"')}${offerInput('contactPhone','Телефон контакта',p.contactPhone,'text','maxlength="60"')}</div><label class="profile-label">Личные заметки<textarea name="notes" rows="5" maxlength="4000">${esc(p.notes)}</textarea></label><input type="hidden" name="nextAction" value="${esc(p.nextAction)}"><input type="hidden" name="nextDate" value="${esc(p.nextDate)}"><p class="profile-muted">Планируйте действия во вкладке «Задачи и история».</p>`;
}

function drawPartner(){
 const p=partnerDetail;
 $('#other-content').innerHTML=`<section class="dashboard-panel"><div class="offers-toolbar"><button id="partner-back">← Мои поставщики</button><button id="partner-refresh">Обновить карточку</button></div><h2>${esc(p.companyName)}</h2><p>${esc(p.country)}</p>${partnerBadges(p)}${p.publicationRestricted?'<p class="compare-warning">Публикации компании приостановлены площадкой. История сотрудничества сохранена.</p>':''}<nav class="admin-tabs" aria-label="Карточка поставщика">${[['overview','Контакты и заметки'],['terms','Условия сотрудничества'],['products','Наше сырьё'],['history','Запросы и предложения'],['issues','Замечания'],['deliveries','Поставки'],['tasks','Задачи и история'],['documents','Договоры и файлы']].map(([v,l])=>`<button data-partner-tab="${v}" aria-current="${partnerTab===v?'page':'false'}">${l}</button>`).join('')}</nav><div id="partner-content"></div></section>`;
 $('#partner-back').onclick=()=>{partnersSelected=null;loadPartners();};$('#partner-refresh').onclick=loadPartners;
 $$('[data-partner-tab]').forEach(b=>b.onclick=()=>{partnerTab=b.dataset.partnerTab;drawPartner();});
 if(partnerTab==='overview'){
  $('#partner-content').innerHTML=`<form id="partner-edit">${partnerFields(p)}<p id="partner-edit-error" class="profile-error" role="alert"></p><div class="profile-footer"><button class="primary" type="submit">Сохранить изменения</button><button type="button" id="partner-archive">${p.archived?'Восстановить из архива':'Перенести в архив'}</button></div><p class="profile-muted">Архивирование сохраняет историю. Новые запросы из этой карточки будут недоступны до восстановления.</p></form>`;
  $('#partner-edit').onsubmit=async e=>{e.preventDefault();const f=e.target,b=f.querySelector('[type=submit]'),d=Object.fromEntries(new FormData(f));d.tags=d.tags.split(',').map(s=>s.trim()).filter(Boolean);d.approved=f.elements.approved.checked;d.archived=p.archived;b.disabled=true;
   try{await changePartner({action:'update',...d});toast('Карточка сохранена.');}catch(err){if(f.isConnected)$('#partner-edit-error').textContent=err.message;}finally{b.disabled=false;}
  };
  $('#partner-archive').onclick=async e=>{if(!confirm(`${p.archived?'Восстановить поставщика':'Перенести в архив'}? Несохранённые изменения формы не будут применены.`))return;const b=e.currentTarget;b.disabled=true;try{await changePartner({action:'update',...partnerEditable(p),archived:!p.archived});}catch(err){toast(err.message);b.disabled=false;}};
 }else if(partnerTab==='terms')drawPartnerTerms(p);else if(partnerTab==='products')drawPartnerProducts(p);else if(partnerTab==='issues')drawDeliveryIssues(p);else if(partnerTab==='deliveries')drawPartnerDeliveries(p);else if(partnerTab==='tasks')drawPartnerTasks(p);else if(partnerTab==='documents')drawPartnerDocuments(p);else drawPartnerHistory(p);
}

function partnerEditable(p){return Object.fromEntries(['status','approved','archived','tags','contactName','contactEmail','contactPhone','notes','nextAction','nextDate'].map(k=>[k,p[k]]));}
async function changePartner(body){
 const p=partnerDetail,ticket=partnersGeneration;
 const data=await api('/api/partners',{method:'POST',body:{...body,id:p.id,revision:p.revision}});
 if(window.currentView==='partners'&&partnersSelected===p.id&&ticket===partnersGeneration){partnerDetail=data.partner;drawPartner();}
 return data;
}

function productIdentity(o){return `<p>CAS ${esc(o.cas)} · ChemEx ID ${esc(o.chemexId||'не указан')}</p><p>${esc(o.manufacturer)} · ${esc(o.grade)}</p>`;}
function drawPartnerProducts(p){
 const canRequest=!p.archived&&p.status!=='paused';
 $('#partner-content').innerHTML=`<p>Закрепляйте предложения этого поставщика. ChemEx ID относится к продукту производителя; один продукт может продаваться несколькими компаниями.</p><div class="partner-grid">${p.products.map(o=>`<article class="trade-card"><h3>${esc(o.name)}</h3>${productIdentity(o)}${!o.available?'<p class="partner-due">Предложение недоступно</p>':o.identityChanged?'<p class="partner-due">Производитель, марка или CAS изменились. Выберите актуальное предложение ниже и закрепите заново.</p>':''}<div class="profile-footer"><button data-partner-request="${o.id}" ${!canRequest||!o.available||o.identityChanged?'disabled':''}>Запросить цену</button><button data-partner-unpin="${o.id}">Открепить</button></div></article>`).join('')||'<p>Закреплённых товаров пока нет.</p>'}</div><h3>Действующие предложения компании</h3>${p.availableProducts.length?`<form id="partner-pin"><label class="profile-label">Товар<select name="offerId">${p.availableProducts.map(o=>`<option value="${o.id}">${esc(o.name)} · ${esc(o.grade)} · ${esc(o.chemexId)}</option>`).join('')}</select></label><button type="submit" ${p.archived?'disabled':''}>Закрепить актуальную карточку</button><p class="profile-error" role="alert" id="partner-pin-error"></p></form>`:'<p>Сейчас нет доступных предложений. История и ранее закреплённые карточки сохранены.</p>'}`;
 $('#partner-pin')?.addEventListener('submit',async e=>{e.preventDefault();const f=e.target,b=f.querySelector('button');b.disabled=true;try{await changePartner({action:'pin',offerId:Number(f.elements.offerId.value)});}catch(err){if(f.isConnected)$('#partner-pin-error').textContent=err.message;b.disabled=false;}});
 $$('[data-partner-unpin]').forEach(b=>b.onclick=async()=>{b.disabled=true;try{await changePartner({action:'unpin',offerId:Number(b.dataset.partnerUnpin)});}catch(e){toast(e.message);b.disabled=false;}});
 $$('[data-partner-request]').forEach(b=>b.onclick=()=>drawPartnerRfq(p.availableProducts.find(o=>o.id===Number(b.dataset.partnerRequest)),null));
}

function drawPartnerHistory(p){
 $('#partner-content').innerHTML=`<p>Здесь только ваши отправленные запросы этой компании. Прошлые цены сохраняются как история и не считаются действующими автоматически.</p><div class="trade-list">${p.history.map(r=>{
  const o=p.availableProducts.find(o=>o.id===r.productId-100000),same=o&&r.chemexId&&o.chemexId===r.chemexId&&o.cas===r.cas;
  return `<article class="trade-card"><h3>${esc(r.product)}</h3><p>${esc(r.quantity)} ${esc(r.unit)} · ${esc(r.destination)} · ${esc(partnerDate(r.sentAt))}</p>${requestRequirements(r)}${quoteMarkup(r)}<div class="profile-footer"><button class="primary" data-partner-repeat="${esc(r.id)}" ${!same||p.archived||p.status==='paused'?'disabled':''}>Повторить запрос</button><button data-open-conversation="${esc(r.id)}">Открыть переписку</button></div>${!same?'<p class="profile-muted">Для повтора выберите действующее предложение во вкладке «Наше сырьё»: товар недоступен, изменился или прежний ChemEx ID не сохранён.</p>':''}</article>`;
 }).join('')||'<p>Отправленных запросов пока нет. Выберите закреплённый товар и запросите условия.</p>'}</div>`;
 $$('[data-partner-repeat]').forEach(b=>b.onclick=()=>{const r=p.history.find(r=>r.id===b.dataset.partnerRepeat);drawPartnerRfq(p.availableProducts.find(o=>o.id===r.productId-100000),r);});
}

function drawPartnerRfq(o,source){
 if(!o)return;const p=partnerDetail,r=source||{},draftId=source?.id;
 $('#partner-content').innerHTML=`<h3>${source?'Повторный запрос':'Запрос цены'}: ${esc(o.name)}</h3>${productIdentity(o)}<p>Проверьте данные. Сначала создаётся личный черновик; отправка поставщику выполняется отдельно в «Моих запросах». Прошлая цена не переносится.</p><form id="partner-rfq"><div class="profile-fields">${offerInput('quantity','Количество',r.quantity||'','number','required min="0.001" max="999999999" step="0.001"')}${offerSelect('unit','Единица',['кг','т','л','шт.'],r.unit||'кг')}${offerInput('destination','Место поставки',r.destination||'','text','required minlength="2" maxlength="150"')}${offerInput('email','Ваш рабочий email',r.email||account?.profile?.contactEmail||'','email','required maxlength="254"')}</div><label class="profile-label">Требования к сырью<textarea name="specification" maxlength="2000" rows="3">${esc(r.specification||'')}</textarea></label><fieldset><legend>Нужные документы</legend>${['SDS','TDS','COA'].map(t=>`<label class="compare-check"><input name="requestedDocuments" type="checkbox" value="${t}" ${(r.requestedDocuments||[]).includes(t)?'checked':''}> ${t}</label>`).join('')}</fieldset><label class="profile-label">Дополнительные условия<textarea name="message" maxlength="3000" rows="3">${esc(r.message||'')}</textarea></label><p id="partner-rfq-error" class="profile-error" role="alert"></p><div class="profile-footer"><button class="primary" type="submit">Создать черновик</button><button id="partner-rfq-cancel" type="button">Отмена</button></div></form>`;
 $('#partner-rfq-cancel').onclick=()=>{if(confirm('Закрыть форму без сохранения?'))drawPartner();};
 $('#partner-rfq').onsubmit=async e=>{e.preventDefault();const f=e.target,b=f.querySelector('[type=submit]'),body=Object.fromEntries(new FormData(f));body.requestedDocuments=[...f.querySelectorAll('[name=requestedDocuments]:checked')].map(el=>el.value);b.disabled=true;
  try{const data=await api('/api/partners',{method:'POST',body:{...body,action:'repeat',id:p.id,revision:p.revision,offerId:o.id,...(draftId?{requestId:draftId}:{}),expectedChemexId:o.chemexId,expectedCas:o.cas}});
   toast('Черновик создан. Проверьте и отправьте его в «Моих запросах».');
   if(f.isConnected){requests.unshift(data.request);$('#request-count').textContent=requests.length;renderOther('orders');}
  }catch(err){if(f.isConnected)$('#partner-rfq-error').textContent=err.message;b.disabled=false;}
 };
}

document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-partner-add-product],[data-partner-add-request]');if(!b)return;
 b.disabled=true;
 try{const data=await api('/api/partners',{method:'POST',body:{action:'add',...(b.dataset.partnerAddProduct?{productId:Number(b.dataset.partnerAddProduct)}:{requestId:b.dataset.partnerAddRequest})}});
  toast(data.existing?'Компания уже в вашем списке.':'Поставщик добавлен в ваш список.');
  if(b.isConnected){partnersSelected=data.partner.id;partnerTab='overview';renderOther('partners');}
 }catch(err){toast(err.message);}finally{b.disabled=false;}
});
