(function(root){
 'use strict';
 function quoteExpiry(r,today=new Date().toISOString().slice(0,10)){
  if(r.status!=='quoted')return {state:'none',days:null};
  try{
   const q=JSON.parse(r.quotation),date=q?.validUntil;
   if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date))return {state:'unknown',days:null};
   const end=new Date(date+'T00:00:00Z'),now=new Date(today+'T00:00:00Z');
   if(!Number.isFinite(+end)||!Number.isFinite(+now)||end.toISOString().slice(0,10)!==date)return {state:'unknown',days:null};
   const days=Math.round((end-now)/86400000);
   return {state:days<0?'expired':days<=7?'expiring':'active',days};
  }catch{return {state:'unknown',days:null};}
 }
 function matchesStatus(r,status,today){
  if(!status)return true;
  if(status==='quote_expiring')return quoteExpiry(r,today).state==='expiring';
  if(status==='quote_expired')return quoteExpiry(r,today).state==='expired';
  if(status==='quote_active')return ['active','expiring'].includes(quoteExpiry(r,today).state);
  return r.status===status;
 }
 function filter(items,{query='',status=''}={},inbox=false,today){
  const q=query.trim().toLocaleLowerCase('ru-RU');
  return items.filter(r=>matchesStatus(r,status,today)&&(!q||[r.product,r.cas,r.chemexId,r.manufacturer,r.grade,inbox?r.buyerCompany:r.supplierCompany,r.destination,r.id].join(' ').toLocaleLowerCase('ru-RU').includes(q)));
 }
 root.ChemexTrade={filter,quoteExpiry,matchesStatus};
})(globalThis);
