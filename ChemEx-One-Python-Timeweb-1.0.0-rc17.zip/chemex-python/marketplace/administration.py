from decimal import Decimal
from .core import *

def prepare_reference(d, i=None):
    p = {k:textfield(d,k,1,160) for k in ['name','grade','category','sourceName']}
    p.update(manufacturer=textfield(d,'manufacturer',0,160),cas=textfield(d,'cas',0,20),
        sourceUrl=urlfield(textfield(d,'sourceUrl',1,1500)),note=textfield(d,'note',10,2000),
        applications=textfield(d,'applications',0,1000),originCountry=textfield(d,'originCountry',0,100),
        checkedAt=datefield(textfield(d,'checkedAt',10,10)),documents=documents(d.get('documents',[])))
    if p['cas']: cas(p['cas'])
    if p['checkedAt']>today(): fail(400,'Дата проверки не может быть в будущем.')
    key = digest([norm(p['manufacturer']),norm(p['grade'])] if p['manufacturer'] else [p['sourceUrl'],norm(p['name']),norm(p['grade'])])
    p.update(sourceRecordId=i or 'IMP-'+key,identityKey=key,chemexId=chemex(p['manufacturer'],p['grade'],p['cas']))
    p['searchText'] = norm(' '.join(p.get(k) or '' for k in ['name','cas','manufacturer','grade','category','sourceName','note','applications','chemexId']))
    return p

def reference_api(req,d):
    if req.method=='GET':
        page = pageparam(req.GET,'page',1,100000); limit = pageparam(req.GET,'limit',12,100)
        q = norm(textfield(req.GET.dict(),'q',0,200)); keys = ['category','manufacturer','sourceName','originCountry']
        all_ = [p for p in records('reference') if not hidden('reference',p['sourceRecordId'])]
        facets = {k:sorted(set(p.get(k,'') for p in all_) - {''}) for k in keys}
        rows = [p for p in all_ if (not q or q in p['searchText']) and all(not req.GET.get(k) or req.GET[k]==p.get(k) for k in keys) and (req.GET.get('documents')!='1' or p['documents'])]
        rows.sort(key=lambda p:p['sourceRecordId'])
        out = [{k:v for k,v in p.items() if k not in ['identityKey','searchText','reviewedBy']} for p in rows[(page-1)*limit:page*limit]]
        return {'products':out,'total':len(rows),'catalogTotal':len(all_),'page':page,'limit':limit,'checkedAt':max([p['checkedAt'] for p in all_],default=None),'facets':facets}
    if req.method!='POST': fail(405,'Метод не поддерживается.')
    u = admin(req); action = choice(d,'action',['preview','commit']); raw = d.get('products')
    if d.get('reviewed') is not True or not isinstance(raw,list) or not 1<=len(raw)<=10: fail(400,'Пакет должен содержать 1–10 проверенных записей.')
    existing = {p['identityKey']:p['sourceRecordId'] for p in records('reference')}; results = []; fresh = inserted = 0
    for r in raw:
        p = prepare_reference(r); dup = p['identityKey'] in existing; i = existing.get(p['identityKey'],p['sourceRecordId']); status = 'duplicate' if dup else 'new'
        if not dup:
            fresh += 1; existing[p['identityKey']] = i
            if action=='commit':
                p['reviewedBy'] = u['email']; putrec('reference',i,p,related=p['identityKey'])
                event(u['email'],'reference_import',i,p['name']+' · '+p['sourceName']); inserted += 1; status='inserted'
        results.append({'name':p['name'],'grade':p['grade'],'status':status,'sourceRecordId':i,'chemexId':p['chemexId']})
    return {'action':action,'results':results,'newCount':fresh,'duplicates':len(results)-fresh,'inserted':inserted}

def payment_settings():
    s = getrec('settings','verification_payment')
    if s: s.pop('_reviewer',None)
    return s

def verification_api(req,d):
    u = user(req); uid = u['userId']
    if req.method=='GET':
        all_ = req.GET.get('admin')=='1'
        if all_: admin(req)
        rows = sorted(records('verification',None if all_ else uid),key=lambda r:r['id'],reverse=True); p = getrec('profile',uid)
        confirmed = bool(p and any(r['userId']==uid and r['status']=='bank_confirmed' and r['fingerprint']==fingerprint(p) for r in rows))
        return {'settings':payment_settings(),'applications':rows,'confirmed':confirmed}
    if req.method!='POST': fail(405,'Метод не поддерживается.')
    action = choice(d,'action',['settings','apply','approve','reject'])
    if action=='settings':
        a = admin(req); s = obj(d.get('settings'))
        if type(s.get('enabled')) is not bool: fail(400,'Проверьте настройки.')
        v = {k:textfield(s,k,lo,hi) for k,lo,hi in [('beneficiary',2,200),('registration',2,100),('bank',2,200),('account',5,100),('bankCode',3,100),('terms',10,2000)]}
        v.update(enabled=s['enabled'],amount=numberstr(s,'amount',7,2),currency=choice(s,'currency',['RUB','EUR','USD']))
        putrec('settings','verification_payment',v); event(a['email'],'payment_settings','verification_payment','Приём платежей: '+('включён' if v['enabled'] else 'выключен'))
        return {'ok':True}
    if action=='apply':
        if d.get('consent') is not True: fail(400,'Подтвердите согласие с условиями.')
        s = payment_settings() or {}
        if not s.get('enabled'): fail(409,'Приём проверочных платежей не настроен.')
        p = profile(uid)
        if not p['registrationNumber']: fail(409,'Заполните регистрационный номер компании.')
        fp = fingerprint(p)
        for r in records('verification',uid):
            if r['fingerprint']==fp and r['status'] in ['pending','bank_confirmed']: return {'application':r}
        r = {'id':nextid('verification'),'userId':uid,**{k:p[k] for k in ['companyName','registrationNumber','country']},
            'fingerprint':fp,'status':'pending','paymentTerms':encode(s),'purpose':'CHEMEX-VERIFY-'+str(uuid.uuid4()),
            'bankReference':None,'payerName':None,'payerRegistration':None,'reviewer':None,'reviewedAt':None,'note':'','createdAt':stamp()}
        putrec('verification',r['id'],r,uid,status='pending'); return {'application':r}
    a = admin(req); i = positive(d.get('id')); r = getrec('verification',i)
    if not r: fail(404,'Заявка не найдена.')
    note = textfield(d,'note',3,2000)
    if action=='reject':
        if r['status'] not in ['pending','bank_confirmed']: fail(409,'Заявка уже закрыта.')
        r['status']='rejected'
    else:
        if r['status']!='pending': fail(409,'Заявка уже обработана.')
        p = getrec('profile',r['userId'])
        if not p or fingerprint(p)!=r['fingerprint']: fail(409,'Реквизиты изменились. Нужна новая заявка.')
        s = json.loads(r['paymentTerms']); bank = norm(textfield(d,'bankReference',1,160)); payer = textfield(d,'payerName',1,200); reg = textfield(d,'payerRegistration',1,100)
        if d.get('statementChecked') is not True or norm(payer)!=norm(r['companyName']) or norm(reg)!=norm(r['registrationNumber']) or Decimal(numberstr(d,'amount',7,2))!=Decimal(s['amount']) or d.get('currency')!=s['currency'] or d.get('purpose')!=r['purpose']: fail(400,'Сверьте плательщика, ИНН, сумму, валюту и назначение по выписке.')
        key = hashlib.sha256(bank.encode()).hexdigest()
        if getrec('bank_reference',key): fail(409,'Банковская операция уже использована.')
        putrec('bank_reference',key,{'applicationId':i})
        r.update(status='bank_confirmed',bankReference=bank,payerName=payer,payerRegistration=reg)
    r.update(reviewer=a['email'],reviewedAt=stamp(),note=note)
    putrec('verification',i,r,r['userId'],status=r['status']); event(a['email'],'verification_'+r['status'],i,note)
    return {'ok':True}

def admin_api(req,d):
    a = admin(req)
    if req.method=='POST':
        scope = choice(d,'scope',['company','offer','reference']); i = textfield(d,'id',1,160)
        if scope=='offer':
            if not re.fullmatch('[0-9]+',i) or int(i)<1: fail(400,'Некорректное предложение.')
            i = str(int(i))
        if scope=='company' and i==a['userId']: fail(400,'Нельзя ограничить собственную компанию.')
        if type(d.get('hidden')) is not bool or type(d.get('revision')) is not int or d['revision']<0: fail(400,'Некорректное действие.')
        reason = textfield(d,'reason',5,1000)
        if not getrec('profile' if scope=='company' else scope,i): fail(404,'Объект не найден.')
        old = mod(scope,i)
        if old.get('revision',0)!=d['revision']: fail(409,'Решение изменилось. Обновите список.')
        if bool(old.get('hidden'))==d['hidden']: return {'ok':True,'unchanged':True}
        key = f'{scope}:{i}'; m = {'key':key,'scope':scope,'targetId':i,'hidden':int(d['hidden']),'reason':reason,'actor':a['email'],'revision':d['revision']+1,'updatedAt':stamp()}
        putrec('moderation',key,m); event(a['email'],'hide' if d['hidden'] else 'restore',key,reason)
        return {'ok':True}
    if req.method!='GET': fail(405,'Метод не поддерживается.')
    section = req.GET.get('section','overview')
    if section=='overview':
        p,o,r,v = [records(k) for k in ['profile','offer','reference','verification']]
        return {'counts':{'companies':len(p),'companiesVisible':sum(not hidden('company',x['userId']) for x in p),
            'offers':len(o),'published':sum(visible(x) for x in o),'reference':sum(not hidden('reference',x['sourceRecordId']) for x in r),
            'pending':sum(x['status']=='pending' for x in v),'requests':len(records('request'))},
            'paymentsEnabled':(payment_settings() or {}).get('enabled',False),'actor':a['email'],
            'events':sorted(records('audit'),key=lambda x:x['id'],reverse=True)[:6]}
    mapping = {'companies':('profile','company'),'offers':('offer','offer'),'reference':('reference','reference'),'audit':('audit','')}
    if section not in mapping: fail(400,'Неизвестный раздел.')
    kind,scope = mapping[section]; page = pageparam(req.GET,'page',1,10000); q = norm(textfield(req.GET.dict(),'q',0,160))
    filt = choice(req.GET.dict(),'status',['all','hidden','visible'],'all'); items = []
    for r in records(kind):
        if kind=='profile':
            i=r['userId']; v={'id':i,'name':r['companyName'],'country':r['country'],'registration':r['registrationNumber'],**{k:r[k] for k in ['role','contactName','contactEmail','createdAt']}}
        elif kind=='offer':
            i=r['id']; p=getrec('profile',r['userId']) or {}; v={k:r.get(k,'') for k in ['id','name','cas','manufacturer','grade','chemexId','status','description','updatedAt']}
            v.update(owner=p.get('companyName',''),companyHidden=int(hidden('company',r['userId'])),documents=encode(r['documents']))
        elif kind=='reference':
            i=r['sourceRecordId']; v={k:x for k,x in r.items() if k not in ['identityKey','searchText','reviewedBy']}; v.update(id=i,documents=encode(r['documents']))
        else: i=r['id']; v=r
        if scope:
            m=mod(scope,i); v.update(hidden=m.get('hidden',0),revision=m.get('revision',0),reason=m.get('reason',''))
            if filt!='all' and bool(v['hidden'])!=(filt=='hidden'): continue
        if q and not all(t in norm(encode(v)) for t in q.split()): continue
        items.append(v)
    items.sort(key=lambda x:x['id'],reverse=True)
    return {'items':items[(page-1)*20:page*20],'total':len(items),'page':page,'limit':20}
