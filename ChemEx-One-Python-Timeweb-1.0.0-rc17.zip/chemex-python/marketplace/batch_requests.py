"""Atomic, idempotent creation of individual PRIVATE RFQ drafts."""
from .core import *
from .market import requests_api


def batch_requests(req,uid,d):
    from .partners import owned, supplier_offer
    token=uuidfield(d,'clientId');key=uid+':'+token
    payload={k:v for k,v in d.items() if k!='clientId'}
    digest=hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    previous=getrec('request_batch',key)
    if previous:
        if previous['digest']!=digest: fail(409,'Этот пакет уже обработан с другими данными. Откройте «Мои запросы».')
        rows=[getrec('request',i) for i in previous['requestIds']]
        return {'requests':[q for q in rows if q and q['userId']==uid],'batchId':token,'replayed':True,'missingCount':sum(q is None for q in rows)}
    targets=d.get('targets')
    if not isinstance(targets,list) or not 2<=len(targets)<=10: fail(400,'Выберите от 2 до 10 разных поставщиков.')
    expected=obj(d.get('identity'));identity=tuple(textfield(expected,k,1 if k=='chemexId' else 0,200) for k in ['chemexId','cas','manufacturer','grade'])
    checked=[];suppliers=set()
    for target in targets:
        target=obj(target);r=owned(uid,uuidfield(target,'partnerId'));i=positive(target.get('offerId'))
        if r['archived'] or r['status']=='paused':fail(409,'Работа с одним из поставщиков приостановлена. Обновите таблицу.')
        if type(target.get('revision')) is not int or target['revision']!=r['revision']:fail(409,'Карточка поставщика изменилась. Обновите таблицу.')
        if r['supplierId'] in suppliers:fail(400,'Выберите только одно предложение каждой компании.')
        suppliers.add(r['supplierId']);o=supplier_offer(r['supplierId'],i)
        pin=next((p for p in r['products'] if p['id']==i),None)
        if not pin or any(tuple(x.get(k) or '' for k in ['chemexId','cas','manufacturer','grade'])!=identity for x in [pin,o]):
            fail(409,'Состав или идентичность сырья изменились. Обновите таблицу; черновики не созданы.')
        checked.append((r,o))
    result=[]
    for r,o in checked:
        body={k:d[k] for k in ['quantity','unit','destination','email','message','specification','requestedDocuments'] if k in d}
        body['productId']=100000+o['id'];q=requests_api(req,body)['request']
        q.update(partnerId=r['id'],sourceRequestId=None,batchId=token,batchSupplierName=profile(r['supplierId'])['companyName'])
        putrec('request',q['id'],q,uid,status='draft');result.append(q)
    from .batch_tracking import FIELDS
    putrec('request_batch',key,{'digest':digest,'requestIds':[q['id'] for q in result],'createdAt':stamp(),
        'common':{k:result[0].get(k) for k in FIELDS},
        'members':[{'requestId':q['id'],'companyName':q['batchSupplierName']} for q in result]},uid)
    return {'requests':result,'batchId':token,'replayed':False,'missingCount':0}
