"""Owner-only progress for grouped RFQ drafts, including deleted members."""
from .core import *
from .supply_matrix import quote_state

FIELDS=['product','chemexId','cas','manufacturer','grade','quantity','unit','destination','specification','requestedDocuments','message']


def present_batch(uid,token,batch,detail=False):
    members=[];counts={'draft':0,'sent':0,'quoted':0,'missing':0};dates={'dated':0,'expired':0,'unknown':0}
    saved={m['requestId']:m for m in batch.get('members',[])}
    common=batch.get('common')
    for i in batch['requestIds']:
        q=getrec('request',i)
        if not q or q.get('userId')!=uid or q.get('batchId')!=token:q=None
        if q and common is None:common={k:q.get(k) for k in FIELDS}
        status=q['status'] if q and q['status'] in ['draft','sent','quoted'] else 'missing'
        counts[status]+=1
        state=quote_state(q) if status=='quoted' else 'none'
        if status=='quoted':dates[state]+=1
        if detail:
            members.append({'requestId':i,'companyName':saved.get(i,{}).get('companyName') or (q or {}).get('batchSupplierName') or (q or {}).get('supplierCompany') or 'Название не сохранено',
                'status':status,'quoteState':state,'request':q})
    total=len(batch['requestIds']);sent=counts['sent']+counts['quoted']
    out={'id':token,'createdAt':batch['createdAt'],'common':common,'counts':counts,'total':total,'sentCount':sent,
         'quoteDates':dates,'allAnswered':bool(total and counts['quoted']==total)}
    if detail:out['members']=members
    return out


def batch_tracking(req,uid):
    token=req.GET.get('batchId')
    if token:
        token=uuidfield(req.GET.dict(),'batchId');batch=getrec('request_batch',uid+':'+token)
        if not batch:fail(404,'Пакет не найден.')
        return {'batch':present_batch(uid,token,batch,True)}
    rows=Record.objects.filter(kind='request_batch',owner=uid).values_list('key','payload')
    batches=[present_batch(uid,key.split(':',1)[1],payload) for key,payload in rows]
    return {'batches':sorted(batches,key=lambda b:(b['createdAt'],b['id']),reverse=True),'generatedAt':stamp()}
