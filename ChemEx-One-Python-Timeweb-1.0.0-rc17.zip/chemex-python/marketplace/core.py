"""Shared API contract and PHP-compatible identifiers. All writes hold write_lock."""
import hashlib
import json
import re
import unicodedata
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone, date
from urllib.parse import urlsplit, parse_qs
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import validate_email, URLValidator
from django.db import transaction
from .models import Account, Record, Counter

class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message

def fail(status, message):
    raise APIError(status, message)

def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def norm(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', value)).strip().lower()

def digest(values):
    return hashlib.sha256(encode(values).encode()).hexdigest()

def chemex(manufacturer, grade, cas):
    return 'CX-' + digest([norm(manufacturer), norm(grade), cas.strip()])[:32].upper() if manufacturer.strip() and grade.strip() else None

def fingerprint(p):
    return digest([norm(p[k]) for k in ('companyName', 'country', 'registrationNumber')])

def getrec(kind, key):
    return Record.objects.filter(kind=kind, key=str(key)).values_list('payload', flat=True).first()

def records(kind, owner=None, related=None):
    q = Record.objects.filter(kind=kind)
    if owner is not None: q = q.filter(owner=str(owner))
    if related is not None: q = q.filter(related=str(related))
    return list(q.values_list('payload', flat=True))

def putrec(kind, key, data, owner='', related='', status=''):
    Record.objects.update_or_create(kind=kind, key=str(key), defaults={'payload': data, 'owner': str(owner or ''), 'related': str(related or ''), 'status': status})

def nextid(kind):
    c, _ = Counter.objects.get_or_create(name=kind)
    c.value += 1
    c.save(update_fields=['value'])
    return c.value

@contextmanager
def write_transaction():
    with transaction.atomic():
        if not Counter.objects.select_for_update().filter(name='write_lock').exists():
            fail(503, 'Выполните миграции базы данных.')
        yield

def event(actor, action, target, detail):
    i = nextid('audit')
    putrec('audit', i, {'id': i, 'actor': actor, 'action': action, 'target': str(target), 'detail': detail, 'createdAt': stamp()})

def user(request, required=True):
    uid = request.session.get('uid')
    u = Account.objects.filter(id=uid).first() if uid else None
    if not u or u.session_version != request.session.get('version'):
        if uid: request.session.flush()
        if required: fail(401, 'Войдите в аккаунт.')
        return None
    return {'userId': str(u.id), 'email': u.email, 'displayName': u.display_name, 'admin': u.is_admin}

def admin(request):
    u = user(request)
    if not u['admin']: fail(403, 'Доступ только суперадминистратору.')
    return u

def obj(d):
    if not isinstance(d, dict): fail(400, 'Ожидается объект.')
    return d

def textfield(d, key, minimum=0, maximum=160, default=''):
    value = obj(d).get(key, default)
    if not isinstance(value, str): fail(400, 'Некорректное поле: ' + key)
    value = value.strip()
    if not minimum <= len(value) <= maximum: fail(400, 'Проверьте поле: ' + key)
    return value

def choice(d, key, values, default=None):
    v = obj(d).get(key, default)
    if v not in values: fail(400, 'Проверьте поле: ' + key)
    return v

def positive(v):
    if type(v) is not int or not 1 <= v <= 2147483647: fail(400, 'Некорректный идентификатор.')
    return v

def numberstr(d, key, integer=9, fraction=4):
    v = textfield(d, key, 1, 32)
    if not re.fullmatch(r'[0-9]{1,%d}(\.[0-9]{1,%d})?' % (integer, fraction), v) or float(v) <= 0:
        fail(400, 'Проверьте число: ' + key)
    return v

def cas(v):
    if not re.fullmatch(r'[0-9]{2,7}-[0-9]{2}-[0-9]', v): fail(400, 'Некорректный CAS.')
    s = v.replace('-', '')
    if sum(int(x) * (i + 1) for i, x in enumerate(s[-2::-1])) % 10 != int(s[-1]): fail(400, 'Неверная контрольная цифра CAS.')
    return v

def emailfield(d, key):
    v = textfield(d, key, 3, 254)
    try: validate_email(v)
    except ValidationError: fail(400, 'Проверьте email.')
    return v

def urlfield(v, https=True):
    try:
        p = urlsplit(v)
        if p.username is not None or p.password is not None: raise ValueError()
        # Locally uploaded documents use the configured origin, including local HTTP tests.
        internal = p.scheme+'://'+p.netloc==settings.BASE_URL and p.path=='/api/document-files' and re.fullmatch(r'[a-f0-9-]{36}',parse_qs(p.query).get('id',[''])[0])
        if not internal: URLValidator(schemes=['https'] if https else ['http', 'https'])(v)
    except (ValidationError, ValueError): fail(400, 'Нужна корректная ссылка без логина и пароля.')
    return v

def datefield(v, empty=False):
    if empty and v == '': return ''
    try:
        if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', v): raise ValueError()
        date.fromisoformat(v)
    except (ValueError, TypeError): fail(400, 'Некорректная дата.')
    return v

def today():
    return datetime.now(timezone.utc).date().isoformat()

def uuidfield(d, key):
    v = textfield(d, key, 36, 36)
    if not re.fullmatch(r'[a-fA-F0-9]{8}-(?:[a-fA-F0-9]{4}-){3}[a-fA-F0-9]{12}', v): fail(400, 'Некорректный идентификатор.')
    return v

def documents(rows):
    if not isinstance(rows, list) or len(rows) > 6: fail(400, 'Допустимо до 6 документов.')
    result = []
    for r in rows:
        t = choice(r, 'type', ['SDS', 'COA', 'TDS'])
        result.append({'type': t, 'version': textfield(r, 'version', 0, 80), 'sourceName': textfield(r, 'sourceName', 0, 160),
            'url': urlfield(textfield(r, 'url', 1, 1500)), 'language': textfield(r, 'language', 2, 30),
            'date': datefield(textfield(r, 'date', 0, 10), True), 'batch': textfield(r, 'batch', 1 if t == 'COA' else 0, 100)})
    return result

def mod(scope, key): return getrec('moderation', f'{scope}:{key}') or {}
def hidden(scope, key): return bool(mod(scope, key).get('hidden'))
def visible(o): return o['status'] == 'published' and not hidden('offer', o['id']) and not hidden('company', o['userId'])
def profile(uid):
    p = getrec('profile', uid)
    if not p: fail(409, 'Сначала заполните профиль компании.')
    return p

def product(pid):
    demo = [('Ацетон','67-64-1'),('Лимонная кислота','77-92-9'),('Гидроксид натрия','1310-73-2'),('Этанол','64-17-5'),('Диоксид титана','13463-67-7'),('Полиэтилен низкого давления','9002-88-4'),('Серная кислота','7664-93-9'),('Глицерин фарм. качества','56-81-5')]
    if 1 <= pid <= 8: return (*demo[pid-1], {})
    o = getrec('offer', pid - 100000)
    if not o or not visible(o): fail(404, 'Товар недоступен.')
    return o['name'], o['cas'], {k: o.get(k) or '' for k in ['chemexId','manufacturer','grade']}

def pageparam(query, key, default, maximum):
    raw = str(query.get(key, default))
    if not re.fullmatch('[0-9]+', raw) or not 1 <= int(raw) <= maximum: fail(400, 'Некорректная страница.')
    return int(raw)
