"""Private buyer delivery records, independent of supplier offers and RFQ state."""
from decimal import Decimal
from .core import *
from .market import UNITS


def owned_delivery(uid,i):
    v=getrec('partner_delivery',i)
    if not v or v['userId']!=uid:fail(404,'Поставка не найдена.')
    return v


def fields(d):
    v={k:textfield(d,k,0,n) for k,n in [('reference',150),('batchNumber',150),('notes',2000)]}
    v['status']=choice(d,'status',['planned','partial','received','cancelled'])
    v['inspection']=choice(d,'inspection',['unchecked','accepted','issues'])
    v['quantity']=numberstr(d,'quantity',9,3);v['unit']=choice(d,'unit',UNITS)
    v['plannedDate']=datefield(textfield(d,'plannedDate',10,10))
    v['receivedDate']=datefield(textfield(d,'receivedDate',0,10),True)
    received=textfield(d,'receivedQuantity',0,13)
    v['receivedQuantity']=numberstr(d,'receivedQuantity',9,3) if received else ''
    if v['status'] in ['partial','received']:
        if not v['receivedDate'] or not v['receivedQuantity']:fail(400,'Для получения укажите фактическую дату и количество.')
        if v['receivedDate']>today():fail(400,'Фактическая дата не может быть в будущем (UTC).')
        if v['status']=='partial' and Decimal(v['receivedQuantity'])>=Decimal(v['quantity']):fail(400,'При частичном получении количество должно быть меньше планового.')
    elif v['receivedDate'] or v['receivedQuantity'] or v['inspection']!='unchecked':fail(400,'Для плана или отмены очистите получение и результат приёмки.')
    if v['inspection']=='issues' and not v['notes']:fail(400,'Опишите замечания при приёмке.')
    return v


def present_delivery(v):
    received=Decimal(v['receivedQuantity'] or '0');planned=Decimal(v['quantity'])
    overdue=v['status'] in ['planned','partial'] and v['plannedDate']<today()
    delay=(date.fromisoformat(v['receivedDate'])-date.fromisoformat(v['plannedDate'])).days if v['receivedDate'] else None
    return {**{k:x for k,x in v.items() if k not in ['creationDigest','userId']},'overdue':overdue,'delayDays':max(delay,0) if delay is not None else None,
            'quantityDifference':str(received-planned) if v['receivedQuantity'] else None}


def deliveries_api(req,d):
    from .partners import buyer,owned,supplier_offer,snapshot
    uid=buyer(req)
    if req.method=='GET':
        if req.GET.get('id'):
            v=owned_delivery(uid,uuidfield(req.GET.dict(),'id'));owned(uid,v['partnerId'])
            before=pageparam(req.GET,'before',2147483647,2147483647)
            events=sorted([e for e in records('delivery_event',uid,v['id']) if e['id']<before],key=lambda e:e['id'],reverse=True)
            return {'delivery':present_delivery(v),'events':[{**e,'snapshot':present_delivery(e['snapshot'])} for e in events[:20]],'before':events[19]['id'] if len(events)>20 else None}
        p=owned(uid,uuidfield(req.GET.dict(),'partnerId'))
        return {'deliveries':[present_delivery(v) for v in sorted(records('partner_delivery',uid,p['id']),key=lambda v:(v['plannedDate'],v['id']),reverse=True)]}
    if req.method!='POST':fail(405,'Метод не поддерживается.')
    action=choice(d,'action',['create','update'])
    if action=='create':
        i=uuidfield(d,'clientId');fingerprint=digest(d)
        old=getrec('partner_delivery',i)
        if old:
            if old['userId']!=uid:fail(409,'Идентификатор занят. Обновите форму.')
            if old.get('creationDigest')!=fingerprint:fail(409,'Попытка создания уже выполнена с другими данными. Обновите список.')
            return {'delivery':present_delivery(old),'replayed':True}
        p=owned(uid,uuidfield(d,'partnerId'))
        source=obj(d.get('source'));kind=choice(source,'kind',['offer','request'])
        if kind=='offer':
            offer_id=positive(source.get('id'));pin=next((x for x in p['products'] if x['id']==offer_id),None)
            o=supplier_offer(p['supplierId'],offer_id)
            if not pin or any(pin.get(k)!=o.get(k) for k in ['chemexId','cas','manufacturer','grade']):fail(409,'Закреплённое сырьё изменилось. Обновите карточку.')
            identity={k:o.get(k) or '' for k in ['name','cas','chemexId','manufacturer','grade']}
        else:
            q=getrec('request',uuidfield(source,'id'))
            if not q or q['userId']!=uid or q['recipientId']!=p['supplierId'] or q['status']!='quoted':fail(404,'Полученное предложение не найдено.')
            identity={k:q.get(k) or '' for k in ['cas','chemexId','manufacturer','grade']};identity['name']=q['product']
        v={'id':i,'userId':uid,'partnerId':p['id'],'source':{'kind':kind,'id':source['id']},'product':identity,'revision':0,'createdAt':stamp(),'creationDigest':fingerprint}
    else:
        v=owned_delivery(uid,uuidfield(d,'id'));p=owned(uid,v['partnerId'])
        if type(d.get('revision')) is not int or d['revision']!=v['revision']:fail(409,'Поставка изменилась. Обновите список перед редактированием.')
    if p['archived']:fail(409,'Сначала восстановите поставщика из архива.')
    reason=textfield(d,'reason',3,1000)
    updated=fields(d)
    if v.get('receiptJournal') and any(updated[k]!=v[k] for k in ['quantity','unit','receivedQuantity','receivedDate','batchNumber']):
        fail(409,'При включённом журнале объёмы, единица и партия фиксированы. Фактические поступления изменяйте через журнал.')
    v.update(updated);v['revision']+=1;v['updatedAt']=stamp()
    event_id=nextid('delivery_event')
    putrec('delivery_event',event_id,{'id':event_id,'createdAt':v['updatedAt'],'reason':reason,'snapshot':{k:x for k,x in v.items() if k not in ['creationDigest','userId']}},uid,v['id'])
    putrec('partner_delivery',v['id'],v,uid,p['id'],v['status'])
    return {'delivery':present_delivery(v),'replayed':False}
