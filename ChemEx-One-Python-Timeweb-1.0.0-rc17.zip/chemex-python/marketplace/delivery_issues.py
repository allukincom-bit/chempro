"""Private issue tracking: no supplier notification or legal claim dispatch."""
from .core import *
from .deliveries import owned_delivery

CLOSED=['resolved','cancelled']


def owned_issue(uid,i):
    v=getrec('delivery_issue',i)
    if not v or v['userId']!=uid:fail(404,'Замечание не найдено.')
    return v


def public_issue(v):
    return {**{k:x for k,x in v.items() if k not in ['userId','creationDigest']},
        'reviewDue':v['status'] not in CLOSED and bool(v['reviewDate']) and v['reviewDate']<=today()}


def issue_fields(d):
    v={k:textfield(d,k,lo,hi) for k,lo,hi in [('title',3,200),('description',3,3000),('requestedResolution',0,1500),('resolution',0,2000)]}
    v['category']=choice(d,'category',['quantity','quality','documents','timing','other'])
    v['status']=choice(d,'status',['open','in_progress','resolved','cancelled'])
    v['reviewDate']=datefield(textfield(d,'reviewDate',0,10),True)
    if v['status'] in CLOSED:
        if not v['resolution']:fail(400,'Укажите результат урегулирования или причину отмены.')
        if v['reviewDate']:fail(400,'Для закрытого замечания очистите дату следующей проверки.')
    return v


def issues_api(req,d):
    from .partners import buyer,owned
    uid=buyer(req)
    if req.method=='GET':
        if req.GET.get('id'):
            v=owned_issue(uid,uuidfield(req.GET.dict(),'id'));owned(uid,v['partnerId'])
            before=pageparam(req.GET,'before',2147483647,2147483647)
            rows=sorted([e for e in records('issue_event',uid,v['id']) if e['id']<before],key=lambda e:e['id'],reverse=True)
            return {'issue':public_issue(v),'events':rows[:20],'before':rows[19]['id'] if len(rows)>20 else None}
        p=owned(uid,uuidfield(req.GET.dict(),'partnerId'))
        rows=sorted(records('delivery_issue',uid,p['id']),key=lambda x:(x['updatedAt'],x['id']),reverse=True)
        deliveries=sorted(records('partner_delivery',uid,p['id']),key=lambda x:(x['plannedDate'],x['id']),reverse=True)
        return {'issues':[public_issue(v) for v in rows],'deliveries':[{'id':v['id'],'revision':v['revision'],'name':v['product']['name'],'reference':v['reference'],'batchNumber':v['batchNumber'],'plannedDate':v['plannedDate']} for v in deliveries]}
    if req.method!='POST':fail(405,'Метод не поддерживается.')
    action=choice(d,'action',['create','update'])
    if action=='create':
        i=uuidfield(d,'clientId');fp=digest(d);previous=getrec('delivery_issue',i)
        if previous:
            if previous['userId']!=uid or previous.get('creationDigest')!=fp:fail(409,'Эта попытка уже обработана. Обновите список замечаний.')
            return {'issue':public_issue(previous),'replayed':True}
        p=owned(uid,uuidfield(d,'partnerId'));delivery=owned_delivery(uid,uuidfield(d,'deliveryId'))
        if delivery['partnerId']!=p['id']:fail(404,'Поставка этого поставщика не найдена.')
        if type(d.get('deliveryRevision')) is not int or d['deliveryRevision']!=delivery['revision']:fail(409,'Поставка изменилась. Обновите список перед созданием замечания.')
        v={'id':i,'userId':uid,'partnerId':p['id'],'deliveryId':delivery['id'],
           'deliverySnapshot':{k:x for k,x in delivery.items() if k not in ['userId','creationDigest']},
           'revision':0,'createdAt':stamp(),'creationDigest':fp,'closedAt':None}
    else:
        v=owned_issue(uid,uuidfield(d,'id'));p=owned(uid,v['partnerId'])
        if type(d.get('revision')) is not int or d['revision']!=v['revision']:fail(409,'Замечание изменилось. Обновите список.')
    if p['archived']:fail(409,'Сначала восстановите поставщика из архива.')
    reason=textfield(d,'reason',3,1000);fields=issue_fields(d)
    closed=fields['status'] in CLOSED
    v['closedAt']=(v.get('closedAt') or stamp()) if closed else None
    v.update(fields);v['revision']+=1;v['updatedAt']=stamp()
    event_id=nextid('issue_event')
    putrec('issue_event',event_id,{'id':event_id,'createdAt':v['updatedAt'],'reason':reason,
        'snapshot':{k:x for k,x in v.items() if k not in ['userId','creationDigest']}},uid,v['id'])
    putrec('delivery_issue',v['id'],v,uid,p['id'],v['status'])
    return {'issue':public_issue(v),'replayed':False}
