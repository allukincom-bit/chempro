from django.conf import settings
from .core import *

def laboratory_record(raw):
    r = {'id':textfield(raw,'id',1,90)}
    if not re.fullmatch('LAB-RU-[A-Z0-9-]{1,80}',r['id']): fail(400,'Некорректный ID лаборатории.')
    for k in ['name','region','city','address','addressKind','accreditationNumber']: r[k]=textfield(raw,k,1,600)
    r['addressNote']=textfield(raw,'addressNote',0,2000)
    for k in ['phones','emails','tags','services','sourceUrls']:
        v=raw.get(k)
        if not isinstance(v,list) or len(v)>30: fail(400,'Проверьте '+k)
        r[k]=[textfield({'v':x},'v',1,1500) for x in v]
    if not r['services'] or not r['sourceUrls']: fail(400,'Нужны услуги и источники.')
    for v in r['phones']:
        if not re.fullmatch(r'\+?[0-9 ()-]{5,40}',v): fail(400,'Проверьте телефон.')
    for v in r['emails']: emailfield({'v':v},'v')
    for k in ['website','accreditationSourceUrl','registryUrl']: r[k]=urlfield(textfield(raw,k,1,1500),False)
    for v in r['sourceUrls']: urlfield(v,False)
    if urlsplit(r['registryUrl']).hostname!='pub.fsa.gov.ru': fail(400,'Нужна ссылка на официальный РАЛ.')
    r['scopeUrl']=urlfield(textfield(raw,'scopeUrl',1,1500),False) if raw.get('scopeUrl') is not None else None
    r['registryStatus']=choice(raw,'registryStatus',['not_checked','active','suspended','terminated','partly_suspended'])
    r['sourceCheckedAt']=datefield(textfield(raw,'sourceCheckedAt',10,10))
    r['registryCheckedAt']=datefield(textfield(raw,'registryCheckedAt',10,10)) if raw.get('registryCheckedAt') is not None else None
    if r['sourceCheckedAt']>today() or (r['registryCheckedAt'] and r['registryCheckedAt']>today()): fail(400,'Дата в будущем.')
    if r['registryStatus']=='not_checked':
        if r['registryCheckedAt'] is not None: fail(400,'У непроверенного статуса дата РАЛ должна быть пустой.')
    elif not r['registryCheckedAt'] or not r['scopeUrl'] or not urlsplit(r['registryUrl']).path.startswith('/ral/view/'): fail(400,'Нужны дата, карточка РАЛ и область аккредитации.')
    return r

def laboratory_key(r):
    return hashlib.sha256((re.sub(r'\s','',norm(r['accreditationNumber']).replace('ё','е'))+'|'+norm(r['address']).replace('ё','е')).encode()).hexdigest()

def laboratories_api(req,d):
    management=req.GET.get('admin')=='1'
    if management or req.method!='GET': actor=admin(req)
    if req.method=='GET':
        items=sorted(records('laboratory'),key=lambda x:x['record']['id'])
        if management: return {'items':items}
        seed=json.loads((settings.BASE_DIR/'seed/laboratories-seed.json').read_text())
        return {'schemaVersion':1,'updatedAt':max([x['updatedAt'] for x in items],default=seed['updatedAt']),
            'coverage':seed['coverage'],'laboratories':[x['record'] for x in items if not x['hidden']]}
    if req.method!='POST': fail(405,'Метод не поддерживается.')
    r=laboratory_record(obj(d.get('record'))); reason=textfield(d,'reason',5,1000)
    if type(d.get('hidden')) is not bool or type(d.get('revision')) is not int or d['revision']<0: fail(400,'Проверьте действие и версию.')
    if r['registryStatus']!='not_checked' and d.get('registryReviewed') is not True: fail(400,'Подтвердите ручную сверку в РАЛ.')
    old=getrec('laboratory',r['id'])
    if (old or {}).get('revision',0)!=d['revision']: fail(409,'Карточка изменилась. Обновите список.')
    for entry in records('laboratory'):
        if entry['record']['id']!=r['id'] and laboratory_key(entry['record'])==laboratory_key(r): fail(409,'Номер и адрес уже есть в справочнике.')
    row={'record':r,'hidden':d['hidden'],'revision':d['revision']+1,'reason':reason,'actor':actor['email'],'updatedAt':stamp()}
    putrec('laboratory',r['id'],row)
    action='laboratory_create' if not old else ('laboratory_hide' if row['hidden'] else 'laboratory_restore') if old['hidden']!=row['hidden'] else 'laboratory_update'
    event(actor['email'],action,'laboratory:'+r['id'],reason)
    return {'ok':True,'id':r['id'],'revision':row['revision']}
