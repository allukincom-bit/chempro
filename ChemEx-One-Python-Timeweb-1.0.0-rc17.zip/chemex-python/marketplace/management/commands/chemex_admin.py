import getpass
import json
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.hashers import make_password
from marketplace.core import *
from marketplace.views import validate_password
from marketplace.administration import prepare_reference
from marketplace.laboratories import laboratory_record

def seed():
    for i, raw in enumerate(json.loads((settings.BASE_DIR/'seed/seed.json').read_text()),1):
        p=prepare_reference(raw,f'REF-{i:04d}')
        if not getrec('reference',p['sourceRecordId']): putrec('reference',p['sourceRecordId'],p,related=p['identityKey'])
    data=json.loads((settings.BASE_DIR/'seed/laboratories-seed.json').read_text())
    for raw in data['laboratories']:
        r=laboratory_record(raw)
        if not getrec('laboratory',r['id']): putrec('laboratory',r['id'],{'record':r,'hidden':False,'revision':0,'reason':'','actor':'','updatedAt':data['updatedAt']})
    putrec('settings','laboratories_seed_v1',{'installed':True})

class Command(BaseCommand):
    help='Initial setup and account recovery; passwords are entered with hidden input.'
    def add_arguments(self,p):
        p.add_argument('action',choices=['init','seed','reset-password','grant-admin','revoke-admin'])
        p.add_argument('email',nargs='?')
        p.add_argument('--name',default='Администратор')
    def handle(self,*args,**opts):
        try:
            action=opts['action']; email=emailfield({'email':opts['email'] or ''},'email').lower() if action!='seed' else ''
            password=None
            if action in ['init','reset-password']:
                password=validate_password(getpass.getpass('Новый пароль: '))
                if getpass.getpass('Повторите пароль: ')!=password: raise CommandError('Пароли не совпадают.')
            with write_transaction():
                if action=='init':
                    if Account.objects.exists() or Record.objects.exists(): raise CommandError('Для init нужна пустая база. Для переноса используйте import_php.')
                    u=Account.objects.create(email=email,display_name=textfield({'name':opts['name']},'name',2,120),password_hash=make_password(password),is_admin=True,created_at=stamp())
                    seed(); event('operator','installation','system','Установка Python/Django-версии')
                elif action=='seed':
                    seed(); event('operator','seed','system','Добавление отсутствующих начальных записей')
                else:
                    u=Account.objects.filter(email=email).first()
                    if not u: raise CommandError('Аккаунт не найден.')
                    if action=='reset-password': u.password_hash=make_password(password)
                    else:
                        if action=='revoke-admin' and u.is_admin and Account.objects.filter(is_admin=True).count()<=1: raise CommandError('Нельзя удалить последнего администратора.')
                        u.is_admin=action=='grant-admin'
                    u.session_version+=1; u.save(); event('operator',action,u.id,'Изменение через CLI')
        except APIError as e: raise CommandError(e.message) from e
        settings.DOCUMENT_ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.stdout.write(self.style.SUCCESS('Готово.'))
