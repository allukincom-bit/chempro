"""Offline import into an empty migrated database. No production source is modified."""
import shutil
from pathlib import Path
from urllib.parse import parse_qs, urlsplit, urlunsplit
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from marketplace.core import *

KINDS={'profile','offer','favorite','request','message','message_retry','reference','verification','bank_reference','settings','moderation','audit','file','laboratory'}

def remap_urls(value,old,new):
    if isinstance(value,dict): return {k:remap_urls(v,old,new) for k,v in value.items()}
    if isinstance(value,list): return [remap_urls(v,old,new) for v in value]
    if isinstance(value,str):
        p=urlsplit(value) if value.startswith(old+'/api/document-files?') else None
        if p and p.path=='/api/document-files' and (p.scheme+'://'+p.netloc)==old and parse_qs(p.query).get('id'):
            return new+'/api/document-files?'+p.query
    return value

class Command(BaseCommand):
    help='Import an export_php.php JSON and its private PDF directory; empty database only.'
    def add_arguments(self,p):
        p.add_argument('export_file')
        p.add_argument('--documents',required=True)
        p.add_argument('--dry-run',action='store_true')
    def handle(self,*args,**opts):
        copied=[]
        try:
            data=json.loads(Path(opts['export_file']).read_text())
            if data.get('format')!='chemex-php-export-v1': raise CommandError('Неподдерживаемый формат экспорта.')
            users=data['users']; rows=data['records']; counters=data['counters']; files=data['files']; old=data['baseUrl']
            if not isinstance(users,list) or not isinstance(rows,list) or not isinstance(files,dict): raise CommandError('Некорректный экспорт.')
            ids=set(); emails=set(); record_ids=set(); source=Path(opts['documents']).resolve()
            for u in users:
                uuidfield(u,'id'); email=emailfield(u,'email').lower()
                if u['id'] in ids or email in emails: raise CommandError('Повтор пользователя или email.')
                if not isinstance(u['password_hash'],str) or not u['password_hash'].startswith(('$2y$','$2b$','$2a$','pbkdf2_sha256$')): raise CommandError('Неподдерживаемый хеш пароля; смените пароль через старую CLI перед экспортом.')
                ids.add(u['id']); emails.add(email)
            if not users or not any(int(u['is_admin'])==1 for u in users): raise CommandError('В экспорте должен быть администратор.')
            file_rows={}
            for r in rows:
                key=str(r['id']); kind=r['kind']; payload=obj(r['payload'])
                if kind not in KINDS or not key or len(key)>160 or (kind,key) in record_ids: raise CommandError('Некорректная или повторная запись.')
                record_ids.add((kind,key))
                if r['owner'] and r['owner'] not in ids: raise CommandError('Владелец записи отсутствует.')
                if kind=='file':
                    uuidfield({'id':key},'id'); file_rows[key]=r
                    if str(payload['id'])!=key: raise CommandError('ID файла не совпадает.')
            if set(files)!=set(file_rows): raise CommandError('Манифест PDF не совпадает с записями.')
            for i,m in files.items():
                path=source/(i+'.pdf')
                if path.is_symlink() or not path.is_file() or path.stat().st_size!=int(m['size']): raise CommandError('Не найден PDF или отличается размер: '+i)
                if int(m['size'])!=int(file_rows[i]['payload']['size']): raise CommandError('Размер PDF отличается от метаданных.')
                if hashlib.sha256(path.read_bytes()).hexdigest()!=m['sha256']: raise CommandError('Контрольная сумма PDF не совпадает: '+i)
            if Account.objects.exists() or Record.objects.exists(): raise CommandError('Импорт разрешён только в пустую базу после migrate; не выполняйте init.')
            if settings.DOCUMENT_ROOT.exists() and any(settings.DOCUMENT_ROOT.iterdir()): raise CommandError('Каталог назначения PDF должен быть пустым.')
            if opts['dry_run']:
                self.stdout.write(f'Проверено: {len(users)} пользователей, {len(rows)} записей, {len(files)} PDF. Изменений нет.'); return
            with write_transaction():
                if Account.objects.exists() or Record.objects.exists(): raise CommandError('База уже заполнена.')
                for u in users:
                    Account.objects.create(id=u['id'],email=u['email'].lower(),display_name=u['display_name'],password_hash=u['password_hash'],
                        is_admin=bool(int(u['is_admin'])),session_version=int(u['session_version'])+1,created_at=u['created_at'])
                for r in rows:
                    payload=remap_urls(r['payload'],old,settings.BASE_URL)
                    putrec(r['kind'],r['id'],payload,r['owner'],r['related'],r['status'])
                for c in counters:
                    if c['name']!='write_lock': Counter.objects.update_or_create(name=c['name'],defaults={'value':int(c['value'])})
                for kind in ['offer','verification','message','audit']:
                    maximum=max([int(r['id']) for r in rows if r['kind']==kind],default=0)
                    c,_=Counter.objects.get_or_create(name=kind)
                    if c.value<maximum: c.value=maximum; c.save()
                settings.DOCUMENT_ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
                for i in files:
                    destination=settings.DOCUMENT_ROOT/(i+'.pdf')
                    with destination.open('xb') as out, (source/(i+'.pdf')).open('rb') as src:
                        copied.append(destination); destination.chmod(0o600); shutil.copyfileobj(src,out)
                event('operator','php_import','system',f'{len(users)} пользователей, {len(rows)} записей, {len(files)} PDF')
            self.stdout.write(self.style.SUCCESS('Импорт завершён. Старые сеансы не переносятся; пользователи входят заново.'))
        except Exception as e:
            for path in copied: path.unlink(missing_ok=True)
            if isinstance(e,CommandError): raise
            raise CommandError(str(e)) from e
