from .core import *

UNITS = ['кг','т','л','шт.']
INCOTERMS = ['EXW','FCA','FOB','CIF','CIP','DAP','DDP']

def profile_api(req, d):
    u = user(req); uid = u['userId']
    if req.method == 'GET':
        m = mod('company', uid)
        return {'user': {'displayName': u['displayName'], 'email': u['email']}, 'isSuperAdmin': u['admin'],
            'publicationRestriction': m if m.get('hidden') else None, 'profile': getrec('profile', uid)}
    if req.method != 'PUT': fail(405, 'Метод не поддерживается.')
    p = {k: textfield(d, k, lo, hi) for k, lo, hi in [('companyName',2,160),('country',2,100),
        ('registrationNumber',0,100),('contactName',2,120),('website',0,300),('description',0,2000)]}
    p.update(contactEmail=emailfield(d, 'contactEmail'), role=choice(d, 'role', ['buyer','supplier','both']))
    if p['website']: urlfield(p['website'], False)
    old = getrec('profile', uid) or {}
    p.update(userId=uid, email=u['email'], verificationStatus='unverified', createdAt=old.get('createdAt',stamp()), updatedAt=stamp())
    putrec('profile', uid, p, uid)
    return {'profile': p}

def technical_fields(raw):
    obj(raw)
    if set(raw) - {'physicalForm','appearance','applications','sourceUrl','sourceDate','specifications'}: fail(400, 'Проверьте характеристики.')
    t = {k: textfield(raw, k, 0, hi) for k, hi in [('appearance',200),('applications',2000),('sourceUrl',1500)]}
    t['physicalForm'] = choice(raw, 'physicalForm', ['', 'Жидкость','Порошок','Гранулы','Твёрдое вещество','Паста','Газ','Другое'], '')
    t['sourceDate'] = datefield(textfield(raw,'sourceDate',0,10), True)
    if t['sourceUrl']: urlfield(t['sourceUrl'])
    if t['sourceDate'] and (not t['sourceUrl'] or t['sourceDate'] > today()): fail(400,'Проверьте источник и дату.')
    rows = raw.get('specifications', [])
    if not isinstance(rows, list) or len(rows) > 12: fail(400, 'Допустимо до 12 показателей.')
    t['specifications'] = []
    for r in rows:
        if set(obj(r)) - {'name','value','unit','conditions'}: fail(400,'Проверьте показатель.')
        t['specifications'].append({k:textfield(r,k,lo,hi) for k,lo,hi in [('name',1,80),('value',1,160),('unit',0,40),('conditions',0,120)]})
    return t

def offer_fields(d):
    p = {k: textfield(d,k,1,160) for k in ['name','moq','packaging','lead']}
    for k in ['manufacturer','grade','formula','description']:
        p[k] = textfield(d,k,0,2000 if k == 'description' else 100 if k == 'formula' else 160)
    p['cas'] = cas(textfield(d,'cas',1,20))
    p['category'] = choice(d,'category',['Растворители','Кислоты','Неорганические вещества','Полимеры','Специальная химия'])
    p['purity'] = numberstr(d,'purity',3,3)
    if float(p['purity']) > 100: fail(400,'Чистота не более 100%.')
    p['price'] = numberstr(d,'price')
    p['unit'] = choice(d,'unit',UNITS)
    p['region'] = choice(d,'region',['Европа','Азия','Северная Америка','Ближний Восток','Южная Америка','Африка','Океания'])
    p['incoterm'] = choice(d,'incoterm',INCOTERMS)
    p['status'] = choice(d,'status',['draft','published'])
    if 'technical' in d: p['technical'] = technical_fields(d['technical'])
    p['documents'] = documents(d.get('documents',[]))
    p['chemexId'] = chemex(p['manufacturer'],p['grade'],p['cas'])
    if p['status'] == 'published' and not p['chemexId']: fail(400,'Для публикации укажите производителя и марку.')
    return p

def offers_api(req,d):
    if req.method == 'GET':
        if req.GET.get('mine') == '1':
            uid = user(req)['userId']; m = mod('company',uid)
            rows = sorted(records('offer',uid),key=lambda o:o['updatedAt'],reverse=True)
            for o in rows:
                x = mod('offer',o['id']); o['moderation'] = x if x.get('hidden') else None
            return {'offers': rows,'publicationRestriction': m if m.get('hidden') else None}
        out = []; checks = records('verification')
        for o in records('offer'):
            if not visible(o): continue
            p = getrec('profile',o['userId'])
            if not p: continue
            verified = any(v['userId']==o['userId'] and v['status']=='bank_confirmed' and v['fingerprint']==fingerprint(p) for v in checks)
            o.pop('userId'); o['id'] += 100000
            o.update(price=float(o['price']),purity=float(o['purity']),supplier=p['companyName'],country=p['country'],initials=p['companyName'][:2].upper(),verified=verified,shape='◈',tone='blue-tone',live=True)
            out.append(o)
        return {'products':sorted(out,key=lambda o:o['updatedAt'],reverse=True)}
    if req.method not in ['POST','PUT']: fail(405,'Метод не поддерживается.')
    uid = user(req)['userId']; p = profile(uid)
    if p['role']=='buyer': fail(403,'Выберите роль поставщика.')
    old = {}; i = positive(d.get('id')) if req.method=='PUT' else nextid('offer')
    if req.method == 'PUT':
        old = getrec('offer',i)
        if not old or old['userId']!=uid: fail(404,'Предложение не найдено.')
    o = offer_fields(d)
    if 'technical' not in o: o['technical'] = old.get('technical',technical_fields({}))
    if o['status']=='published' and (hidden('company',uid) or hidden('offer',i)): fail(403,'Публикация приостановлена суперадминистратором.')
    o.update(id=i,userId=uid,createdAt=old.get('createdAt',stamp()),updatedAt=stamp())
    putrec('offer',i,o,uid,status=o['status'])
    return {'offer':o}

def favorites_api(req,d):
    uid = user(req)['userId']
    if req.method=='GET': return {'favorites':[r['productId'] for r in records('favorite',uid)]}
    if req.method!='PUT': fail(405,'Метод не поддерживается.')
    i = positive(d.get('productId')); key = f'{uid}:{i}'
    if type(d.get('saved')) is not bool: fail(400,'Некорректное действие.')
    if d['saved']:
        product(i); putrec('favorite',key,{'productId':i},uid)
    else: Record.objects.filter(kind='favorite',key=key).delete()
    return {'ok':True}

def requested_documents(v):
    if not isinstance(v,list) or len(v)>3 or any(not isinstance(x,str) or x not in ['SDS','TDS','COA'] for x in v) or len(set(v))!=len(v): fail(400,'Допустимы SDS, TDS и COA без повторов.')
    return v

def quotation_terms(q):
    t = {k:textfield(q,k,0,hi) for k,hi in [('vatRate',6),('moqQuantity',13),('paymentTerms',1000),('packaging',300)]}
    t['vatMode'] = choice(q,'vatMode',['unspecified','included','excluded','not_applicable'],'unspecified')
    t['moqUnit'] = choice(q,'moqUnit',['']+UNITS,'')
    if t['vatRate'] and (not re.fullmatch(r'[0-9]{1,3}(\.[0-9]{1,2})?',t['vatRate']) or float(t['vatRate'])>100): fail(400,'Проверьте ставку НДС.')
    if (t['vatMode'] in ['included','excluded']) != bool(t['vatRate']): fail(400,'Укажите ставку только для включённого или начисляемого НДС.')
    if t['moqQuantity']: numberstr(t,'moqQuantity',9,3)
    if bool(t['moqQuantity']) != bool(t['moqUnit']): fail(400,'Укажите количество и единицу минимальной партии.')
    return t

def requests_api(req,d):
    uid = user(req)['userId']
    if req.method=='GET':
        rows = records('request',related=uid) if req.GET.get('inbox')=='1' else records('request',uid)
        return {'requests':sorted(rows,key=lambda r:r['createdAt'],reverse=True)}
    if req.method=='POST':
        if profile(uid)['role']=='supplier': fail(403,'Выберите роль покупателя.')
        pid = positive(d.get('productId')); name,cas_,snapshot = product(pid)
        r = {'id':str(uuid.uuid4()),'userId':uid,'productId':pid,'product':name,'cas':cas_,
            **{k:snapshot.get(k,'') for k in ['chemexId','manufacturer','grade']},
            'quantity':numberstr(d,'quantity',9,3),'unit':choice(d,'unit',UNITS),'destination':textfield(d,'destination',2,150),
            'email':emailfield(d,'email'),'message':textfield(d,'message',0,3000),'specification':textfield(d,'specification',0,2000),
            'requestedDocuments':requested_documents(d.get('requestedDocuments',[])),'status':'draft','createdAt':stamp(),
            'recipientId':None,'buyerCompany':None,'supplierCompany':None,'sentAt':None,'quotation':None,'repliedAt':None}
        putrec('request',r['id'],r,uid,status='draft')
        return {'request':r}
    if req.method not in ['DELETE','PATCH']: fail(405,'Метод не поддерживается.')
    i = uuidfield(d,'id'); r = getrec('request',i)
    if req.method=='DELETE':
        if not r or r['userId']!=uid or r['status']!='draft': fail(409,'Можно удалить только свой черновик.')
        Record.objects.filter(kind='request',key=i).delete(); return {'ok':True}
    action = choice(d,'action',['send','reply'])
    if not r or r['userId' if action=='send' else 'recipientId']!=uid: fail(404,'Запрос не найден.')
    p = profile(uid)
    if action=='send':
        if p['role']=='supplier': fail(403,'Нужна роль покупателя.')
        if r['status']!='draft': return {'request':r}
        if r.get('partnerId'):
            relationship = getrec('partner',r['partnerId'])
            if not relationship or relationship['userId'] != uid or relationship['archived'] or relationship['status'] == 'paused':
                fail(409,'Работа с поставщиком приостановлена. Возобновите её в разделе «Мои поставщики».')
        o = getrec('offer',r['productId']-100000); s = getrec('profile',o['userId']) if o else None
        if not o or not visible(o) or not s or s['role']=='buyer': fail(409,'Отправка доступна только по действующим предложениям поставщиков.')
        if r.get('partnerId') and o['userId']!=relationship['supplierId']: fail(409,'Поставщик товара изменился. Создайте новый запрос.')
        if o['userId']==uid: fail(400,'Нельзя отправить запрос себе.')
        if r['cas']!=o['cas'] or (r.get('chemexId') and r['chemexId']!=o.get('chemexId')): fail(409,'Производитель, марка или CAS товара изменились. Создайте новый запрос.')
        r.update(recipientId=o['userId'],buyerCompany=p['companyName'],supplierCompany=s['companyName'],sentAt=stamp(),status='sent')
    else:
        if p['role']=='buyer': fail(403,'Нужна роль поставщика.')
        if r['status']!='sent': fail(409,'Ответ уже сохранён.')
        raw = obj(d.get('quotation')); q = quotation_terms(raw)
        q.update(price=numberstr(raw,'price'),currency=choice(raw,'currency',['EUR','USD','CNY','RUB']),unit=choice(raw,'unit',UNITS),
            lead=textfield(raw,'lead',1,160),incoterm=choice(raw,'incoterm',INCOTERMS),validUntil=datefield(textfield(raw,'validUntil',10,10)),message=textfield(raw,'message',0,3000))
        if q['validUntil'] < today(): fail(400,'Дата предложения истекла.')
        r.update(quotation=encode(q),repliedAt=stamp(),status='quoted')
    putrec('request',i,r,r['userId'],r['recipientId'],r['status'])
    return {'request':r}

def conversation(i,uid):
    r = getrec('request',i)
    if not r or r['status'] not in ['sent','quoted'] or not r['recipientId'] or uid not in [r['userId'],r['recipientId']]: fail(404,'Диалог не найден.')
    return r

def present_message(m,uid): return {**{k:m[k] for k in ['id','body','createdAt']},'mine':m['senderId']==uid}

def conversation_summary(r,uid):
    return {**{k:r[k] for k in ['id','product','cas','quantity','unit','destination','status']},
        **{k:r.get(k,'') for k in ['chemexId','manufacturer','grade']},
        'canAddSupplier':r['userId']==uid,
        'partner':r['supplierCompany'] if r['userId']==uid else r['buyerCompany']}

def messages_api(req,d):
    uid = user(req)['userId']
    if req.method=='POST':
        i = uuidfield(d,'requestId'); client = uuidfield(d,'clientId'); text = textfield(d,'body',1,3000)
        conversation(i,uid); retry = getrec('message_retry',uid+':'+client)
        if retry:
            m = getrec('message',retry['id'])
            if m['requestId']!=i or m['body']!=text: fail(409,'Повтор сообщения с другим содержимым.')
        else:
            m = {'id':nextid('message'),'requestId':i,'clientId':client,'senderId':uid,'body':text,'createdAt':stamp()}
            putrec('message',m['id'],m,uid,i); putrec('message_retry',uid+':'+client,{'id':m['id']})
        return {'message':present_message(m,uid)}
    if req.method!='GET': fail(405,'Метод не поддерживается.')
    i = req.GET.get('requestId')
    if not i:
        out = []
        for r in records('request',uid)+records('request',related=uid):
            if r['status'] not in ['sent','quoted']: continue
            ms = records('message',related=r['id']); v = conversation_summary(r,uid)
            v.update(sentAt=r['sentAt'],lastMessageId=max([m['id'] for m in ms],default=0),messageCount=len(ms)); out.append(v)
        return {'conversations':sorted(out,key=lambda r:(r['lastMessageId'],r['sentAt']),reverse=True)}
    r = conversation(uuidfield({'id':i},'id'),uid)
    before = pageparam(req.GET,'before',2147483647,2147483647)
    ms = sorted([m for m in records('message',related=i) if m['id']<before],key=lambda m:m['id'],reverse=True)
    page = list(reversed(ms[:50])); v = conversation_summary(r,uid)
    v.update(requirements=r['message'],specification=r.get('specification',''),requestedDocuments=r.get('requestedDocuments',[]))
    return {'conversation':v,'messages':[present_message(m,uid) for m in page],'before':page[0]['id'] if len(ms)>50 else None}
