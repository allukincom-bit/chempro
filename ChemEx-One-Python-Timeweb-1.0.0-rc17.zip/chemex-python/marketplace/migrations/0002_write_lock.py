from django.db import migrations

def seed_lock(apps, schema_editor):
    apps.get_model('marketplace', 'Counter').objects.get_or_create(name='write_lock',defaults={'value':0})

class Migration(migrations.Migration):
    dependencies=[('marketplace','0001_initial')]
    operations=[migrations.RunPython(seed_lock,migrations.RunPython.noop)]
