import uuid
from datetime import datetime, timezone
from django.db import migrations


def migrate_tasks(apps,schema_editor):
    Record=apps.get_model('marketplace','Record');db=schema_editor.connection.alias
    rows=Record.objects.using(db)
    for row in rows.filter(kind='partner').iterator():
        p=row.payload
        if not p.get('nextDate') or not p.get('nextAction'):continue
        i=str(uuid.uuid5(uuid.NAMESPACE_URL,'chemex:legacy-task:'+p['id']))
        now=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        t={'id':i,'userId':p['userId'],'partnerId':p['id'],'title':p['nextAction'],'dueDate':p['nextDate'],
           'priority':'normal','status':'open','notes':'','result':'','taskLink':p.get('taskLink'),'closedAt':None,
           'revision':1,'createdAt':now,'updatedAt':now,'legacyImported':True}
        task,created=rows.get_or_create(kind='supplier_task',key=i,defaults={'owner':p['userId'],'related':p['id'],'status':'open','payload':t})
        if created:
            rows.create(kind='supplier_task_event',key=str(uuid.uuid5(uuid.NAMESPACE_URL,'chemex:legacy-event:'+p['id'])),owner=p['userId'],related=i,
                        payload={'revision':1,'createdAt':now,'reason':'Перенос следующего действия из rc13; прежняя история сохранена в карточке поставщика.',
                                 'snapshot':{k:v for k,v in t.items() if k!='userId'}})
        p.update(nextAction='',nextDate='',taskLink=None,revision=p.get('revision',1)+1)
        row.payload=p;row.save(using=db,update_fields=['payload'])


class Migration(migrations.Migration):
    dependencies=[('marketplace','0002_write_lock')]
    operations=[migrations.RunPython(migrate_tasks)]
