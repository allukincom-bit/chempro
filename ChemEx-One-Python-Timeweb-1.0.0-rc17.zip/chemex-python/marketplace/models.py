import uuid
from django.db import models

class Account(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.CharField(max_length=254, unique=True)
    display_name = models.CharField(max_length=120)
    password_hash = models.CharField(max_length=255)
    is_admin = models.BooleanField(default=False)
    session_version = models.PositiveIntegerField(default=1)
    created_at = models.CharField(max_length=30)

class Record(models.Model):
    kind = models.CharField(max_length=24)
    key = models.CharField(max_length=160)
    owner = models.CharField(max_length=36, blank=True, db_index=True)
    related = models.CharField(max_length=160, blank=True, db_index=True)
    status = models.CharField(max_length=30, blank=True)
    payload = models.JSONField()
    class Meta:
        constraints = [models.UniqueConstraint(fields=['kind', 'key'], name='record_identity')]
        indexes = [models.Index(fields=['kind', 'owner']), models.Index(fields=['kind', 'related']), models.Index(fields=['kind', 'status'])]

class Counter(models.Model):
    name = models.CharField(max_length=40, primary_key=True)
    value = models.BigIntegerField(default=0)

class AuthLimit(models.Model):
    bucket = models.CharField(max_length=64, primary_key=True)
    attempts = models.PositiveIntegerField(default=0)
    expires = models.BigIntegerField()
