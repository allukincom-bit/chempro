"""Private relationship PDFs, isolated from public product SDS/TDS/COA files."""
import os
from datetime import timedelta
from pathlib import Path
from django.conf import settings
from django.http import JsonResponse, FileResponse
from .core import *
from .partners import buyer, owned

def document_fields(d):
    v={k:textfield(d,k,lo,hi) for k,lo,hi in [('title',1,200),('number',0,100),('version',0,80),('note',0,1000),('batchNumber',0,150)]}
    v['kind']=choice(d,'kind',['contract','specification','coa','invoice','acceptance','other'])
    v['documentDate']=datefield(textfield(d,'documentDate',0,10),True)
    v['expiresAt']=datefield(textfield(d,'expiresAt',0,10),True)
    if v['documentDate'] and v['expiresAt'] and v['expiresAt']<v['documentDate']: fail(400,'Дата окончания не может быть раньше даты документа.')
    return v

def delivery_binding(uid,partner_id,raw,fields,old=None):
    old=old or {}
    key=textfield(raw,'deliveryId',0,36) if 'deliveryId' in raw else old.get('deliveryId','')
    if old.get('deliveryId') and key!=old['deliveryId']:fail(409,'Связь с поставкой нельзя заменить. Загрузите отдельный документ и архивируйте ошибочный.')
    if fields['kind'] in ['coa','invoice','acceptance'] and not key:fail(400,'Для этого документа выберите поставку.')
    if fields['kind']=='coa' and not fields['batchNumber']:fail(400,'Для COA укажите номер партии из документа.')
    snapshot=old.get('deliverySnapshot')
    if key and not old.get('deliveryId'):
        from .deliveries import owned_delivery
        key=uuidfield({'id':key},'id');v=owned_delivery(uid,key)
        if v['partnerId']!=partner_id:fail(404,'Поставка этого поставщика не найдена.')
        revision=str(raw.get('deliveryRevision',''))
        if revision!=str(v['revision']):fail(409,'Поставка изменилась. Обновите вкладку документов.')
        snapshot={k:v[k] for k in ['id','revision','product','reference','batchNumber','plannedDate']}
    if fields['kind']=='coa' and snapshot and snapshot.get('batchNumber') and fields['batchNumber']!=snapshot['batchNumber']:
        fail(400,'Номер партии COA не совпадает с сохранённой партией поставки.')
    return {'deliveryId':key,'deliverySnapshot':snapshot if key else None}


def receipt_binding(uid,raw,fields,old=None):
    old=old or {}
    key=textfield(raw,'receiptId',0,36) if 'receiptId' in raw else old.get('receiptId','')
    if old.get('receiptId') and key!=old['receiptId']:fail(409,'Связь с поступлением нельзя изменить. Загрузите отдельный документ.')
    snapshot=old.get('receiptSnapshot')
    if key and not old.get('receiptId'):
        key=uuidfield({'id':key},'id');r=getrec('delivery_receipt',key)
        if not r or r['userId']!=uid or r['deliveryId']!=fields.get('deliveryId'):fail(404,'Поступление этой поставки не найдено.')
        if r['voided']:fail(409,'Поступление отменено. Выберите действующую запись.')
        if r.get('opening'):fail(400,'Начальный накопленный объём не является отдельным поступлением.')
        if str(raw.get('receiptRevision',''))!=str(r['revision']):fail(409,'Поступление изменилось. Обновите документы.')
        snapshot={k:r[k] for k in ['id','revision','date','quantity','batchNumber']}
    if fields['kind']=='coa' and snapshot and snapshot['batchNumber'] and snapshot['batchNumber']!=fields['batchNumber']:
        fail(400,'Номер партии COA не совпадает с партией поступления.')
    return {'receiptId':key,'receiptSnapshot':snapshot if key else None}


def receipt_state(d):
    if not d.get('receiptId'):return 'none'
    r=getrec('delivery_receipt',d['receiptId'])
    if not r or r['userId']!=d['userId'] or r['deliveryId']!=d.get('deliveryId'):return 'unavailable'
    return 'voided' if r['voided'] else 'active'


def document_state(d):
    if d['archived']: return 'archived'
    if not d['expiresAt']: return 'no_date'
    if d['expiresAt']<today(): return 'expired'
    if d['expiresAt'] <= (date.fromisoformat(today())+timedelta(days=30)).isoformat(): return 'expiring'
    return 'dated'

def public_metadata(d):
    return {**{k:v for k,v in d.items() if k not in ['userId','sha256']},'expiryState':document_state(d),'receiptState':receipt_state(d),
            'downloadUrl':'/api/partner-documents?id='+d['id']}

def owned_document(uid,i):
    d=getrec('partner_document',i)
    if not d or d['userId']!=uid: fail(404,'Документ не найден.')
    owned(uid,d['partnerId'])
    return d

def partner_documents_api(req):
    uid=buyer(req)
    if req.method=='GET':
        if req.GET.get('id'):
            d=owned_document(uid,uuidfield(req.GET.dict(),'id'))
            path=settings.DOCUMENT_ROOT/'partner-private'/(d['id']+'.pdf')
            if not path.is_file(): fail(404,'Файл недоступен.')
            if path.stat().st_size!=d['size']: fail(409,'Размер сохранённого файла изменился. Обратитесь к оператору.')
            stream=path.open('rb')
            if hashlib.file_digest(stream,'sha256').hexdigest()!=d['sha256']:
                stream.close(); fail(409,'Контрольная сумма файла изменилась. Обратитесь к оператору.')
            stream.seek(0)
            response=FileResponse(stream,as_attachment=True,filename=d['filename'],content_type='application/pdf')
            response['Content-Security-Policy']="sandbox; default-src 'none'"
            return response
        p=owned(uid,uuidfield(req.GET.dict(),'partnerId'))
        rows=sorted(records('partner_document',uid,p['id']),key=lambda d:d['createdAt'],reverse=True)
        from .deliveries import owned_delivery
        if req.GET.get('deliveryId'):
            delivery=owned_delivery(uid,uuidfield(req.GET.dict(),'deliveryId'))
            if delivery['partnerId']!=p['id']:fail(404,'Поставка не найдена.')
            rows=[d for d in rows if d.get('deliveryId')==delivery['id']]
        options=[{'id':v['id'],'revision':v['revision'],'title':v['product']['name']+' · '+(v['reference'] or v['plannedDate']),'batchNumber':v['batchNumber']} for v in records('partner_delivery',uid,p['id'])]
        delivery_ids={v['id'] for v in options}
        receipts=[{k:r[k] for k in ['id','deliveryId','revision','date','quantity','batchNumber','voided','opening']} for r in records('delivery_receipt',uid) if r['deliveryId'] in delivery_ids]
        if req.GET.get('receiptId'):
            key=uuidfield(req.GET.dict(),'receiptId')
            if not any(r['id']==key for r in receipts):fail(404,'Поступление не найдено.')
            rows=[d for d in rows if d.get('receiptId')==key]
        return JsonResponse({'documents':[public_metadata(d) for d in rows],'deliveries':options,'receipts':receipts})
    if req.method=='POST':
        if req.content_type!='multipart/form-data': fail(415,'Ожидается загрузка PDF через multipart/form-data.')
        raw=req.POST.dict(); partner_id=uuidfield(raw,'partnerId'); fields=document_fields(raw)
        f=req.FILES.get('file')
        if not f or not 5<=f.size<=8*1024*1024 or f.read(5)!=b'%PDF-': fail(400,'Выберите PDF размером не более 8 МиБ.')
        f.seek(0); i=str(uuid.uuid4()); destination=settings.DOCUMENT_ROOT/'partner-private'/(i+'.pdf')
        try:
            with write_transaction():
                p=owned(uid,partner_id)
                if p['archived']: fail(409,'Сначала восстановите поставщика из архива.')
                fields.update(delivery_binding(uid,partner_id,raw,fields))
                fields.update(receipt_binding(uid,raw,fields))
                if len(records('partner_document',uid,partner_id))>=100: fail(409,'Лимит — 100 документов на поставщика, включая архив.')
                destination.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
                checksum=hashlib.sha256()
                with destination.open('xb') as output:
                    os.chmod(destination,0o600)
                    for chunk in f.chunks(): output.write(chunk); checksum.update(chunk)
                d={**fields,'id':i,'partnerId':partner_id,'userId':uid,'filename':Path(f.name).name[:200],
                   'size':f.size,'sha256':checksum.hexdigest(),'archived':False,'revision':1,'createdAt':stamp(),'updatedAt':stamp()}
                putrec('partner_document',i,d,uid,partner_id)
        except Exception:
            destination.unlink(missing_ok=True); raise
        return JsonResponse({'document':public_metadata(d)},status=201)
    if req.method!='PATCH': fail(405,'Метод не поддерживается.')
    if req.content_type!='application/json': fail(415,'Ожидается JSON.')
    if len(req.body)>16000: fail(413,'Запрос слишком большой.')
    try: raw=obj(json.loads(req.body,parse_constant=lambda _:fail(400,'Некорректный JSON.')))
    except (ValueError,UnicodeError,RecursionError): fail(400,'Некорректный JSON.')
    with write_transaction():
        d=owned_document(uid,uuidfield(raw,'id')); p=owned(uid,d['partnerId'])
        if p['archived']: fail(409,'Сначала восстановите поставщика из архива.')
        if type(raw.get('revision')) is not int or raw['revision']!=d['revision']: fail(409,'Документ изменился. Обновите список.')
        if type(raw.get('archived')) is not bool: fail(400,'Некорректный признак архива.')
        fields=document_fields(raw)
        fields.update(delivery_binding(uid,p['id'],raw,fields,d))
        fields.update(receipt_binding(uid,raw,fields,d))
        d.update(fields); d['archived']=raw['archived'];d['revision']+=1;d['updatedAt']=stamp()
        putrec('partner_document',d['id'],d,uid,d['partnerId'])
    return JsonResponse({'document':public_metadata(d)})
