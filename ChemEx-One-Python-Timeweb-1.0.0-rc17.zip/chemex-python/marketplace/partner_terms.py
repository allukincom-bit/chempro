"""Private cooperation notes; never supplier confirmation or RFQ price defaults."""
from datetime import timedelta
from .core import *
from .partner_workspace import validate_link


def terms_state(t):
    if not t: return 'empty'
    if t['status']!='agreed': return t['status']
    if t['validUntil'] and t['validUntil']<today(): return 'expired'
    if t['reviewDate'] and t['reviewDate']<=today(): return 'review'
    if t['validUntil'] and t['validUntil']<=(date.fromisoformat(today())+timedelta(days=30)).isoformat(): return 'expiring'
    return 'recorded'


def save_terms(r,d):
    if r['archived']: fail(409,'Сначала восстановите поставщика из архива.')
    raw=obj(d.get('terms'));t={k:textfield(raw,k,0,limit) for k,limit in [
        ('payment',1500),('delivery',1500),('minimumOrder',500),('leadTime',500),('source',1000),('notes',2000)]}
    t['status']=choice(raw,'status',['draft','agreed','inactive'])
    for k in ['agreedOn','validUntil','reviewDate']: t[k]=datefield(textfield(raw,k,0,10),True)
    if t['agreedOn'] and t['agreedOn']>today(): fail(400,'Дата договорённости не может быть в будущем (UTC).')
    if t['validUntil'] and t['agreedOn'] and t['validUntil']<t['agreedOn']: fail(400,'Окончание не может быть раньше договорённости.')
    old=r.get('terms') or {}; document_id=textfield(raw,'documentId',0,36)
    if document_id:
        # An unchanged archived source remains a valid historical reference.
        if document_id==old.get('documentId'):
            doc=getrec('partner_document',document_id)
            if not doc or doc['userId']!=r['userId'] or doc['partnerId']!=r['id']: fail(404,'Документ не найден.')
        else:
            validate_link(r,{'kind':'document','id':document_id});doc=getrec('partner_document',document_id)
        t['documentTitle']=doc['title'];t['documentRevision']=doc['revision']
    else: t['documentTitle']='';t['documentRevision']=None
    t['documentId']=document_id
    if t['status']=='agreed':
        if not t['agreedOn'] or not (t['source'] or document_id): fail(400,'Укажите дату и источник договорённости.')
        if not any(t[k] for k in ['payment','delivery','minimumOrder','leadTime']): fail(400,'Заполните хотя бы одно условие сотрудничества.')
    reason=textfield(d,'reason',3,1000)
    t.update(version=old.get('version',0)+1,updatedAt=stamp())
    i=nextid('partner_terms_event')
    putrec('partner_terms_event',i,{'id':i,'terms':t,'reason':reason,'createdAt':t['updatedAt']},r['userId'],r['id'])
    r['terms']=t


def terms_history(r,before=None):
    rows=sorted([e for e in records('partner_terms_event',r['userId'],r['id']) if before is None or e['id']<before],key=lambda e:e['id'],reverse=True)
    return {'termsEvents':rows[:20],'termsBefore':rows[19]['id'] if len(rows)>20 else None}
