"""Owner-scoped attention feed, explicit task references and sourcing preferences."""
from datetime import timedelta
from .core import *


def attention(r, history):
    if r['archived']: return []
    now = date.fromisoformat(today()); items = []
    def add(kind, title, due, target):
        items.append(dict(kind=kind, title=title, date=due, targetId=target))
    if r['nextDate'] and r['nextDate'] <= now.isoformat():
        add('task', r['nextAction'], r['nextDate'], r['id'])
    for task in records('supplier_task',r['userId'],r['id']):
        if task['status']=='open' and task['dueDate']<=now.isoformat():
            add('supplier_task',task['title'],task['dueDate'],task['id'])
    t=r.get('terms') or {}
    if t.get('status')=='agreed':
        if t.get('validUntil') and t['validUntil']<=(now+timedelta(days=30)).isoformat():
            add('terms_expiry','Проверить срок условий сотрудничества',t['validUntil'],r['id'])
        if t.get('reviewDate') and t['reviewDate']<=now.isoformat():
            add('terms_review','Проверить актуальность условий',t['reviewDate'],r['id'])
    for issue in records('delivery_issue',r['userId'],r['id']):
        if issue['status'] not in ['resolved','cancelled'] and issue['reviewDate'] and issue['reviewDate']<=now.isoformat():
            add('issue_review','Проверить урегулирование: '+issue['title'],issue['reviewDate'],issue['id'])
    for delivery in records('partner_delivery',r['userId'],r['id']):
        if delivery['status'] in ['planned','partial'] and delivery['plannedDate']<now.isoformat():
            add('delivery_overdue','Проверить получение: '+delivery['product']['name'],delivery['plannedDate'],delivery['id'])
    for q in history:
        if q['status'] == 'sent':
            add('waiting', 'Ожидается ответ: '+q['product'], (q.get('sentAt') or q['createdAt'])[:10], q['id'])
        if q['status'] == 'quoted':
            try:
                raw = q.get('quotation'); quote = json.loads(raw) if isinstance(raw,str) else raw
                due = date.fromisoformat(quote['validUntil'])
            except (ValueError, TypeError, KeyError): continue
            if due <= now+timedelta(days=7):
                add('quote_expired' if due<now else 'quote_expiring', 'Предложение: '+q['product'], due.isoformat(), q['id'])
    for d in records('partner_document',r['userId'],r['id']):
        if d['archived'] or not d['expiresAt']: continue
        due=date.fromisoformat(d['expiresAt'])
        if due<=now+timedelta(days=30):
            add('document_expired' if due<now else 'document_expiring', d['title'],due.isoformat(),d['id'])
    return sorted(items,key=lambda x:(x['date'],x['kind'],str(x['targetId'])))


def validate_link(r, raw):
    if raw is None: return None
    raw=obj(raw); kind=choice(raw,'kind',['request','document','delivery','issue']); i=uuidfield(raw,'id')
    target=getrec({'request':'request','document':'partner_document','delivery':'partner_delivery','issue':'delivery_issue'}[kind],i)
    if not target or target['userId']!=r['userId']: fail(404,'Связанный объект не найден.')
    if kind=='request':
        if target['recipientId']!=r['supplierId'] or target['status'] not in ['sent','quoted']: fail(404,'Запрос этого поставщика не найден.')
        title=target['product']
    else:
        if target['partnerId']!=r['id']: fail(404,'Объект этого поставщика не найден.')
        if kind=='document' and target['archived']: fail(409,'Документ находится в архиве.')
        title=(target['product']['name']+' · '+(target['reference'] or target['plannedDate'])) if kind=='delivery' else target['title']
    return {'kind':kind,'id':i,'title':title}


def set_role(r,d):
    i=positive(d.get('offerId')); role=choice(d,'supplyRole',['none','primary','backup'])
    pin=next((p for p in r['products'] if p['id']==i),None)
    if not pin: fail(404,'Закреплённый товар не найден.')
    if role!='none':
        from .partners import supplier_offer
        if r['archived'] or r['status']=='paused': fail(409,'Сначала возобновите работу с поставщиком.')
        o=supplier_offer(r['supplierId'],i)
        if not pin.get('chemexId') or (pin['chemexId'],pin['cas'])!=(o.get('chemexId'),o['cas']): fail(409,'Товар изменился. Закрепите актуальное предложение.')
        if role=='primary':
            for other in records('partner',r['userId']):
                for p in other['products']:
                    if (other['id'],p['id'])!=(r['id'],i) and p.get('chemexId')==pin['chemexId'] and p.get('supplyRole')=='primary':
                        fail(409,'Основной поставщик уже назначен. Сначала снимите прежнюю отметку, в том числе в архиве.')
    pin['supplyRole']=role
