"""Private buyer/supplier relationships. No administrator bypass and no public notes."""
from .core import *
from .market import requests_api
from .partner_workspace import attention, validate_link, set_role
from .partner_terms import terms_state, save_terms, terms_history

STATUSES = ['trial', 'regular', 'reserve', 'paused']

def buyer(req):
    uid = user(req)['userId']
    if profile(uid)['role'] == 'supplier': fail(403, 'Для работы с поставщиками выберите роль покупателя или обе роли.')
    return uid

def owned(uid, key):
    r = getrec('partner', key)
    if not r or r['userId'] != uid: fail(404, 'Поставщик не найден в вашем списке.')
    return r

def snapshot(o):
    return {k:o.get(k) or '' for k in ['id', 'name', 'cas', 'chemexId', 'manufacturer', 'grade']}

def supplier_offer(supplier, i):
    o = getrec('offer', i); p = getrec('profile', supplier)
    if not o or o['userId'] != supplier or not visible(o) or not p or p['role'] == 'buyer':
        fail(409, 'Предложение поставщика недоступно. Выберите действующее предложение.')
    return o

def current_products(r):
    p = getrec('profile', r['supplierId'])
    if not p or p['role'] == 'buyer': return []
    return [snapshot(o) for o in records('offer', r['supplierId']) if visible(o)]

def history(r):
    return sorted([q for q in records('request', r['userId'], r['supplierId']) if q['status'] in ['sent','quoted']],
                  key=lambda q:q.get('sentAt') or q['createdAt'], reverse=True)

def task_state(r):
    if not r['nextDate'] or r['archived']: return 'none'
    if r['nextDate'] < today(): return 'overdue'
    if r['nextDate'] == today(): return 'today'
    return 'planned'

def task_event(r, action, note='', next_action='', next_date=''):
    i = nextid('partner_task_event')
    putrec('partner_task_event',i,{'id':i,'action':action,'title':r['nextAction'],'dueDate':r['nextDate'],
        'nextAction':next_action,'nextDate':next_date,'taskLink':r.get('taskLink'),'note':note,'createdAt':stamp()},r['userId'],r['id'])

def present(r, detail=False, before=None, terms_before=None):
    p = getrec('profile', r['supplierId']) or {}
    verified = bool(p and any(v['status'] == 'bank_confirmed' and v['fingerprint'] == fingerprint(p)
                             for v in records('verification', r['supplierId'])))
    offers = current_products(r); by_id = {o['id']:o for o in offers}
    pins = []
    for pin in r['products']:
        o = by_id.get(pin['id'])
        changed = bool(o and (o['chemexId'] != pin['chemexId'] or o['cas'] != pin['cas']))
        pins.append({**pin, 'available': bool(o), 'identityChanged': changed})
    hist = history(r)
    last = max([q.get('repliedAt') or q.get('sentAt') or q['createdAt'] for q in hist], default=None)
    thread_ids = {q['id'] for q in hist}
    messages = [m for m in records('message') if m['requestId'] in thread_ids]
    if messages: last = max([m['createdAt'] for m in messages]+([last] if last else []))
    open_tasks=[t for t in records('supplier_task',r['userId'],r['id']) if t['status']=='open']
    out = {**r, 'openTaskCount':len(open_tasks), 'dueTaskCount':sum(t['dueDate']<=today() for t in open_tasks), 'termsState':terms_state(r.get('terms')), 'attention':attention(r,hist), 'taskLink':r.get('taskLink'), 'companyName':p.get('companyName', r['companyName']), 'country':p.get('country',r['country']),
           'bankConfirmed':verified, 'products':pins, 'lastInteraction':last, 'requestCount':len(hist),
           'publicationRestricted':hidden('company',r['supplierId']),
           'actionDue':bool(not r['archived'] and (any(t['dueDate']<=today() for t in open_tasks) or r['nextDate'] and r['nextDate']<=today())), 'taskState':task_state(r)}
    if detail:
        out.update(terms_history(r,terms_before))
        out['linkDeliveries']=[{'id':v['id'],'title':v['product']['name']+' · '+(v['reference'] or v['plannedDate'])} for v in records('partner_delivery',r['userId'],r['id'])]
        out['linkIssues']=[{'id':v['id'],'title':v['title']} for v in records('delivery_issue',r['userId'],r['id'])]
        events=sorted([e for e in records('partner_task_event',r['userId'],r['id']) if before is None or e['id']<before],key=lambda e:e['id'],reverse=True)
        out.update(history=hist, availableProducts=offers,taskEvents=events[:50],taskBefore=events[49]['id'] if len(events)>50 else None, linkDocuments=[{'id':d['id'],'title':d['title']} for d in records('partner_document',r['userId'],r['id']) if not d['archived']])
    return out

def edit_fields(d):
    p = {k:textfield(d,k,0,hi) for k,hi in [('notes',4000),('contactName',120),('contactEmail',254),('contactPhone',60),('nextAction',300)]}
    if p['contactEmail']: emailfield(p,'contactEmail')
    p['nextDate'] = datefield(textfield(d,'nextDate',0,10),True)
    if bool(p['nextDate']) != bool(p['nextAction']): fail(400,'Укажите действие вместе с датой или очистите оба поля.')
    p['status'] = choice(d,'status',STATUSES)
    for k in ['approved','archived']:
        if type(d.get(k)) is not bool: fail(400,'Проверьте поле: '+k)
        p[k] = d[k]
    tags = d.get('tags',[])
    if not isinstance(tags,list) or len(tags)>10: fail(400,'Допустимо до 10 меток.')
    p['tags'] = []; seen = set()
    for raw in tags:
        t = textfield({'v':raw},'v',1,40)
        if norm(t) not in seen: p['tags'].append(t); seen.add(norm(t))
    return p

def partners_api(req, d):
    uid = buyer(req)
    if req.method == 'GET':
        if req.GET.get('quoteHistory')=='1':
            from .quote_history import quote_history
            return quote_history(uid)
        if req.GET.get('batches')=='1' or req.GET.get('batchId'):
            from .batch_tracking import batch_tracking
            return batch_tracking(req,uid)
        if req.GET.get('supply')=='1':
            from .supply_matrix import supply_matrix
            return {'groups':supply_matrix(uid),'generatedAt':stamp()}
        if req.GET.get('id'):
            r = owned(uid,uuidfield(req.GET.dict(),'id'))
            before=pageparam(req.GET,'taskBefore',2147483647,2147483647) if req.GET.get('taskBefore') is not None else None
            terms_before=pageparam(req.GET,'termsBefore',2147483647,2147483647) if req.GET.get('termsBefore') is not None else None
            return {'partner':present(r,True,before,terms_before)}
        return {'partners':[present(r) for r in sorted(records('partner',uid),key=lambda x:x['updatedAt'],reverse=True)]}
    if req.method != 'POST': fail(405,'Метод не поддерживается.')
    action = choice(d,'action',['add','update','pin','unpin','repeat','complete_task','reschedule_task','link_task','supply_role','save_terms','batch_requests','schedule_linked_task'])
    if action == 'batch_requests':
        from .batch_requests import batch_requests
        return batch_requests(req,uid,d)
    if action == 'add':
        o = None
        if d.get('requestId'):
            q = getrec('request',uuidfield(d,'requestId'))
            if not q or q['userId'] != uid or q['status'] not in ['sent','quoted'] or not q['recipientId']: fail(404,'Отправленный запрос не найден.')
            supplier = q['recipientId']
            company = q['supplierCompany']; country = ''
        else:
            pid = positive(d.get('productId'))
            if pid <= 100000: fail(400,'Демонстрационную компанию нельзя добавить в постоянные поставщики.')
            o = getrec('offer',pid-100000)
            if not o: fail(404,'Предложение не найдено.')
            supplier = o['userId']; o = supplier_offer(supplier,o['id'])
            company = ''; country = ''
        if supplier == uid: fail(400,'Нельзя добавить свою компанию.')
        existing = records('partner',uid,supplier)
        if existing: return {'partner':present(existing[0],True),'existing':True}
        p = getrec('profile',supplier) or {}
        r = {'id':str(uuid.uuid4()),'userId':uid,'supplierId':supplier,'companyName':p.get('companyName',company),
             'country':p.get('country',country),'status':'trial','archived':False,'approved':False,'approvedAt':None,
             'notes':'','tags':[],'contactName':'','contactEmail':'','contactPhone':'','nextAction':'','nextDate':'',
             'products':[snapshot(o)] if o else [],'revision':1,'createdAt':stamp(),'updatedAt':stamp()}
        putrec('partner',r['id'],r,uid,supplier,r['status'])
        return {'partner':present(r,True),'existing':False}
    r = owned(uid,uuidfield(d,'id'))
    if type(d.get('revision')) is not int or d['revision'] != r['revision']: fail(409,'Карточка изменилась. Обновите её перед сохранением.')
    if action == 'schedule_linked_task':
        if r['archived']: fail(409,'Сначала восстановите поставщика из архива.')
        if r['nextDate']: fail(409,'У поставщика уже есть открытая задача. Завершите или измените её во вкладке задач.')
        title=textfield(d,'nextAction',3,300);due=datefield(textfield(d,'nextDate',10,10))
        if due<today(): fail(400,'Нельзя назначить новое действие в прошлом (UTC).')
        link=validate_link(r,d.get('taskLink'))
        if not link or link['kind'] not in ['delivery','issue']: fail(400,'Выберите поставку или замечание.')
        r.update(nextAction=title,nextDate=due,taskLink=link)
        task_event(r,'scheduled',next_action=title,next_date=due)
    elif action == 'save_terms':
        save_terms(r,d)
    elif action == 'supply_role':
        set_role(r,d)
    elif action == 'link_task':
        if r['archived'] or not r['nextDate']: fail(409,'Нужна открытая задача у активного поставщика.')
        link=validate_link(r,d.get('taskLink'))
        task_event(r,'linked',next_action=r['nextAction'],next_date=r['nextDate'])
        r['taskLink']=link
    elif action == 'update':
        fields = edit_fields(d)
        fields['approvedAt'] = (r['approvedAt'] if r['approved'] else stamp()) if fields['approved'] else None
        if (fields['nextAction'],fields['nextDate']) != (r['nextAction'],r['nextDate']):
            if r['archived']: fail(409,'Сначала восстановите поставщика из архива.')
            event_type='scheduled' if not r['nextDate'] else 'cancelled' if not fields['nextDate'] else 'changed'
            task_event(r,event_type,next_action=fields['nextAction'],next_date=fields['nextDate'])
        r.update(fields)
        if not r['nextDate']: r['taskLink']=None
    elif action in ['complete_task','reschedule_task']:
        if r['archived']: fail(409,'Сначала восстановите поставщика из архива.')
        if not r['nextDate']: fail(409,'Нет запланированного действия.')
        note=textfield(d,'note',3 if action=='reschedule_task' else 0,1000)
        if action=='reschedule_task':
            new_date=datefield(textfield(d,'nextDate',10,10))
            if new_date<today() or new_date==r['nextDate']: fail(400,'Выберите другую дату, не ранее сегодняшнего дня (UTC).')
            task_event(r,'rescheduled',note,r['nextAction'],new_date)
            r['nextDate']=new_date
        else:
            next_action=textfield(d,'nextAction',0,300)
            next_date=datefield(textfield(d,'nextDate',0,10),True)
            if bool(next_action)!=bool(next_date): fail(400,'Укажите следующее действие вместе с датой.')
            if next_date and next_date<today(): fail(400,'Новое действие нельзя назначить в прошлом (UTC).')
            task_event(r,'completed',note,next_action,next_date)
            r.update(nextAction=next_action,nextDate=next_date,taskLink=None)
    elif action in ['pin','unpin']:
        i = positive(d.get('offerId'))
        if action == 'unpin': r['products'] = [p for p in r['products'] if p['id'] != i]
        else:
            if r['archived']: fail(409,'Сначала восстановите поставщика из архива.')
            o = supplier_offer(r['supplierId'],i)
            if not any(p['id'] == i for p in r['products']) and len(r['products']) >= 100: fail(409,'Допустимо до 100 закреплённых товаров.')
            old=next((p for p in r['products'] if p['id']==i),{})
            role=old.get('supplyRole','none') if old.get('chemexId')==o.get('chemexId') and old.get('cas')==o['cas'] else 'none'
            r['products'] = [p for p in r['products'] if p['id'] != i] + [{**snapshot(o),'supplyRole':role}]
    else:
        if r['archived'] or r['status']=='paused': fail(409,'Сначала возобновите работу с поставщиком.')
        source = None
        if d.get('requestId'):
            source = getrec('request',uuidfield(d,'requestId'))
            if not source or source['userId'] != uid or source['recipientId'] != r['supplierId'] or source['status'] not in ['sent','quoted']: fail(404,'Исходный запрос не найден.')
            i = source['productId'] - 100000
        else: i = positive(d.get('offerId'))
        o = supplier_offer(r['supplierId'],i)
        if source and (not source.get('chemexId') or source['chemexId'] != o.get('chemexId') or source['cas'] != o['cas']):
            fail(409,'Идентичность товара изменилась или не сохранена. Выберите действующее предложение и создайте новый запрос.')
        if d.get('expectedChemexId') != o.get('chemexId') or d.get('expectedCas') != o['cas']:
            fail(409,'Товар изменился после открытия формы. Обновите список предложений.')
        # The shared request validator creates a PRIVATE draft, never a sent request.
        body = {k:d[k] for k in ['quantity','unit','destination','email','message','specification','requestedDocuments'] if k in d}
        body['productId'] = 100000+i
        result = requests_api(req,body)
        q = result['request']; q['partnerId'] = r['id']; q['sourceRequestId'] = source['id'] if source else None
        putrec('request',q['id'],q,uid,status='draft')
        return {'request':q}
    r['revision'] += 1; r['updatedAt'] = stamp()
    putrec('partner',r['id'],r,uid,r['supplierId'],r['status'])
    return {'partner':present(r,True)}
