"""Historical supplier proposals, never a ledger of actual purchases."""
from .core import *
from .supply_matrix import quote_state

QUOTE_FIELDS={'price':'Цена','currency':'Валюта','unit':'Единица цены','vatMode':'Условия НДС','vatRate':'Ставка НДС',
 'moqQuantity':'Минимальная партия','moqUnit':'Единица минимальной партии','paymentTerms':'Оплата','incoterm':'Базис поставки',
 'lead':'Срок поставки','packaging':'Упаковка','message':'Комментарий поставщика'}
REQUEST_FIELDS={'quantity':'Запрошенный объём','unit':'Единица объёма','destination':'Место поставки','specification':'Требования к сырью',
 'requestedDocuments':'Запрошенные документы','message':'Комментарий покупателя'}


def decoded(q):
    try:
        value=json.loads(q['quotation']) if isinstance(q.get('quotation'),str) else q.get('quotation')
        return value if isinstance(value,dict) else None
    except (ValueError,TypeError):return None


def quote_history(uid):
    partners={p['supplierId']:p for p in records('partner',uid)}
    rows=sorted([q for q in records('request',uid) if q['status']=='quoted' and q.get('recipientId') in partners],
                key=lambda q:(q.get('repliedAt') or '',q['id']))
    result=[];groups={}
    for q in rows:
        p=partners[q['recipientId']];identity=tuple(q.get(k) or '' for k in ['chemexId','cas','manufacturer','grade'])
        # Only saved complete identity and known response timestamps support automatic pairing.
        key=(q['recipientId'],)+identity
        prior=None
        if all(identity) and q.get('repliedAt'):
            state=groups.get(key)
            if state:
                if state['time']!=q['repliedAt']:state={'time':q['repliedAt'],'previous':state['last'],'last':q}
                else:state={**state,'last':q}
                prior=state['previous']
            else:state={'time':q['repliedAt'],'previous':None,'last':q}
            groups[key]=state
        old=decoded(prior) if prior else None;new=decoded(q)
        changes=[]
        if old is not None and new is not None:
            changes=[label for k,label in QUOTE_FIELDS.items() if old.get(k)!=new.get(k)]
            changes += [label for k,label in REQUEST_FIELDS.items() if prior.get(k)!=q.get(k)]
        result.append({'request':q,'partnerId':p['id'],'companyName':q.get('supplierCompany') or p['companyName'],
                       'archived':p['archived'],'quoteState':quote_state(q),'previousId':prior['id'] if prior else None,
                       'changes':changes,'comparisonAvailable':old is not None and new is not None})
    return {'entries':list(reversed(result)),'generatedAt':stamp()}
