"""Optional per-delivery receipt journal; void entries instead of deleting history."""
from decimal import Decimal
from .core import *
from .deliveries import owned_delivery, present_delivery


def receipt_rows(uid,delivery_id):
    return sorted(records('delivery_receipt',uid,delivery_id),key=lambda x:(x['date'],x['createdAt'],x['id']),reverse=True)


def save_delivery(v,reason):
    v['revision']+=1;v['updatedAt']=stamp()
    event_id=nextid('delivery_event')
    putrec('delivery_event',event_id,{'id':event_id,'createdAt':v['updatedAt'],'reason':reason,
        'snapshot':{k:x for k,x in v.items() if k not in ['creationDigest','userId']}},v['userId'],v['id'])
    putrec('partner_delivery',v['id'],v,v['userId'],v['partnerId'],v['status'])


def recompute(v):
    active=[x for x in receipt_rows(v['userId'],v['id']) if not x['voided']]
    total=sum((Decimal(x['quantity']) for x in active),Decimal('0'))
    if total>Decimal('999999999.999'):fail(400,'Суммарное получение превышает допустимый объём.')
    v['receivedQuantity']=format(total,'f') if total else ''
    v['receivedDate']=max((x['date'] for x in active),default='')
    v['status']='planned' if not total else 'received' if total>=Decimal(v['quantity']) else 'partial'
    if not total:v['inspection']='unchecked'


def public_receipt(x):
    return {k:v for k,v in x.items() if k not in ['userId','creationDigest']}


def receipts_api(req,d):
    from .partners import buyer,owned
    uid=buyer(req)
    if req.method=='GET':
        v=owned_delivery(uid,uuidfield(req.GET.dict(),'deliveryId'));owned(uid,v['partnerId'])
        total=Decimal(v['receivedQuantity'] or '0');planned=Decimal(v['quantity'])
        return {'delivery':present_delivery(v),'receipts':[public_receipt(x) for x in receipt_rows(uid,v['id'])],
                'remainingQuantity':format(max(planned-total,Decimal('0')),'f'),'excessQuantity':format(max(total-planned,Decimal('0')),'f')}
    if req.method!='POST':fail(405,'Метод не поддерживается.')
    action=choice(d,'action',['enable','add','void'])
    v=owned_delivery(uid,uuidfield(d,'deliveryId'));p=owned(uid,v['partnerId'])
    if action=='enable' and v.get('receiptJournal'):return {'delivery':present_delivery(v),'replayed':True}
    if action=='add':
        i=uuidfield(d,'clientId');fp=digest(d);previous=getrec('delivery_receipt',i)
        if previous:
            if previous['userId']!=uid or previous['deliveryId']!=v['id'] or previous.get('creationDigest')!=fp:fail(409,'Попытка уже обработана с другими данными. Обновите журнал.')
            return {'delivery':present_delivery(v),'receipt':public_receipt(previous),'replayed':True}
    if p['archived']:fail(409,'Сначала восстановите поставщика из архива.')
    if type(d.get('deliveryRevision')) is not int or d['deliveryRevision']!=v['revision']:fail(409,'Поставка изменилась. Обновите журнал.')
    reason=textfield(d,'reason',3,1000)
    if action=='enable':
        v['receiptJournal']=True
        if v['receivedQuantity']:
            i=str(uuid.uuid5(uuid.NAMESPACE_URL,'chemex:receipt-opening:'+v['id']))
            row={'id':i,'userId':uid,'deliveryId':v['id'],'quantity':v['receivedQuantity'],'date':v['receivedDate'],'batchNumber':v['batchNumber'],
                 'note':'Накопленный объём до включения журнала; не отдельное поступление.','opening':True,'voided':False,'revision':1,
                 'createdAt':stamp(),'voidReason':'','voidedAt':None}
            putrec('delivery_receipt',i,row,uid,v['id'])
        save_delivery(v,reason)
        return {'delivery':present_delivery(v),'replayed':False}
    if not v.get('receiptJournal'):fail(409,'Сначала включите журнал поступлений.')
    if action=='add':
        if v['status']=='cancelled':fail(409,'Сначала возобновите отменённую поставку.')
        amount=numberstr(d,'quantity',9,3);day=datefield(textfield(d,'date',10,10))
        if day>today():fail(400,'Дата фактического получения не может быть в будущем (UTC).')
        batch=textfield(d,'batchNumber',0,150)
        if v['batchNumber'] and batch!=v['batchNumber']:fail(400,'Партия должна совпадать с указанной партией поставки.')
        row={'id':i,'userId':uid,'deliveryId':v['id'],'quantity':amount,'date':day,'batchNumber':batch,'note':textfield(d,'note',0,1000),
             'opening':False,'voided':False,'revision':1,'createdAt':stamp(),'voidReason':'','voidedAt':None,'creationDigest':fp}
        putrec('delivery_receipt',i,row,uid,v['id'])
    else:
        i=uuidfield(d,'id');row=getrec('delivery_receipt',i)
        if not row or row['userId']!=uid or row['deliveryId']!=v['id']:fail(404,'Поступление не найдено.')
        if row['voided'] or type(d.get('revision')) is not int or row['revision']!=d['revision']:fail(409,'Поступление уже изменено. Обновите журнал.')
        row.update(voided=True,voidReason=reason,voidedAt=stamp(),revision=row['revision']+1)
        putrec('delivery_receipt',i,row,uid,v['id'])
    recompute(v);save_delivery(v,reason)
    return {'delivery':present_delivery(v),'receipt':public_receipt(row),'replayed':False}
