"""Buyer's pinned sourcing alternatives, grouped by saved product identity."""
from .core import *


def quote_state(q):
    if not q: return 'none'
    try:
        raw=q.get('quotation'); raw=json.loads(raw) if isinstance(raw,str) else raw
        due=date.fromisoformat(raw['validUntil'])
    except (ValueError,TypeError,KeyError): return 'unknown'
    return 'expired' if due.isoformat()<today() else 'dated'


def supply_matrix(uid):
    from .partners import present, history
    groups={}
    for raw in records('partner',uid):
        p=present(raw);hist=history(raw)
        for pin in p['products']:
            # Unknown identifiers must never collapse distinct products into one group.
            identity=(pin.get('chemexId') or '',pin.get('cas') or '',pin.get('manufacturer') or '',pin.get('grade') or '')
            key=identity if identity[0] else ('unknown',p['id'],pin['id'])
            g=groups.setdefault(key,{'chemexId':identity[0],'cas':identity[1],'manufacturer':identity[2],'grade':identity[3],
                                    'name':pin['name'],'suppliers':[]})
            matching=[q for q in hist if q['status']=='quoted' and identity[0] and
                      tuple(q.get(k) or '' for k in ['chemexId','cas','manufacturer','grade'])==identity]
            latest=max(matching,key=lambda q:(q.get('repliedAt') or q['createdAt'],q['id']),default=None)
            eligible=not p['archived'] and p['status']!='paused' and pin['available'] and not pin['identityChanged'] and bool(identity[0])
            g['suppliers'].append({'partnerId':p['id'],'supplierId':p['supplierId'],'companyName':p['companyName'],'country':p['country'],
                'revision':p['revision'],'status':p['status'],'archived':p['archived'],'bankConfirmed':p['bankConfirmed'],
                'offerId':pin['id'],'role':pin.get('supplyRole','none'),'available':pin['available'],'identityChanged':pin['identityChanged'],
                'eligible':eligible,'latestQuote':latest,'quoteState':quote_state(latest)})
    result=[]
    for g in groups.values():
        active=[s for s in g['suppliers'] if s['eligible']]
        primary={s['supplierId'] for s in active if s['role']=='primary'}
        backup={s['supplierId'] for s in active if s['role']=='backup'}-primary
        g.update(supplierCount=len({s['supplierId'] for s in g['suppliers']}),availableCount=len({s['supplierId'] for s in active}),
                 hasPrimary=bool(primary),hasBackup=bool(backup))
        g['warnings']=[]
        if not g['chemexId']: g['warnings'].append('ChemEx ID не сохранён: товар показан отдельно.')
        if not primary:g['warnings'].append('Нет доступного основного поставщика.')
        if not backup:g['warnings'].append('Нет доступного резервного поставщика другой компании.')
        if g['availableCount']==1:g['warnings'].append('Доступен только один поставщик.')
        if not active:g['warnings'].append('Нет доступных источников снабжения.')
        g['suppliers'].sort(key=lambda s:({'primary':0,'backup':1,'none':2}.get(s['role'],2),s['companyName'],s['offerId']))
        result.append(g)
    return sorted(result,key=lambda g:(g['name'],g['chemexId'],g['manufacturer'],g['grade']))
