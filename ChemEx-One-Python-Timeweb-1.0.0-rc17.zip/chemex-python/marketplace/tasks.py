"""Independent private supplier tasks with versioned audit history."""
from .core import *


def owned_task(uid,i):
    t=getrec('supplier_task',i)
    if not t or t['userId']!=uid:fail(404,'Задача не найдена.')
    return t


def task_public(t,p):
    state='closed' if t['status']!='open' else 'overdue' if t['dueDate']<today() else 'today' if t['dueDate']==today() else 'planned'
    return {**{k:v for k,v in t.items() if k not in ['userId','creationDigest']},'state':state,'archived':p['archived'],'companyName':p['companyName']}


def tasks_api(req,d):
    from .partners import buyer,owned
    from .partner_workspace import validate_link
    uid=buyer(req)
    if req.method=='GET':
        if req.GET.get('id'):
            t=owned_task(uid,uuidfield(req.GET.dict(),'id'));p=owned(uid,t['partnerId'])
            before=pageparam(req.GET,'before',2147483647,2147483647)
            events=sorted([e for e in records('supplier_task_event',uid,t['id']) if e['revision']<before],key=lambda e:e['revision'],reverse=True)
            return {'task':task_public(t,p),'events':events[:20],'before':events[19]['revision'] if len(events)>20 else None}
        partners={p['id']:p for p in records('partner',uid)}
        if req.GET.get('partnerId'):
            p=owned(uid,uuidfield(req.GET.dict(),'partnerId'));partners={p['id']:p}
        tasks=[task_public(t,partners[t['partnerId']]) for t in records('supplier_task',uid) if t['partnerId'] in partners]
        return {'tasks':sorted(tasks,key=lambda t:(t['dueDate'],{'high':0,'normal':1,'low':2}[t['priority']],t['id']))}
    if req.method!='POST':fail(405,'Метод не поддерживается.')
    action=choice(d,'action',['create','update'])
    if action=='create':
        i=uuidfield(d,'clientId');fp=digest(d);old=getrec('supplier_task',i)
        if old:
            if old['userId']!=uid or old.get('creationDigest')!=fp:fail(409,'Попытка уже обработана с другими данными. Обновите список.')
            return {'task':task_public(old,owned(uid,old['partnerId'])),'replayed':True}
        p=owned(uid,uuidfield(d,'partnerId'))
        t={'id':i,'partnerId':p['id'],'userId':uid,'revision':0,'createdAt':stamp(),'creationDigest':fp,'closedAt':None}
    else:
        t=owned_task(uid,uuidfield(d,'id'));p=owned(uid,t['partnerId'])
        if type(d.get('revision')) is not int or d['revision']!=t['revision']:fail(409,'Задача изменилась. Обновите список.')
    if p['archived']:fail(409,'Сначала восстановите поставщика из архива.')
    fields={k:textfield(d,k,lo,hi) for k,lo,hi in [('title',3,300),('notes',0,2000),('result',0,1000)]}
    fields['status']=choice(d,'status',['open','done','cancelled'])
    fields['priority']=choice(d,'priority',['low','normal','high'])
    fields['dueDate']=datefield(textfield(d,'dueDate',10,10))
    if fields['status']!='open' and not fields['result']:fail(400,'Укажите результат выполнения или причину отмены.')
    link=d.get('taskLink')
    fields['taskLink']=t.get('taskLink') if action=='update' and link==t.get('taskLink') else validate_link(p,link)
    reason=textfield(d,'reason',3,1000)
    fields['closedAt']=(t.get('closedAt') or stamp()) if fields['status']!='open' else None
    t.update(fields);t['revision']+=1;t['updatedAt']=stamp()
    snapshot={k:v for k,v in t.items() if k not in ['userId','creationDigest']}
    putrec('supplier_task_event',str(uuid.uuid4()),{'revision':t['revision'],'createdAt':t['updatedAt'],'reason':reason,'snapshot':snapshot},uid,t['id'])
    putrec('supplier_task',t['id'],t,uid,p['id'],t['status'])
    return {'task':task_public(t,p),'replayed':False}
