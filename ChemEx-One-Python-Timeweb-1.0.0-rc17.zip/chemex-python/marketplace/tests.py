import io
import json
import re
import tempfile
import uuid
from pathlib import Path
from unittest.mock import patch
import bcrypt
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, Client, override_settings
from .core import *
from .models import AuthLimit
from .market import offer_fields
from .management.commands.chemex_admin import seed

PROFILE={'companyName':'ООО Химия','country':'Россия','registrationNumber':'1234567890','contactName':'Иван Иванов','contactEmail':'buyer@example.com','website':'','description':'','role':'both'}
OFFER={'name':'Ацетон','cas':'67-64-1','manufacturer':'Производитель','grade':'Технический','category':'Растворители','moq':'100 кг',
       'packaging':'Бочка','lead':'7 дней','purity':'99.5','price':'120','unit':'кг','region':'Европа','incoterm':'EXW','status':'published','documents':[]}

@override_settings(ALLOWED_HOSTS=['testserver'],BASE_URL='http://testserver',CSRF_TRUSTED_ORIGINS=['http://testserver'],
                   PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class MarketplaceTests(TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.storage=override_settings(DOCUMENT_ROOT=Path(self.temp.name)/'documents'); self.storage.enable(); self.addCleanup(self.storage.disable)
        self.supplier=self.account('supplier@example.com'); self.buyer=self.account('buyer@example.com'); self.outsider=self.account('other@example.com'); self.administrator=self.account('admin@example.com',True)
        for u in [self.supplier,self.buyer,self.outsider]:
            putrec('profile',u['userId'],{**PROFILE,**u,'createdAt':stamp(),'updatedAt':stamp()},u['userId'])
        self.s=self.client_for(self.supplier); self.b=self.client_for(self.buyer); self.x=self.client_for(self.outsider); self.a=self.client_for(self.administrator)
        self.guest=Client(enforce_csrf_checks=True)

    def account(self,email,admin_=False):
        u=Account.objects.create(email=email,display_name='Иван Иванов',password_hash=make_password('safe-password-123'),is_admin=admin_,created_at=stamp())
        return {'userId':str(u.id),'email':email}

    def client_for(self,u):
        c=Client(enforce_csrf_checks=True); session=c.session; session['uid']=u['userId']; session['version']=1; session.save()
        return c

    def token(self,c):
        response=c.get('/'); self.assertEqual(response.status_code,200)
        return re.search(r'name="csrf-token" content="([^"]+)',response.content.decode()).group(1)

    def api(self,c,name,method='GET',data=None,expected=200):
        headers={'HTTP_ORIGIN':settings.BASE_URL,'HTTP_X_CSRF_TOKEN':self.token(c)} if method!='GET' else {}
        response=c.generic(method,'/api/'+name,data=json.dumps(data) if data is not None else '',content_type='application/json',**headers)
        self.assertEqual(response.status_code,expected,response.content[:1000]); return response.json()

    def offer(self): return self.api(self.s,'offers','POST',OFFER)['offer']

    def rfq(self,offer=None,send=True):
        offer=offer or self.offer()
        r=self.api(self.b,'requests','POST',{'productId':100000+offer['id'],'quantity':'500','unit':'кг','destination':'Самара',
            'email':'buyer@example.com','specification':'Чистота от 99%','requestedDocuments':['SDS','COA']})['request']
        if send: r=self.api(self.b,'requests','PATCH',{'id':r['id'],'action':'send'})['request']
        return r

    def test_guest_csrf_host_and_static_boundaries(self):
        self.api(self.guest,'profile',expected=401)
        self.assertEqual(self.s.put('/api/profile',data=json.dumps(PROFILE),content_type='application/json').status_code,403)
        self.assertEqual(self.s.put('/api/profile',data=json.dumps(PROFILE),content_type='application/json',HTTP_X_CSRF_TOKEN=self.token(self.s),HTTP_ORIGIN='https://evil.example').status_code,403)
        self.assertEqual(self.guest.get('/',HTTP_HOST='evil.example').status_code,400)
        self.assertEqual(self.guest.get('/config/settings.py').status_code,404)
        self.assertEqual(self.guest.get('/account.js').status_code,200)
        self.api(self.guest,'health')

    def test_registration_login_logout_and_revocation(self):
        c=Client(enforce_csrf_checks=True)
        def form(path,body):
            page=c.get(path); token=re.search(r'name="csrfmiddlewaretoken" value="([^"]+)',page.content.decode()).group(1)
            return c.post(path,{**body,'csrfmiddlewaretoken':token},HTTP_ORIGIN=settings.BASE_URL)
        self.assertEqual(form('/register',{'email':'NEW@example.com','displayName':'Новый','password':'safe-password-123'}).status_code,302)
        self.assertEqual(self.api(c,'profile')['user']['email'],'new@example.com')
        self.assertEqual(c.get('/logout').status_code,200)
        self.api(c,'profile')  # GET logout must not log out.
        self.assertEqual(form('/logout',{}).status_code,302); self.api(c,'profile',expected=401)
        self.assertEqual(form('/login',{'email':'new@example.com','password':'incorrect'}).status_code,401)
        self.assertEqual(form('/login',{'email':'new@example.com','password':'safe-password-123'}).status_code,302)
        Account.objects.filter(email='new@example.com').update(session_version=2); self.api(c,'profile',expected=401)

    def test_login_rate_limit_persists_failed_attempts(self):
        c=Client(enforce_csrf_checks=True)
        for _ in range(20):
            token=self.token(c)
            response=c.post('/login',{'email':'absent@example.com','password':'wrong'},HTTP_X_CSRF_TOKEN=token,HTTP_ORIGIN=settings.BASE_URL)
            self.assertEqual(response.status_code,401)
        response=c.post('/login',{'email':'absent@example.com','password':'wrong'},HTTP_X_CSRF_TOKEN=self.token(c),HTTP_ORIGIN=settings.BASE_URL)
        self.assertEqual(response.status_code,429); self.assertTrue(AuthLimit.objects.filter(attempts=20).exists())

    def test_legacy_bcrypt_rehash(self):
        hashed=bcrypt.hashpw(b'safe-password-123',bcrypt.gensalt(rounds=4)).decode().replace('$2b$','$2y$')
        Account.objects.filter(id=self.supplier['userId']).update(password_hash=hashed)
        c=Client(enforce_csrf_checks=True)
        response=c.post('/login',{'email':'supplier@example.com','password':'safe-password-123'},HTTP_X_CSRF_TOKEN=self.token(c),HTTP_ORIGIN=settings.BASE_URL)
        self.assertEqual(response.status_code,302)
        self.assertFalse(Account.objects.get(id=self.supplier['userId']).password_hash.startswith('$2'))

    def test_offer_ownership_validation_and_identity(self):
        o=self.offer()
        self.assertEqual(o['chemexId'],chemex('Производитель','Технический','67-64-1'))
        self.assertEqual(chemex(' Производитель ','ТЕХНИЧЕСКИЙ','67-64-1'),o['chemexId'])
        live=self.api(self.guest,'offers')['products'][0]
        self.assertEqual(live['id'],100000+o['id']); self.assertNotIn('userId',live)
        self.api(self.x,'offers','PUT',{**OFFER,'id':o['id']},404)
        self.api(self.s,'offers','POST',{**OFFER,'cas':'67-64-2'},400)
        self.api(self.s,'offers','POST',{**OFFER,'technical':{'specifications':'bad'}},400)
        self.api(self.b,'favorites','PUT',{'productId':live['id'],'saved':True})
        self.assertEqual(self.api(self.b,'favorites')['favorites'],[live['id']])

    def test_full_trade_private_messages_and_quotation(self):
        r=self.rfq()
        self.assertEqual(self.api(self.s,'requests?inbox=1')['requests'][0]['id'],r['id'])
        self.assertEqual(self.api(self.x,'requests?inbox=1')['requests'],[])
        self.api(self.x,'requests','PATCH',{'id':r['id'],'action':'reply','quotation':{}},404)
        q={'price':'150','currency':'RUB','unit':'кг','lead':'5 дней','incoterm':'FCA','validUntil':'2099-12-31','vatMode':'included','vatRate':'20','moqQuantity':'100','moqUnit':'кг','paymentTerms':'Предоплата','packaging':'Бочки'}
        quoted=self.api(self.s,'requests','PATCH',{'id':r['id'],'action':'reply','quotation':q})['request']
        self.assertEqual(quoted['status'],'quoted'); self.assertEqual(json.loads(quoted['quotation'])['currency'],'RUB')
        self.api(self.s,'requests','PATCH',{'id':r['id'],'action':'reply','quotation':q},409)
        m={'requestId':r['id'],'clientId':str(uuid.uuid4()),'body':'Подтвердите срок поставки'}
        first=self.api(self.b,'messages','POST',m)['message']
        self.assertEqual(self.api(self.b,'messages','POST',m)['message']['id'],first['id'])
        self.api(self.b,'messages','POST',{**m,'body':'Другой текст'},409)
        self.api(self.x,'messages?requestId='+r['id'],expected=404)
        page=self.api(self.s,'messages?requestId='+r['id'])
        self.assertFalse(page['messages'][0]['mine']); self.assertEqual(page['conversation']['requestedDocuments'],['SDS','COA'])
        self.assertFalse(page['conversation']['canAddSupplier'])
        self.assertTrue(self.api(self.b,'messages?requestId='+r['id'])['conversation']['canAddSupplier'])
        self.assertEqual(page['conversation']['chemexId'],r['chemexId'])

    def test_stale_rfq_and_demo_cannot_send(self):
        o=self.offer(); r=self.rfq(o,False)
        self.api(self.s,'offers','PUT',{**OFFER,'id':o['id'],'grade':'Новая марка'})
        self.api(self.b,'requests','PATCH',{'id':r['id'],'action':'send'},409)
        demo=self.api(self.b,'requests','POST',{'productId':1,'quantity':'1','unit':'кг','destination':'Самара','email':'buyer@example.com'})['request']
        self.api(self.b,'requests','PATCH',{'id':demo['id'],'action':'send'},409)
        self.api(self.b,'requests','DELETE',{'id':demo['id']})

    def test_quote_validation_and_bad_payloads(self):
        r=self.rfq()
        self.api(self.s,'requests','PATCH',{'id':r['id'],'action':'reply','quotation':{'vatMode':'included'}},400)
        self.api(self.b,'requests','POST',{'productId':True},400)
        self.api(self.s,'offers','POST',[],400)
        self.api(self.b,'requests','POST',{'productId':1,'quantity':'1','unit':'кг','destination':'Самара','email':'a@example.com','requestedDocuments':['SDS','SDS']},400)
        self.api(self.s,'offers','POST',{**OFFER,'description':'x'*17000},413)

    def test_pdf_access_attachment_moderation(self):
        o=self.offer()
        response=self.s.post('/api/document-files',{'offerId':str(o['id']),'file':SimpleUploadedFile('sds.pdf',b'%PDF-1.4\n%%EOF')},HTTP_X_CSRF_TOKEN=self.token(self.s),HTTP_ORIGIN=settings.BASE_URL)
        self.assertEqual(response.status_code,201,response.content)
        url=response.json()['url']; path=url.replace(settings.BASE_URL,'')
        self.assertEqual(self.guest.get(path).status_code,404); self.assertEqual(self.x.get(path).status_code,404)
        self.assertEqual(self.s.get(path).status_code,200)
        # Public document URLs require HTTPS even during local API testing.
        with override_settings(BASE_URL='https://testserver',CSRF_TRUSTED_ORIGINS=['https://testserver']):
            doc={'type':'SDS','url':url.replace('http:','https:'),'language':'ru','date':'','batch':''}
            self.api(self.s,'offers','PUT',{**OFFER,'id':o['id'],'documents':[doc]})
            self.assertEqual(self.guest.get(path).status_code,200)
            self.api(self.a,'admin','POST',{'scope':'offer','id':str(o['id']),'hidden':True,'revision':0,'reason':'Проверка документа'})
            self.assertEqual(self.guest.get(path).status_code,404)
            self.api(self.a,'admin','POST',{'scope':'offer','id':str(o['id']),'hidden':False,'revision':0,'reason':'Возврат карточки'},409)
        self.assertEqual(self.api(self.guest,'offers')['products'],[])

    def test_verification_and_profile_fingerprint(self):
        self.offer()
        s={'enabled':True,'beneficiary':'ООО Площадка','registration':'1234','bank':'Тестовый банк','account':'1234567890','bankCode':'123','terms':'Проверка по выписке банка','amount':'1.00','currency':'RUB'}
        self.api(self.s,'verification','POST',{'action':'settings','settings':s},403)
        self.api(self.a,'verification','POST',{'action':'settings','settings':s})
        r=self.api(self.s,'verification','POST',{'action':'apply','consent':True})['application']
        self.assertEqual(self.api(self.s,'verification','POST',{'action':'apply','consent':True})['application']['id'],r['id'])
        approve={'action':'approve','id':r['id'],'note':'Проверено по выписке','statementChecked':True,'bankReference':'BANK-001','payerName':PROFILE['companyName'],'payerRegistration':PROFILE['registrationNumber'],'amount':'1.00','currency':'RUB','purpose':r['purpose']}
        self.api(self.a,'verification','POST',{**approve,'amount':'2'},400)
        self.api(self.a,'verification','POST',approve)
        self.assertTrue(self.api(self.guest,'offers')['products'][0]['verified'])
        self.api(self.s,'profile','PUT',{**PROFILE,'registrationNumber':'9876543210'})
        self.assertFalse(self.api(self.guest,'offers')['products'][0]['verified'])

    def test_reference_preview_commit_and_atomic_rollback(self):
        raw=json.loads((settings.BASE_DIR/'seed/seed.json').read_text())[0]
        self.api(self.s,'reference','POST',{'action':'preview','reviewed':True,'products':[raw]},403)
        result=self.api(self.a,'reference','POST',{'action':'preview','reviewed':True,'products':[raw]})
        self.assertEqual(result['newCount'],1); self.assertEqual(records('reference'),[])
        self.api(self.a,'reference','POST',{'action':'commit','reviewed':True,'products':[raw,{}]},400)
        self.assertEqual(records('reference'),[])
        self.api(self.a,'reference','POST',{'action':'commit','reviewed':True,'products':[raw,raw]})
        self.assertEqual(len(records('reference')),1)
        self.assertEqual(self.api(self.guest,'reference')['total'],1)

    def test_audit_failure_rolls_back_moderation(self):
        o=self.offer()
        with patch('marketplace.administration.event',side_effect=RuntimeError('test audit failure')):
            self.api(self.a,'admin','POST',{'scope':'offer','id':str(o['id']),'hidden':True,'revision':0,'reason':'Тест отката'},500)
        self.assertFalse(hidden('offer',o['id']))

    def test_laboratory_seed_revision_and_roles(self):
        with write_transaction(): seed()
        raw=self.api(self.guest,'laboratories')['laboratories'][0]
        d={'record':raw,'revision':0,'hidden':True,'reason':'Проверка источников'}
        self.api(self.s,'laboratories','POST',d,403)
        self.api(self.a,'laboratories','POST',d)
        self.api(self.a,'laboratories','POST',d,409)
        self.assertNotIn(raw['id'],[r['id'] for r in self.api(self.guest,'laboratories')['laboratories']])
        self.api(self.a,'laboratories','POST',{**d,'revision':1,'record':{**raw,'registryStatus':'active','registryCheckedAt':today()}},400)
        self.assertTrue(self.api(self.a,'admin')['counts']['reference']>0)

    def test_import_dry_run_files_and_preserved_ids(self):
        o=self.offer(); fid=str(uuid.uuid4()); pdf=b'%PDF-1.4\n%%EOF'
        old='https://old.example.com'
        payload=getrec('offer',o['id']); payload['documents']=[{'type':'SDS','url':old+'/api/document-files?id='+fid,'language':'ru','date':'','batch':''}]
        putrec('offer',o['id'],payload,self.supplier['userId'],status='published')
        putrec('file',fid,{'id':fid,'ownerId':self.supplier['userId'],'offerId':o['id'],'filename':'sds.pdf','size':len(pdf),'createdAt':stamp()},self.supplier['userId'],o['id'])
        users=[]
        for u in Account.objects.values(): u['id']=str(u['id']); users.append(u)
        rows=[{'kind':r.kind,'id':r.key,'owner':r.owner,'related':r.related,'status':r.status,'payload':r.payload} for r in Record.objects.all()]
        data={'format':'chemex-php-export-v1','baseUrl':old,'users':users,'records':rows,'counters':list(Counter.objects.values()),'files':{fid:{'size':len(pdf),'sha256':hashlib.sha256(pdf).hexdigest()}}}
        for u in data['users']: u['password_hash']='$2y$04$'+('a'*53) # Import transports hashes; legacy login tested separately.
        source=Path(self.temp.name)/'source'; source.mkdir(); (source/(fid+'.pdf')).write_bytes(pdf)
        export=Path(self.temp.name)/'export.json'; export.write_text(json.dumps(data))
        Account.objects.all().delete(); Record.objects.all().delete()
        output=io.StringIO(); call_command('import_php',str(export),documents=str(source),dry_run=True,stdout=output)
        self.assertFalse(Account.objects.exists()); self.assertFalse(settings.DOCUMENT_ROOT.exists())
        (source/(fid+'.pdf')).write_bytes(b'CORRUPTED')
        with self.assertRaises(CommandError): call_command('import_php',str(export),documents=str(source),stdout=output)
        self.assertFalse(Account.objects.exists())
        (source/(fid+'.pdf')).write_bytes(pdf)
        call_command('import_php',str(export),documents=str(source),stdout=output)
        self.assertEqual(getrec('offer',o['id'])['chemexId'],o['chemexId'])
        self.assertTrue(getrec('offer',o['id'])['documents'][0]['url'].startswith(settings.BASE_URL))
        self.assertEqual((settings.DOCUMENT_ROOT/(fid+'.pdf')).read_bytes(),pdf)
        self.assertEqual(Account.objects.get(id=self.supplier['userId']).session_version,2)
        with self.assertRaises(CommandError): call_command('import_php',str(export),documents=str(source),stdout=output)

    def partner(self,offer=None):
        o=offer or self.offer()
        return self.api(self.b,'partners','POST',{'action':'add','productId':100000+o['id']})['partner']

    def partner_update(self,p,**changes):
        keys=['status','approved','archived','tags','contactName','contactEmail','contactPhone','notes','nextAction','nextDate']
        return {'action':'update','id':p['id'],'revision':p['revision'],**{k:p[k] for k in keys},**changes}

    def test_partner_owner_privacy_and_duplicate_add(self):
        o=self.offer(); p=self.partner(o)
        p=self.api(self.b,'partners','POST',self.partner_update(p,notes='PRIVATE-NOTE-771',contactEmail='private@example.com',approved=True))['partner']
        duplicate=self.api(self.b,'partners','POST',{'action':'add','productId':100000+o['id']})
        self.assertTrue(duplicate['existing']); self.assertEqual(duplicate['partner']['notes'],'PRIVATE-NOTE-771')
        self.assertEqual(len(records('partner',self.buyer['userId'])),1)
        self.api(self.x,'partners?id='+p['id'],expected=404)
        self.api(self.s,'partners?id='+p['id'],expected=404)
        self.api(self.guest,'partners',expected=401)
        self.api(self.a,'profile','PUT',PROFILE)
        self.api(self.a,'partners?id='+p['id'],expected=404)
        self.api(self.x,'partners','POST',self.partner_update(p,notes='HACK'),404)
        self.assertNotIn('PRIVATE-NOTE-771',json.dumps(self.api(self.guest,'offers')))
        self.assertEqual(self.api(self.s,'partners')['partners'],[])

    def test_partner_source_authorization_and_roles(self):
        o=self.offer()
        self.api(self.b,'partners','POST',{'action':'add','productId':1},400)
        self.api(self.s,'partners','POST',{'action':'add','productId':100000+o['id']},400)
        draft=self.rfq(o,False)
        self.api(self.b,'partners','POST',{'action':'add','requestId':draft['id']},404)
        r=self.api(self.b,'requests','PATCH',{'id':draft['id'],'action':'send'})['request']
        self.api(self.x,'partners','POST',{'action':'add','requestId':r['id']},404)
        p=self.api(self.b,'partners','POST',{'action':'add','requestId':r['id']})['partner']
        self.assertEqual(p['requestCount'],1)
        self.api(self.b,'profile','PUT',{**PROFILE,'role':'supplier'})
        self.api(self.b,'partners',expected=403)
        self.api(self.b,'profile','PUT',PROFILE)
        self.assertEqual(self.api(self.b,'partners')['partners'][0]['id'],p['id'])

    def test_partner_revisions_archive_and_validation(self):
        p=self.partner()
        updated=self.api(self.b,'partners','POST',self.partner_update(p,archived=True,tags=['Растворители',' растворители '],nextAction='Уточнить цену',nextDate='2026-01-01'))['partner']
        self.assertEqual(updated['tags'],['Растворители']); self.assertFalse(updated['actionDue'])
        self.api(self.b,'partners','POST',self.partner_update(p,notes='Stale'),409)
        self.api(self.b,'partners','POST',self.partner_update(updated,nextDate=''),400)
        self.api(self.b,'partners','POST',self.partner_update(updated,contactEmail='bad-email'),400)
        self.api(self.b,'partners','POST',self.partner_update(updated,tags=['x']*11),400)
        restored=self.api(self.b,'partners','POST',self.partner_update(updated,archived=False))['partner']
        self.assertTrue(restored['actionDue']); self.assertEqual(restored['nextAction'],'Уточнить цену')
        self.assertEqual(restored['products'],updated['products'])

    def test_partner_pin_visibility_and_identity_changes(self):
        o=self.offer(); p=self.partner(o)
        foreign=self.api(self.x,'offers','POST',{**OFFER,'manufacturer':'Другой'})['offer']
        self.api(self.b,'partners','POST',{'action':'pin','id':p['id'],'revision':p['revision'],'offerId':foreign['id']},409)
        self.api(self.s,'offers','PUT',{**OFFER,'id':o['id'],'grade':'Новая марка'})
        changed=self.api(self.b,'partners?id='+p['id'])['partner']
        self.assertTrue(changed['products'][0]['identityChanged'])
        refreshed=self.api(self.b,'partners','POST',{'action':'pin','id':p['id'],'revision':p['revision'],'offerId':o['id']})['partner']
        self.assertFalse(refreshed['products'][0]['identityChanged']); self.assertEqual(len(refreshed['products']),1)
        self.api(self.a,'admin','POST',{'scope':'offer','id':str(o['id']),'hidden':True,'revision':0,'reason':'Проверка сырья'})
        hidden_=self.api(self.b,'partners?id='+p['id'])['partner']
        self.assertFalse(hidden_['products'][0]['available']); self.assertEqual(hidden_['availableProducts'],[])
        unpinned=self.api(self.b,'partners','POST',{'action':'unpin','id':p['id'],'revision':refreshed['revision'],'offerId':o['id']})['partner']
        self.assertEqual(unpinned['products'],[])

    def repeat_body(self,p,o,source=None):
        return {'action':'repeat','id':p['id'],'revision':p['revision'],'offerId':o['id'],
                **({'requestId':source['id']} if source else {}),'expectedChemexId':o['chemexId'],'expectedCas':o['cas'],
                'quantity':'750','unit':'кг','destination':'Саратов','email':'buyer@example.com','specification':'Чистота 99%',
                'requestedDocuments':['SDS','TDS'],'message':'Согласовать срок'}

    def test_partner_repeat_creates_private_draft_then_send(self):
        o=self.offer(); r=self.rfq(o); p=self.partner(o)
        q=self.api(self.b,'partners','POST',self.repeat_body(p,o,r))['request']
        self.assertEqual(q['status'],'draft'); self.assertIsNone(q['recipientId']); self.assertIsNone(q['quotation'])
        self.assertEqual(q['sourceRequestId'],r['id']); self.assertEqual(q['quantity'],'750')
        self.assertEqual(q['requestedDocuments'],['SDS','TDS'])
        self.assertEqual(len(self.api(self.s,'requests?inbox=1')['requests']),1)
        sent=self.api(self.b,'requests','PATCH',{'action':'send','id':q['id']})['request']
        self.assertEqual(sent['recipientId'],self.supplier['userId'])
        detail=self.api(self.b,'partners?id='+p['id'])['partner']
        self.assertEqual(detail['requestCount'],2)
        message={'requestId':q['id'],'clientId':str(uuid.uuid4()),'body':'Последнее сообщение'}
        self.api(self.s,'messages','POST',message)
        self.assertIsNotNone(self.api(self.b,'partners?id='+p['id'])['partner']['lastInteraction'])

    def test_partner_repeat_paused_stale_and_foreign_sources(self):
        o=self.offer(); r=self.rfq(o); p=self.partner(o)
        self.api(self.x,'partners','POST',self.repeat_body(p,o,r),404)
        outsider_partner=self.api(self.x,'partners','POST',{'action':'add','productId':100000+o['id']})['partner']
        self.api(self.x,'partners','POST',self.repeat_body(outsider_partner,o,r),404)
        q=self.api(self.b,'partners','POST',self.repeat_body(p,o,r))['request']
        paused=self.api(self.b,'partners','POST',self.partner_update(p,status='paused'))['partner']
        self.api(self.b,'partners','POST',self.repeat_body(paused,o,r),409)
        self.api(self.b,'requests','PATCH',{'action':'send','id':q['id']},409)
        active=self.api(self.b,'partners','POST',self.partner_update(paused,status='regular'))['partner']
        changed=self.api(self.s,'offers','PUT',{**OFFER,'id':o['id'],'grade':'Изменена'})['offer']
        self.api(self.b,'partners','POST',self.repeat_body(active,o),409)
        self.api(self.b,'partners','POST',self.repeat_body(active,changed,r),409)
        new=self.api(self.b,'partners','POST',self.repeat_body(active,changed))['request']
        self.assertEqual(new['chemexId'],changed['chemexId'])
        self.assertEqual(len(records('request',self.buyer['userId'])),3)

    def test_partner_internal_approval_independent_of_bank(self):
        p=self.partner(); self.assertFalse(p['approved']); self.assertFalse(p['bankConfirmed'])
        p=self.api(self.b,'partners','POST',self.partner_update(p,approved=True,status='regular'))['partner']
        self.assertTrue(p['approved']); self.assertFalse(p['bankConfirmed']); self.assertIsNotNone(p['approvedAt'])
        uid=self.supplier['userId']; company=getrec('profile',uid)
        putrec('verification',1,{'id':1,'userId':uid,'status':'bank_confirmed','fingerprint':fingerprint(company)},uid)
        p=self.api(self.b,'partners?id='+p['id'])['partner']; self.assertTrue(p['bankConfirmed'])
        p=self.api(self.b,'partners','POST',self.partner_update(p,approved=False))['partner']
        self.assertFalse(p['approved']); self.assertTrue(p['bankConfirmed']); self.assertIsNone(p['approvedAt'])

    def test_partner_task_completion_and_next_step(self):
        p=self.partner()
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Получить SDS',nextDate='2026-01-01'))['partner']
        self.assertEqual(p['taskState'],'overdue'); self.assertEqual(p['taskEvents'][0]['action'],'scheduled')
        old=p
        p=self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision'],'note':'SDS получен','nextAction':'Согласовать партию','nextDate':'2099-01-01'})['partner']
        self.assertEqual(p['taskState'],'planned'); self.assertEqual(p['nextAction'],'Согласовать партию')
        e=p['taskEvents'][0]; self.assertEqual(e['title'],'Получить SDS'); self.assertEqual(e['action'],'completed'); self.assertEqual(e['note'],'SDS получен')
        self.api(self.b,'partners','POST',{'action':'complete_task','id':old['id'],'revision':old['revision']},409)
        p=self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision']})['partner']
        self.assertEqual(p['nextDate'],''); self.assertEqual(p['taskState'],'none')
        self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision']},409)
        self.assertEqual(len(records('partner_task_event',self.buyer['userId'],p['id'])),3)

    def test_partner_task_reschedule_validation_and_privacy(self):
        p=self.partner()
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Уточнить срок',nextDate='2099-01-01'))['partner']
        body={'action':'reschedule_task','id':p['id'],'revision':p['revision'],'nextDate':'2099-02-01','note':'Ждём ответ'}
        self.api(self.s,'partners','POST',body,404)
        self.api(self.x,'partners?id='+p['id']+'&taskBefore=100',expected=404)
        self.api(self.b,'partners','POST',{**body,'nextDate':'2000-01-01'},400)
        self.api(self.b,'partners','POST',{**body,'nextDate':'2099-02-30'},400)
        self.api(self.b,'partners','POST',{**body,'note':''},400)
        self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision'],'nextAction':'Без даты'},400)
        self.assertEqual(len(records('partner_task_event',self.buyer['userId'],p['id'])),1)
        p=self.api(self.b,'partners','POST',body)['partner']
        self.assertEqual(p['nextDate'],'2099-02-01'); self.assertEqual(p['taskEvents'][0]['dueDate'],'2099-01-01')
        self.assertEqual(p['taskEvents'][0]['note'],'Ждём ответ')
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
        self.assertEqual(p['taskState'],'none')
        self.api(self.b,'partners','POST',{**body,'revision':p['revision'],'nextDate':'2099-03-01'},409)
        self.assertNotIn('taskEvents',self.api(self.b,'partners')['partners'][0])

    def test_partner_task_history_cursor_and_legacy(self):
        p=self.partner()
        self.assertEqual(p['taskEvents'],[]); self.assertIsNone(p['taskBefore'])
        from .partners import task_event
        for i in range(55): task_event(getrec('partner',p['id']),'changed',str(i),'Новое действие','2099-01-01')
        first=self.api(self.b,'partners?id='+p['id'])['partner']
        self.assertEqual(len(first['taskEvents']),50)
        second=self.api(self.b,'partners?id='+p['id']+'&taskBefore='+str(first['taskBefore']))['partner']
        self.assertEqual(len(second['taskEvents']),5);self.assertIsNone(second['taskBefore'])
        self.assertFalse(set(e['id'] for e in first['taskEvents']) & set(e['id'] for e in second['taskEvents']))
        self.api(self.b,'partners?id='+p['id']+'&taskBefore=invalid',expected=400)

    def test_partner_task_change_cancel_atomicity_and_utc(self):
        p=self.partner()
        with patch('marketplace.partners.today',return_value='2026-10-18'):
            p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Звонок',nextDate='2026-10-18'))['partner']
            self.assertEqual(p['taskState'],'today')
        with patch('marketplace.partners.task_event',side_effect=RuntimeError('task history failure')):
            self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision']},500)
        current=getrec('partner',p['id']); self.assertEqual(current['nextAction'],'Звонок'); self.assertEqual(current['revision'],p['revision'])
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Уточнить упаковку'))['partner']
        self.assertEqual(p['taskEvents'][0]['action'],'changed')
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='',nextDate=''))['partner']
        self.assertEqual(p['taskEvents'][0]['action'],'cancelled'); self.assertEqual(p['taskState'],'none')

    def upload_partner_document(self,p,client=None,content=b'%PDF-1.4\nprivate test\n%%EOF',expected=201,**fields):
        c=client or self.b
        body={'partnerId':p['id'],'title':'Договор поставки','kind':'contract','number':'Д-1','version':'1',
              'documentDate':'2026-10-01','expiresAt':'2026-12-31','note':'Личная заметка',**fields,
              'file':SimpleUploadedFile('contract.pdf',content,content_type='application/pdf')}
        response=c.post('/api/partner-documents',body,HTTP_ORIGIN=settings.BASE_URL,HTTP_X_CSRF_TOKEN=self.token(c))
        self.assertEqual(response.status_code,expected,response.content[:1000])
        return response.json()

    def test_partner_document_lifecycle_and_private_download(self):
        uid=self.administrator['userId']; putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        p=self.partner(); d=self.upload_partner_document(p)['document']
        self.assertNotIn('sha256',d);self.assertNotIn('userId',d)
        rows=self.api(self.b,'partner-documents?partnerId='+p['id'])['documents'];self.assertEqual(len(rows),1)
        response=self.b.get(d['downloadUrl']);self.assertEqual(response.status_code,200)
        self.assertEqual(b''.join(response.streaming_content),b'%PDF-1.4\nprivate test\n%%EOF');response.close()
        self.assertEqual(response['Cache-Control'],'private, no-store');self.assertIn('attachment',response['Content-Disposition'])
        for c in [self.s,self.x,self.a]:
            self.api(c,'partner-documents?partnerId='+p['id'],expected=404)
            self.assertEqual(c.get(d['downloadUrl']).status_code,404)
            self.api(c,'partner-documents','PATCH',{**d,'archived':True},404)
        self.assertEqual(self.guest.get(d['downloadUrl']).status_code,401)
        self.assertEqual(self.b.get('/api/document-files?id='+d['id']).status_code,404)
        self.assertEqual(self.guest.get('/partner-private/'+d['id']+'.pdf').status_code,404)
        edited=self.api(self.b,'partner-documents','PATCH',{**d,'title':'Изменённый договор','archived':True})['document']
        self.assertEqual(edited['expiryState'],'archived');self.assertEqual(edited['revision'],2)
        self.api(self.b,'partner-documents','PATCH',{**d,'archived':False},409)
        restored=self.api(self.b,'partner-documents','PATCH',{**edited,'archived':False})['document']
        self.assertFalse(restored['archived'])

    def test_partner_document_validation_and_archive(self):
        p=self.partner()
        self.upload_partner_document(p,content=b'not a pdf',expected=400)
        self.upload_partner_document(p,content=b'%PDF-'+b'x'*(8*1024*1024),expected=400)
        self.upload_partner_document(p,expiresAt='2026-02-30',expected=400)
        self.upload_partner_document(p,expiresAt='2026-09-30',expected=400)
        self.upload_partner_document(p,kind='SDS',expected=400)
        self.upload_partner_document(p,client=self.x,expected=404)
        self.assertEqual(records('partner_document'),[])
        d=self.upload_partner_document(p)['document']
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
        self.upload_partner_document(p,expected=409)
        self.api(self.b,'partner-documents','PATCH',{**d,'archived':True},409)
        response=self.b.get(d['downloadUrl']);self.assertEqual(response.status_code,200);response.close()
        self.assertEqual(len(self.api(self.b,'partner-documents?partnerId='+p['id'])['documents']),1)

    def test_partner_document_expiry_boundaries(self):
        from .partner_documents import document_state
        with patch('marketplace.partner_documents.today',return_value='2026-12-31'):
            for expiry,state in [('2026-12-30','expired'),('2026-12-31','expiring'),('2027-01-30','expiring'),('2027-01-31','dated'),('','no_date')]:
                self.assertEqual(document_state({'archived':False,'expiresAt':expiry}),state)
            self.assertEqual(document_state({'archived':True,'expiresAt':'2026-12-30'}),'archived')

    def test_partner_document_integrity_cleanup_and_csrf(self):
        p=self.partner()
        self.assertEqual(self.b.post('/api/partner-documents',{}).status_code,403)
        with patch('marketplace.partner_documents.putrec',side_effect=RuntimeError('storage failed')):
            self.upload_partner_document(p,expected=500)
        self.assertEqual(records('partner_document'),[])
        self.assertEqual(list((settings.DOCUMENT_ROOT/'partner-private').glob('*.pdf')),[])
        d=self.upload_partner_document(p)['document'];path=settings.DOCUMENT_ROOT/'partner-private'/(d['id']+'.pdf')
        original=path.read_bytes();path.write_bytes(original.replace(b'private',b'changed'))
        self.assertEqual(self.b.get(d['downloadUrl']).status_code,409)
        path.unlink();self.assertEqual(self.b.get(d['downloadUrl']).status_code,404)

    def test_workspace_attention_boundaries_privacy_archive(self):
        o=self.offer();p=self.partner(o);q=self.rfq(o)
        self.upload_partner_document(p,expiresAt='2026-11-17')
        with patch('marketplace.partner_workspace.today',return_value='2026-10-18'):
            rows=self.api(self.b,'partners')['partners'][0]['attention']
            self.assertEqual({x['kind'] for x in rows},{'waiting','document_expiring'})
            self.assertEqual(self.api(self.x,'partners')['partners'],[])
            self.assertEqual(self.api(self.s,'partners')['partners'],[])
            q.update(status='quoted',quotation=json.dumps({'validUntil':'2026-10-25'}));putrec('request',q['id'],q,q['userId'],q['recipientId'])
            self.assertIn('quote_expiring',{x['kind'] for x in self.api(self.b,'partners')['partners'][0]['attention']})
            q['quotation']=json.dumps({'validUntil':'2026-10-26'});putrec('request',q['id'],q,q['userId'],q['recipientId'])
            self.assertNotIn('quote_expiring',{x['kind'] for x in self.api(self.b,'partners')['partners'][0]['attention']})
            p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
            self.assertEqual(p['attention'],[])

    def test_workspace_task_links_owner_and_completion(self):
        o=self.offer();p=self.partner(o);q=self.rfq(o);d=self.upload_partner_document(p)['document']
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Проверить договор',nextDate='2099-01-01'))['partner']
        body={'action':'link_task','id':p['id'],'revision':p['revision'],'taskLink':{'kind':'document','id':d['id']}}
        self.api(self.x,'partners','POST',body,404)
        p=self.api(self.b,'partners','POST',body)['partner'];self.assertEqual(p['taskLink']['id'],d['id'])
        self.api(self.b,'partners','POST',body,409)
        p=self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision']})['partner']
        self.assertIsNone(p['taskLink']);self.assertEqual(p['taskEvents'][0]['taskLink']['id'],d['id'])
        self.api(self.b,'partners','POST',{**body,'revision':p['revision']},409)
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Ответ',nextDate='2099-01-01'))['partner']
        p=self.api(self.b,'partners','POST',{**body,'revision':p['revision'],'taskLink':{'kind':'request','id':q['id']}})['partner']
        self.assertEqual(p['taskLink']['id'],q['id'])
        q['recipientId']=self.outsider['userId'];putrec('request',q['id'],q,q['userId'],q['recipientId'])
        self.api(self.b,'partners','POST',{**body,'revision':p['revision'],'taskLink':{'kind':'request','id':q['id']}},404)

    def test_workspace_primary_uniqueness_and_identity(self):
        o=self.offer();p=self.partner(o)
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        def role(p,o,role,code=200):
            return self.api(self.b,'partners','POST',{'action':'supply_role','id':p['id'],'revision':p['revision'],'offerId':o['id'],'supplyRole':role},code)
        p=role(p,o,'primary')['partner'];self.assertEqual(p['products'][0]['supplyRole'],'primary')
        role(p2,other,'primary',409)
        p2=role(p2,other,'backup')['partner']
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
        role(p2,other,'primary',409)
        p=role(p,o,'none')['partner'];p2=role(p2,other,'primary')['partner']
        raw=getrec('offer',other['id']);raw['chemexId']='CHANGED';putrec('offer',raw['id'],raw,raw['userId'])
        role(p2,other,'backup',409)
        p2=role(p2,other,'none')['partner'];self.assertEqual(p2['products'][0]['supplyRole'],'none')

    def test_workspace_link_document_reject_other_relationship_and_archive(self):
        p=self.partner();other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        d=self.upload_partner_document(p2)['document']
        p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Проверка',nextDate='2099-01-01'))['partner']
        body={'action':'link_task','id':p['id'],'revision':p['revision'],'taskLink':{'kind':'document','id':d['id']}}
        self.api(self.b,'partners','POST',body,404)
        d=self.upload_partner_document(p)['document'];self.api(self.b,'partner-documents','PATCH',{**d,'archived':True})
        self.api(self.b,'partners','POST',{**body,'taskLink':{'kind':'document','id':d['id']}},409)

    def terms_body(self,p,**changes):
        return {'action':'save_terms','id':p['id'],'revision':p['revision'],'reason':'Получено письмо менеджера',
                'terms':{'status':'agreed','payment':'Отсрочка 30 дней','delivery':'DAP Самара','minimumOrder':'1 т','leadTime':'7 дней',
                         'source':'Письмо менеджера','notes':'','agreedOn':'2026-10-01','validUntil':'2026-12-31','reviewDate':'2026-11-01','documentId':'',**changes}}

    def test_terms_versions_private_archive_conflict(self):
        p=self.partner();self.assertEqual(p['termsState'],'empty');self.assertEqual(p['termsEvents'],[])
        body=self.terms_body(p)
        for c in [self.s,self.x]: self.api(c,'partners','POST',body,404)
        uid=self.administrator['userId'];putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        self.api(self.a,'partners','POST',body,404)
        p=self.api(self.b,'partners','POST',body)['partner'];self.assertEqual(p['terms']['version'],1)
        self.api(self.b,'partners','POST',body,409)
        p=self.api(self.b,'partners','POST',self.terms_body(p,payment='Предоплата'))['partner']
        self.assertEqual(p['terms']['version'],2);self.assertEqual(p['termsEvents'][1]['terms']['payment'],'Отсрочка 30 дней')
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
        self.api(self.b,'partners','POST',self.terms_body(p),409)
        self.assertEqual(len(p['termsEvents']),2)

    def test_terms_validation_document_scope_and_atomicity(self):
        p=self.partner()
        for changes in [{'source':'','agreedOn':''},{'validUntil':'2026-09-30'},{'reviewDate':'2026-02-30'},{'agreedOn':'2099-01-01'}, {'payment':'','delivery':'','minimumOrder':'','leadTime':''}]:
            self.api(self.b,'partners','POST',self.terms_body(p,**changes),400)
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other);d=self.upload_partner_document(p2)['document']
        self.api(self.b,'partners','POST',self.terms_body(p,documentId=d['id']),404)
        d=self.upload_partner_document(p)['document']
        with patch('marketplace.partner_terms.putrec',side_effect=RuntimeError('history unavailable')):
            self.api(self.b,'partners','POST',self.terms_body(p,documentId=d['id']),500)
        self.assertNotIn('terms',getrec('partner',p['id']))
        p=self.api(self.b,'partners','POST',self.terms_body(p,documentId=d['id'],source=''))['partner']
        self.api(self.b,'partner-documents','PATCH',{**d,'archived':True})
        p=self.api(self.b,'partners','POST',self.terms_body(p,documentId=d['id']))['partner']
        self.assertEqual(p['terms']['documentId'],d['id'])

    def test_terms_dates_attention_and_no_rfq_overwrite(self):
        from .partner_terms import terms_state
        p=self.partner()
        with patch('marketplace.partner_terms.today',return_value='2026-10-18'),patch('marketplace.partner_workspace.today',return_value='2026-10-18'):
            p=self.api(self.b,'partners','POST',self.terms_body(p,reviewDate='2026-10-18',validUntil='2026-11-17'))['partner']
            self.assertEqual(p['termsState'],'review');self.assertEqual({a['kind'] for a in p['attention']},{'terms_review','terms_expiry'})
            self.assertEqual(terms_state({**p['terms'],'reviewDate':'','validUntil':'2026-10-18'}),'expiring')
            self.assertEqual(terms_state({**p['terms'],'validUntil':'2026-10-17'}),'expired')
            self.assertEqual(terms_state({**p['terms'],'reviewDate':'','validUntil':''}),'recorded')
            p=self.api(self.b,'partners','POST',self.terms_body(p,status='inactive'))['partner'];self.assertEqual(p['attention'],[])
        q=self.rfq();self.assertNotIn('terms',q);self.assertIsNone(q['quotation'])

    def test_terms_history_pagination_and_legacy(self):
        p=self.partner()
        for i in range(22): p=self.api(self.b,'partners','POST',self.terms_body(p,notes=str(i)))['partner']
        self.assertEqual(len(p['termsEvents']),20)
        older=self.api(self.b,'partners?id='+p['id']+'&termsBefore='+str(p['termsBefore']))['partner']
        self.assertEqual([e['terms']['version'] for e in older['termsEvents']],[2,1]);self.assertIsNone(older['termsBefore'])
        self.api(self.b,'partners?id='+p['id']+'&termsBefore=bad',expected=400)

    def test_supply_matrix_identity_privacy_and_unique_companies(self):
        o=self.offer();p=self.partner(o)
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        duplicate=self.offer();p=self.api(self.b,'partners','POST',{'action':'pin','id':p['id'],'revision':p['revision'],'offerId':duplicate['id']})['partner']
        rows=self.api(self.b,'partners?supply=1')['groups'];self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['supplierCount'],2);self.assertEqual(rows[0]['availableCount'],2);self.assertEqual(len(rows[0]['suppliers']),3)
        self.assertEqual(self.api(self.x,'partners?supply=1')['groups'],[])
        self.api(self.guest,'partners?supply=1',expected=401)
        changed=self.api(self.x,'offers','POST',{**OFFER,'grade':'Другая марка'})['offer']
        self.api(self.b,'partners','POST',{'action':'pin','id':p2['id'],'revision':p2['revision'],'offerId':changed['id']})
        self.assertEqual(len(self.api(self.b,'partners?supply=1')['groups']),2)

    def test_supply_matrix_coverage_archive_and_changed_product(self):
        o=self.offer();p=self.partner(o);other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        p=self.api(self.b,'partners','POST',{'action':'supply_role','id':p['id'],'revision':p['revision'],'offerId':o['id'],'supplyRole':'primary'})['partner']
        p2=self.api(self.b,'partners','POST',{'action':'supply_role','id':p2['id'],'revision':p2['revision'],'offerId':other['id'],'supplyRole':'backup'})['partner']
        g=self.api(self.b,'partners?supply=1')['groups'][0];self.assertTrue(g['hasPrimary']);self.assertTrue(g['hasBackup'])
        p2=self.api(self.b,'partners','POST',self.partner_update(p2,archived=True))['partner']
        g=self.api(self.b,'partners?supply=1')['groups'][0];self.assertFalse(g['hasBackup']);self.assertEqual(g['availableCount'],1)
        raw=getrec('offer',o['id']);raw['chemexId']='CHANGED';putrec('offer',o['id'],raw,raw['userId'])
        g=self.api(self.b,'partners?supply=1')['groups'][0];self.assertFalse(g['hasPrimary']);self.assertEqual(g['availableCount'],0)
        self.assertTrue(any(s['identityChanged'] for s in g['suppliers']))

    def test_supply_matrix_latest_quote_never_falls_back_to_old(self):
        o=self.offer();p=self.partner(o);first=self.rfq(o);second=self.rfq(o)
        for q,when,until in [(first,'2026-10-01T00:00:00Z','2099-12-31'),(second,'2026-10-02T00:00:00Z','2026-10-17')]:
            q.update(status='quoted',repliedAt=when,quotation=json.dumps({'price':'120','currency':'RUB','validUntil':until}))
            putrec('request',q['id'],q,q['userId'],q['recipientId'])
        with patch('marketplace.supply_matrix.today',return_value='2026-10-18'):
            s=self.api(self.b,'partners?supply=1')['groups'][0]['suppliers'][0]
            self.assertEqual(s['latestQuote']['id'],second['id']);self.assertEqual(s['quoteState'],'expired')
            second['grade']='Другая марка';putrec('request',second['id'],second,second['userId'],second['recipientId'])
            s=self.api(self.b,'partners?supply=1')['groups'][0]['suppliers'][0];self.assertEqual(s['latestQuote']['id'],first['id'])
        from .supply_matrix import quote_state
        with patch('marketplace.supply_matrix.today',return_value='2026-10-18'):
            self.assertEqual(quote_state({'quotation':'{"validUntil":"2026-10-18"}'}),'dated')
            self.assertEqual(quote_state({'quotation':'{"validUntil":"invalid"}'}),'unknown')

    def test_supply_matrix_unknown_identity_and_same_company_backup(self):
        o=self.offer();p=self.partner(o);o2=self.offer()
        p=self.api(self.b,'partners','POST',{'action':'pin','id':p['id'],'revision':p['revision'],'offerId':o2['id']})['partner']
        for i,role in [(o['id'],'primary'),(o2['id'],'backup')]:
            p=self.api(self.b,'partners','POST',{'action':'supply_role','id':p['id'],'revision':p['revision'],'offerId':i,'supplyRole':role})['partner']
        g=self.api(self.b,'partners?supply=1')['groups'][0];self.assertTrue(g['hasPrimary']);self.assertFalse(g['hasBackup']);self.assertEqual(g['availableCount'],1)
        raw=getrec('partner',p['id'])
        for pin in raw['products']:pin['chemexId']=''
        putrec('partner',raw['id'],raw,raw['userId'],raw['supplierId'])
        rows=self.api(self.b,'partners?supply=1')['groups'];self.assertEqual(len(rows),2)
        self.assertTrue(all(g['availableCount']==0 for g in rows))

    def batch_fixture(self):
        o=self.offer();p=self.partner(o);o2=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(o2)
        body={'action':'batch_requests','clientId':str(uuid.uuid4()),'targets':[{'partnerId':p['id'],'revision':p['revision'],'offerId':o['id']},{'partnerId':p2['id'],'revision':p2['revision'],'offerId':o2['id']}],
              'identity':{k:o[k] for k in ['chemexId','cas','manufacturer','grade']},'quantity':'500','unit':'кг','destination':'Самара',
              'email':'buyer@example.com','specification':'Чистота 99%','requestedDocuments':['SDS','COA'],'message':'Цена с доставкой'}
        return body,p,p2,o,o2

    def test_batch_private_drafts_idempotency_and_individual_send(self):
        body,p,p2,o,o2=self.batch_fixture()
        data=self.api(self.b,'partners','POST',body);self.assertEqual(len(data['requests']),2)
        self.assertFalse(data['replayed'])
        for q in data['requests']:
            self.assertEqual(q['status'],'draft');self.assertIsNone(q['recipientId']);self.assertIsNone(q['quotation'])
            self.assertEqual(q['requestedDocuments'],['SDS','COA']);self.assertEqual(q['quantity'],'500')
        self.assertEqual(self.api(self.s,'requests?inbox=1')['requests'],[]);self.assertEqual(self.api(self.x,'requests?inbox=1')['requests'],[])
        replay=self.api(self.b,'partners','POST',body);self.assertTrue(replay['replayed'])
        self.assertEqual([q['id'] for q in replay['requests']],[q['id'] for q in data['requests']])
        self.assertEqual(len(records('request',self.buyer['userId'])),2)
        self.api(self.b,'partners','POST',{**body,'quantity':'600'},409)
        q=data['requests'][0];self.api(self.b,'requests','PATCH',{'action':'send','id':q['id']})
        self.assertEqual(len(self.api(self.s,'requests?inbox=1')['requests']),1);self.assertEqual(self.api(self.x,'requests?inbox=1')['requests'],[])
        self.api(self.b,'requests','DELETE',{'id':data['requests'][1]['id']})
        replay=self.api(self.b,'partners','POST',body);self.assertEqual(replay['missingCount'],1);self.assertEqual(len(replay['requests']),1)

    def test_batch_invalid_target_never_partially_creates(self):
        body,p,p2,o,o2=self.batch_fixture()
        self.api(self.x,'partners','POST',body,404)
        self.api(self.b,'partners','POST',{**body,'targets':body['targets'][:1]},400)
        self.api(self.b,'partners','POST',{**body,'targets':body['targets']*6},400)
        self.api(self.b,'partners','POST',{**body,'targets':[body['targets'][0]]*2},400)
        raw=getrec('offer',o2['id']);raw['grade']='Другая';putrec('offer',o2['id'],raw,raw['userId'])
        self.api(self.b,'partners','POST',body,409)
        self.assertEqual(records('request',self.buyer['userId']),[]);self.assertEqual(records('request_batch'),[])

    def test_batch_rollback_and_stale_revision(self):
        body,p,p2,o,o2=self.batch_fixture()
        from .market import requests_api as original
        calls=[]
        def failing(req,d):
            calls.append(d)
            if len(calls)==2:raise RuntimeError('second draft unavailable')
            return original(req,d)
        with patch('marketplace.batch_requests.requests_api',side_effect=failing):self.api(self.b,'partners','POST',body,500)
        self.assertEqual(records('request',self.buyer['userId']),[]);self.assertEqual(records('request_batch'),[])
        self.api(self.b,'partners','POST',self.partner_update(p2,archived=True))
        self.api(self.b,'partners','POST',body,409)
        self.assertEqual(records('request',self.buyer['userId']),[])

    def test_batch_validation_and_supplier_change_before_send(self):
        body,p,p2,o,o2=self.batch_fixture()
        self.api(self.b,'partners','POST',{**body,'quantity':'0'},400)
        self.api(self.b,'partners','POST',{**body,'requestedDocuments':['SDS','SDS']},400)
        self.assertEqual(records('request',self.buyer['userId']),[])
        data=self.api(self.b,'partners','POST',body)
        raw=getrec('offer',o['id']);raw['userId']=self.outsider['userId'];putrec('offer',o['id'],raw,raw['userId'])
        self.api(self.b,'requests','PATCH',{'action':'send','id':data['requests'][0]['id']},409)

    def test_batch_tracking_progress_and_deleted_members(self):
        body,p,p2,o,o2=self.batch_fixture();created=self.api(self.b,'partners','POST',body);token=created['batchId']
        detail=self.api(self.b,'partners?batchId='+token)['batch']
        self.assertEqual(detail['counts'],{'draft':2,'sent':0,'quoted':0,'missing':0});self.assertFalse(detail['allAnswered'])
        q=created['requests'][0];self.api(self.b,'requests','PATCH',{'id':q['id'],'action':'send'})
        detail=self.api(self.b,'partners?batchId='+token)['batch'];self.assertEqual(detail['sentCount'],1);self.assertEqual(detail['counts']['sent'],1)
        q=getrec('request',q['id']);q.update(status='quoted',quotation=json.dumps({'validUntil':'2000-01-01'}),repliedAt=stamp());putrec('request',q['id'],q,q['userId'],q['recipientId'])
        self.api(self.b,'requests','DELETE',{'id':created['requests'][1]['id']})
        detail=self.api(self.b,'partners?batchId='+token)['batch'];self.assertEqual(detail['counts']['quoted'],1);self.assertEqual(detail['counts']['missing'],1)
        self.assertEqual(detail['quoteDates']['expired'],1);self.assertFalse(detail['allAnswered']);self.assertEqual(detail['total'],2)
        self.assertEqual(detail['members'][1]['companyName'],created['requests'][1]['batchSupplierName'])
        listed=self.api(self.b,'partners?batches=1')['batches'][0];self.assertNotIn('members',listed);self.assertNotIn('digest',listed)

    def test_batch_tracking_owner_and_corrupt_reference(self):
        body,*_=self.batch_fixture();created=self.api(self.b,'partners','POST',body);token=created['batchId']
        uid=self.administrator['userId'];putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        for c in [self.s,self.x,self.a]:
            self.api(c,'partners?batchId='+token,expected=404)
            self.assertEqual(self.api(c,'partners?batches=1')['batches'],[])
        self.api(self.guest,'partners?batches=1',expected=401)
        self.api(self.b,'partners?batchId=invalid',expected=400)
        q=created['requests'][0];q['userId']=self.outsider['userId'];q['message']='PRIVATE-OTHER';putrec('request',q['id'],q,q['userId'])
        detail=self.api(self.b,'partners?batchId='+token)['batch'];self.assertIsNone(detail['members'][0]['request']);self.assertNotIn('PRIVATE-OTHER',json.dumps(detail))

    def test_batch_tracking_legacy_after_deletion_and_new_snapshot(self):
        body,*_=self.batch_fixture();created=self.api(self.b,'partners','POST',body);token=created['batchId'];key=self.buyer['userId']+':'+token
        stored=getrec('request_batch',key);stored.pop('common');stored.pop('members');putrec('request_batch',key,stored,self.buyer['userId'])
        detail=self.api(self.b,'partners?batchId='+token)['batch'];self.assertEqual(detail['common']['quantity'],'500')
        for q in created['requests']:self.api(self.b,'requests','DELETE',{'id':q['id']})
        detail=self.api(self.b,'partners?batchId='+token)['batch'];self.assertIsNone(detail['common']);self.assertEqual(detail['counts']['missing'],2)
        body['clientId']=str(uuid.uuid4());new=self.api(self.b,'partners','POST',body)
        for q in new['requests']:self.api(self.b,'requests','DELETE',{'id':q['id']})
        detail=self.api(self.b,'partners?batchId='+new['batchId'])['batch'];self.assertEqual(detail['common']['quantity'],'500')
        self.assertEqual(len(self.api(self.b,'partners?batches=1')['batches']),2)

    def test_batch_tracking_complete_and_quote_dates(self):
        body,*_=self.batch_fixture();created=self.api(self.b,'partners','POST',body)
        for q,expiry in zip(created['requests'],['2099-12-31','bad-date']):
            q.update(status='quoted',quotation=json.dumps({'validUntil':expiry}),repliedAt=stamp());putrec('request',q['id'],q,q['userId'])
        detail=self.api(self.b,'partners?batchId='+created['batchId'])['batch']
        self.assertTrue(detail['allAnswered']);self.assertEqual(detail['sentCount'],2);self.assertEqual(detail['quoteDates'],{'dated':1,'expired':0,'unknown':1})

    def historical_quote(self,o,when,price='100',**changes):
        q=self.rfq(o);quote={'price':price,'currency':'RUB','unit':'кг','validUntil':'2099-12-31','paymentTerms':'Предоплата',**changes}
        q.update(status='quoted',repliedAt=when,quotation=json.dumps(quote));putrec('request',q['id'],q,q['userId'],q['recipientId']);return q

    def test_quote_history_prior_and_changed_conditions(self):
        o=self.offer();p=self.partner(o)
        first=self.historical_quote(o,'2026-10-01T10:00:00Z')
        second=self.historical_quote(o,'2026-10-02T10:00:00Z','120',paymentTerms='Отсрочка 30 дней')
        rows=self.api(self.b,'partners?quoteHistory=1')['entries']
        self.assertEqual([e['request']['id'] for e in rows],[second['id'],first['id']])
        self.assertEqual(rows[0]['previousId'],first['id']);self.assertEqual(rows[0]['changes'],['Цена','Оплата'])
        self.assertIsNone(rows[1]['previousId'])
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.assertTrue(self.api(self.b,'partners?quoteHistory=1')['entries'][0]['archived'])

    def test_quote_history_isolation_by_owner_supplier_and_identity(self):
        o=self.offer();self.partner(o);first=self.historical_quote(o,'2026-10-01T10:00:00Z')
        other=self.api(self.x,'offers','POST',OFFER)['offer'];self.partner(other);self.historical_quote(other,'2026-10-02T10:00:00Z')
        changed=self.api(self.s,'offers','POST',{**OFFER,'grade':'Другая'})['offer'];self.historical_quote(changed,'2026-10-03T10:00:00Z')
        rows=self.api(self.b,'partners?quoteHistory=1')['entries'];self.assertTrue(all(e['previousId'] is None for e in rows))
        for c in [self.s,self.x]:self.assertEqual(self.api(c,'partners?quoteHistory=1')['entries'],[])
        self.api(self.guest,'partners?quoteHistory=1',expected=401)
        uid=self.administrator['userId'];putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        self.assertEqual(self.api(self.a,'partners?quoteHistory=1')['entries'],[])

    def test_quote_history_unknown_identity_and_malformed_quote(self):
        o=self.offer();self.partner(o);first=self.historical_quote(o,'2026-10-01T10:00:00Z')
        second=self.historical_quote(o,'2026-10-02T10:00:00Z')
        second['quotation']='bad-json';putrec('request',second['id'],second,second['userId'],second['recipientId'])
        row=self.api(self.b,'partners?quoteHistory=1')['entries'][0];self.assertEqual(row['previousId'],first['id']);self.assertFalse(row['comparisonAvailable']);self.assertEqual(row['quoteState'],'unknown')
        second['chemexId']='';putrec('request',second['id'],second,second['userId'],second['recipientId'])
        self.assertIsNone(self.api(self.b,'partners?quoteHistory=1')['entries'][0]['previousId'])

    def test_quote_history_equal_timestamps_and_request_changes(self):
        o=self.offer();self.partner(o);first=self.historical_quote(o,'2026-10-01T10:00:00Z')
        second=self.historical_quote(o,'2026-10-01T10:00:00Z')
        self.assertTrue(all(e['previousId'] is None for e in self.api(self.b,'partners?quoteHistory=1')['entries']))
        third=self.historical_quote(o,'2026-10-02T10:00:00Z');third['destination']='Казань';putrec('request',third['id'],third,third['userId'],third['recipientId'])
        row=self.api(self.b,'partners?quoteHistory=1')['entries'][0];self.assertIn(row['previousId'],[first['id'],second['id']]);self.assertEqual(row['changes'],['Место поставки'])

    def delivery_body(self,p,o,**changes):
        return {'action':'create','clientId':str(uuid.uuid4()),'partnerId':p['id'],'source':{'kind':'offer','id':o['id']},
            'status':'planned','inspection':'unchecked','quantity':'500','unit':'кг','plannedDate':'2026-10-01','receivedDate':'','receivedQuantity':'',
            'reference':'Заказ 100','batchNumber':'','notes':'','reason':'Поставка согласована',**changes}

    def test_delivery_lifecycle_history_and_replay(self):
        o=self.offer();p=self.partner(o);body=self.delivery_body(p,o)
        v=self.api(self.b,'deliveries','POST',body)['delivery'];self.assertEqual(v['revision'],1);self.assertNotIn('creationDigest',v)
        self.assertTrue(self.api(self.b,'deliveries','POST',body)['replayed'])
        self.api(self.b,'deliveries','POST',{**body,'quantity':'600'},409)
        v=self.api(self.b,'deliveries','POST',{**v,'action':'update','status':'partial','receivedQuantity':'200','receivedDate':'2026-10-02','reason':'Пришла часть'})['delivery']
        self.assertEqual(v['quantityDifference'],'-300');self.assertEqual(v['delayDays'],1)
        stale={**v,'action':'update','status':'received','receivedQuantity':'490','receivedDate':'2026-10-03','inspection':'issues','notes':'Недопоставка 10 кг','reason':'Получение закрыто'}
        v=self.api(self.b,'deliveries','POST',stale)['delivery'];self.assertEqual(v['quantityDifference'],'-10');self.assertFalse(v['overdue'])
        self.api(self.b,'deliveries','POST',stale,409)
        h=self.api(self.b,'deliveries?id='+v['id']);self.assertEqual(len(h['events']),3);self.assertEqual(h['events'][-1]['snapshot']['status'],'planned')

    def test_delivery_privacy_archive_and_atomicity(self):
        o=self.offer();p=self.partner(o);body=self.delivery_body(p,o)
        with patch('marketplace.deliveries.putrec',side_effect=RuntimeError('history unavailable')):self.api(self.b,'deliveries','POST',body,500)
        self.assertEqual(records('partner_delivery'),[]);self.assertEqual(records('delivery_event'),[])
        v=self.api(self.b,'deliveries','POST',body)['delivery']
        uid=self.administrator['userId'];putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        for c in [self.s,self.x,self.a]:
            self.api(c,'deliveries?partnerId='+p['id'],expected=404);self.api(c,'deliveries?id='+v['id'],expected=404)
            self.api(c,'deliveries','POST',{**v,'action':'update','reason':'Изменение'},404)
        self.api(self.guest,'deliveries?id='+v['id'],expected=401)
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.api(self.b,'deliveries','POST',{**v,'action':'update','reason':'Изменение'},409)
        self.assertEqual(len(self.api(self.b,'deliveries?partnerId='+p['id'])['deliveries']),1)

    def test_delivery_validation_and_source_snapshots(self):
        o=self.offer();p=self.partner(o)
        for changes in [{'quantity':'0'},{'status':'partial'},{'status':'received','receivedQuantity':'100','receivedDate':'2099-01-01'},
                        {'status':'partial','receivedQuantity':'500','receivedDate':'2026-10-01'}, {'inspection':'accepted'},
                        {'status':'received','receivedQuantity':'500','receivedDate':'2026-10-01','inspection':'issues'}]:
            self.api(self.b,'deliveries','POST',self.delivery_body(p,o,**changes),400)
        q=self.historical_quote(o,'2026-10-01T10:00:00Z')
        v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o,source={'kind':'request','id':q['id']}))['delivery']
        raw=getrec('offer',o['id']);raw['grade']='Новая';putrec('offer',o['id'],raw,raw['userId'])
        self.assertEqual(self.api(self.b,'deliveries?id='+v['id'])['delivery']['product']['grade'],OFFER['grade'])
        self.api(self.b,'deliveries','POST',self.delivery_body(p,o),409)
        q['userId']=self.outsider['userId'];putrec('request',q['id'],q,q['userId'],q['recipientId'])
        self.api(self.b,'deliveries','POST',self.delivery_body(p,o,source={'kind':'request','id':q['id']}),404)

    def test_delivery_attention_boundaries_and_cancel(self):
        o=self.offer();p=self.partner(o)
        with patch('marketplace.deliveries.today',return_value='2026-10-01'),patch('marketplace.partner_workspace.today',return_value='2026-10-01'):
            v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o))['delivery'];self.assertFalse(v['overdue'])
            self.assertEqual(self.api(self.b,'partners?id='+p['id'])['partner']['attention'],[])
        with patch('marketplace.deliveries.today',return_value='2026-10-02'),patch('marketplace.partner_workspace.today',return_value='2026-10-02'):
            self.assertTrue(self.api(self.b,'deliveries?id='+v['id'])['delivery']['overdue'])
            self.assertEqual(self.api(self.b,'partners?id='+p['id'])['partner']['attention'][0]['kind'],'delivery_overdue')
            v=self.api(self.b,'deliveries','POST',{**v,'action':'update','status':'cancelled','reason':'Заказ отменён'})['delivery']
            self.assertEqual(self.api(self.b,'partners?id='+p['id'])['partner']['attention'],[])

    def test_delivery_history_pagination(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o))['delivery']
        for i in range(21):v=self.api(self.b,'deliveries','POST',{**v,'action':'update','reason':'Уточнение '+str(i)})['delivery']
        first=self.api(self.b,'deliveries?id='+v['id']);self.assertEqual(len(first['events']),20)
        last=self.api(self.b,'deliveries?id='+v['id']+'&before='+str(first['before']));self.assertEqual(len(last['events']),2);self.assertIsNone(last['before'])

    def issue_fixture(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o))['delivery']
        body={'action':'create','clientId':str(uuid.uuid4()),'partnerId':p['id'],'deliveryId':v['id'],'deliveryRevision':v['revision'],
              'title':'Не хватает документов','category':'documents','description':'Не получен COA партии','requestedResolution':'Получить COA','resolution':'',
              'status':'open','reviewDate':'2026-10-19','reason':'Зафиксирована проблема'}
        return p,v,body

    def test_issue_lifecycle_replay_resolution_reopen(self):
        p,v,body=self.issue_fixture();issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        self.assertEqual(issue['revision'],1);self.assertNotIn('creationDigest',issue)
        self.assertTrue(self.api(self.b,'delivery-issues','POST',body)['replayed'])
        self.api(self.b,'delivery-issues','POST',{**body,'title':'Другая проблема'},409)
        patch_body={**issue,'action':'update','status':'resolved','reviewDate':'','resolution':'COA получен','reason':'Документ проверен'}
        closed=self.api(self.b,'delivery-issues','POST',patch_body)['issue'];self.assertTrue(closed['closedAt']);self.assertFalse(closed['reviewDue'])
        self.api(self.b,'delivery-issues','POST',patch_body,409)
        reopened=self.api(self.b,'delivery-issues','POST',{**closed,'action':'update','status':'in_progress','reviewDate':'2026-10-20','reason':'Проверка версии документа'})['issue']
        self.assertIsNone(reopened['closedAt'])
        events=self.api(self.b,'delivery-issues?id='+issue['id'])['events'];self.assertEqual(len(events),3);self.assertEqual(events[1]['snapshot']['status'],'resolved')
        self.assertEqual(getrec('partner_delivery',v['id'])['revision'],1)

    def test_issue_validation_privacy_and_archive(self):
        p,v,body=self.issue_fixture()
        for changes in [{'status':'resolved','reviewDate':''},{'status':'cancelled','resolution':'Ошибка записи'},{'reviewDate':'2026-02-30'},{'deliveryRevision':0}]:
            self.api(self.b,'delivery-issues','POST',{**body,**changes},409 if 'deliveryRevision' in changes else 400)
        uid=self.administrator['userId'];putrec('profile',uid,{**PROFILE,'userId':uid},uid)
        issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        for c in [self.s,self.x,self.a]:
            self.api(c,'delivery-issues?id='+issue['id'],expected=404);self.api(c,'delivery-issues?partnerId='+p['id'],expected=404)
            self.api(c,'delivery-issues','POST',{**issue,'action':'update','reason':'Чужая запись'},404)
        self.api(self.guest,'delivery-issues?id='+issue['id'],expected=401)
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.api(self.b,'delivery-issues','POST',{**issue,'action':'update','reason':'Новая заметка'},409)
        self.assertEqual(len(self.api(self.b,'delivery-issues?partnerId='+p['id'])['issues']),1)

    def test_issue_snapshot_scope_and_atomicity(self):
        p,v,body=self.issue_fixture()
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        self.api(self.b,'delivery-issues','POST',{**body,'partnerId':p2['id']},404)
        with patch('marketplace.delivery_issues.putrec',side_effect=RuntimeError('history failure')):self.api(self.b,'delivery-issues','POST',body,500)
        self.assertEqual(records('delivery_issue'),[]);self.assertEqual(records('issue_event'),[])
        issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        self.api(self.b,'deliveries','POST',{**v,'action':'update','reference':'Исправленный заказ','reason':'Уточнили номер'})
        read=self.api(self.b,'delivery-issues?id='+issue['id'])['issue'];self.assertEqual(read['deliverySnapshot']['reference'],'Заказ 100')
        self.api(self.b,'delivery-issues','POST',{**body,'clientId':str(uuid.uuid4())},409)

    def test_issue_attention_dates_and_history_pagination(self):
        p,v,body=self.issue_fixture()
        with patch('marketplace.delivery_issues.today',return_value='2026-10-19'),patch('marketplace.partner_workspace.today',return_value='2026-10-19'):
            issue=self.api(self.b,'delivery-issues','POST',body)['issue'];self.assertTrue(issue['reviewDue'])
            self.assertIn('issue_review',[a['kind'] for a in self.api(self.b,'partners?id='+p['id'])['partner']['attention']])
            issue=self.api(self.b,'delivery-issues','POST',{**issue,'action':'update','status':'cancelled','resolution':'Дублирующее замечание','reviewDate':'','reason':'Отмена дубликата'})['issue']
            self.assertNotIn('issue_review',[a['kind'] for a in self.api(self.b,'partners?id='+p['id'])['partner']['attention']])
        for i in range(20):issue=self.api(self.b,'delivery-issues','POST',{**issue,'action':'update','reason':'Уточнение '+str(i)})['issue']
        first=self.api(self.b,'delivery-issues?id='+issue['id']);self.assertEqual(len(first['events']),20)
        last=self.api(self.b,'delivery-issues?id='+issue['id']+'&before='+str(first['before']));self.assertEqual(len(last['events']),2);self.assertIsNone(last['before'])

    def test_linked_task_issue_creation_and_no_automatic_completion(self):
        p,v,body=self.issue_fixture();issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        request={'action':'schedule_linked_task','id':p['id'],'revision':p['revision'],'nextAction':'Получить COA','nextDate':'2099-01-01','taskLink':{'kind':'issue','id':issue['id']}}
        p=self.api(self.b,'partners','POST',request)['partner'];self.assertEqual(p['taskLink']['id'],issue['id']);self.assertEqual(p['taskEvents'][0]['taskLink']['kind'],'issue')
        self.api(self.b,'partners','POST',request,409)
        self.api(self.b,'partners','POST',{**request,'revision':p['revision']},409)
        self.api(self.b,'delivery-issues','POST',{**issue,'action':'update','status':'resolved','resolution':'Документ получен','reviewDate':'','reason':'Проверено'})
        refreshed=self.api(self.b,'partners?id='+p['id'])['partner'];self.assertEqual(refreshed['nextAction'],'Получить COA')
        p=self.api(self.b,'partners','POST',{'action':'complete_task','id':p['id'],'revision':p['revision'],'note':'COA принят'})['partner']
        self.assertIsNone(p['taskLink']);self.assertEqual(p['taskEvents'][0]['taskLink']['id'],issue['id'])

    def test_linked_task_delivery_scope_and_archive(self):
        p,v,body=self.issue_fixture()
        request={'action':'schedule_linked_task','id':p['id'],'revision':p['revision'],'nextAction':'Проверить количество','nextDate':'2099-01-01','taskLink':{'kind':'delivery','id':v['id']}}
        self.api(self.x,'partners','POST',request,404)
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        self.api(self.b,'partners','POST',{**request,'id':p2['id'],'revision':p2['revision']},404)
        self.api(self.b,'partners','POST',{**request,'nextDate':'2000-01-01'},400)
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=True))['partner']
        self.api(self.b,'partners','POST',{**request,'revision':p['revision']},409)
        p=self.api(self.b,'partners','POST',self.partner_update(p,archived=False))['partner']
        p=self.api(self.b,'partners','POST',{**request,'revision':p['revision']})['partner']
        self.assertEqual(p['taskLink']['kind'],'delivery');self.assertEqual(p['linkDeliveries'][0]['id'],v['id'])
        self.assertEqual(self.api(self.b,'deliveries?id='+v['id'])['delivery']['status'],'planned')

    def test_linked_task_atomicity_and_existing_link_editor(self):
        p,v,body=self.issue_fixture();issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        request={'action':'schedule_linked_task','id':p['id'],'revision':p['revision'],'nextAction':'Проверка','nextDate':'2099-01-01','taskLink':{'kind':'delivery','id':v['id']}}
        with patch('marketplace.partners.task_event',side_effect=RuntimeError('audit unavailable')):self.api(self.b,'partners','POST',request,500)
        self.assertEqual(getrec('partner',p['id'])['nextDate'],'')
        p=self.api(self.b,'partners','POST',request)['partner']
        p=self.api(self.b,'partners','POST',{'action':'link_task','id':p['id'],'revision':p['revision'],'taskLink':{'kind':'issue','id':issue['id']}})['partner']
        self.assertEqual(p['taskLink']['id'],issue['id']);self.assertEqual(p['linkIssues'][0]['id'],issue['id'])

    def multi_task_body(self,p,**changes):
        return {'action':'create','clientId':str(uuid.uuid4()),'partnerId':p['id'],'title':'Запросить цену','dueDate':'2099-01-01','priority':'normal',
                'status':'open','notes':'Проверить условия','result':'','reason':'План закупки','taskLink':None,**changes}

    def test_multi_tasks_independent_versions_and_statuses(self):
        p=self.partner();body=self.multi_task_body(p)
        t=self.api(self.b,'supplier-tasks','POST',body)['task'];self.assertTrue(self.api(self.b,'supplier-tasks','POST',body)['replayed'])
        other=self.api(self.b,'supplier-tasks','POST',self.multi_task_body(p,priority='high'))['task']
        self.assertEqual(len(self.api(self.b,'supplier-tasks?partnerId='+p['id'])['tasks']),2)
        patch_body={**t,'action':'update','status':'done','result':'Цена получена','reason':'Ответ поставщика'}
        closed=self.api(self.b,'supplier-tasks','POST',patch_body)['task'];self.assertTrue(closed['closedAt'])
        self.api(self.b,'supplier-tasks','POST',patch_body,409)
        self.assertEqual(getrec('supplier_task',other['id'])['status'],'open')
        reopened=self.api(self.b,'supplier-tasks','POST',{**closed,'action':'update','status':'open','reason':'Нужна новая цена'})['task'];self.assertIsNone(reopened['closedAt'])
        self.assertEqual(len(self.api(self.b,'supplier-tasks?id='+t['id'])['events']),3)

    def test_multi_tasks_scope_links_and_archive(self):
        p,v,body=self.issue_fixture();issue=self.api(self.b,'delivery-issues','POST',body)['issue']
        t=self.api(self.b,'supplier-tasks','POST',self.multi_task_body(p,taskLink={'kind':'issue','id':issue['id']}))['task']
        for c in [self.s,self.x]:
            self.api(c,'supplier-tasks?id='+t['id'],expected=404);self.assertEqual(self.api(c,'supplier-tasks')['tasks'],[])
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        self.api(self.b,'supplier-tasks','POST',self.multi_task_body(p2,taskLink={'kind':'issue','id':issue['id']}),404)
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.api(self.b,'supplier-tasks','POST',{**t,'action':'update','reason':'Изменение'},409)
        self.assertTrue(self.api(self.b,'supplier-tasks?id='+t['id'])['task']['archived'])

    def test_multi_tasks_atomicity_attention_and_validation(self):
        p=self.partner();body=self.multi_task_body(p,dueDate='2026-10-20')
        with patch('marketplace.tasks.putrec',side_effect=RuntimeError('audit failure')):self.api(self.b,'supplier-tasks','POST',body,500)
        self.assertEqual(records('supplier_task'),[])
        self.api(self.b,'supplier-tasks','POST',{**body,'status':'done'},400)
        self.api(self.b,'supplier-tasks','POST',{**body,'dueDate':'2026-02-30'},400)
        with patch('marketplace.tasks.today',return_value='2026-10-20'),patch('marketplace.partner_workspace.today',return_value='2026-10-20'),patch('marketplace.partners.today',return_value='2026-10-20'):
            t=self.api(self.b,'supplier-tasks','POST',body)['task'];self.assertEqual(t['state'],'today')
            r=self.api(self.b,'partners?id='+p['id'])['partner'];self.assertEqual(r['openTaskCount'],1);self.assertEqual(r['dueTaskCount'],1);self.assertTrue(r['actionDue'])
            self.assertEqual(r['attention'][0]['kind'],'supplier_task')
        self.api(self.b,'supplier-tasks','POST',{**body,'title':'Другое'},409)

    def test_multi_tasks_migration_preserves_legacy_history(self):
        import importlib
        from django.apps import apps
        from django.db import connection
        from types import SimpleNamespace
        p=self.partner();p=self.api(self.b,'partners','POST',self.partner_update(p,nextAction='Старое действие',nextDate='2026-10-01'))['partner']
        old_count=len(records('partner_task_event',self.buyer['userId'],p['id']))
        migrate=importlib.import_module('marketplace.migrations.0003_supplier_tasks').migrate_tasks
        migrate(apps,SimpleNamespace(connection=connection));migrate(apps,SimpleNamespace(connection=connection))
        tasks=records('supplier_task',self.buyer['userId'],p['id']);self.assertEqual(len(tasks),1);self.assertEqual(tasks[0]['title'],'Старое действие')
        self.assertEqual(tasks[0]['dueDate'],'2026-10-01');self.assertTrue(tasks[0]['legacyImported'])
        self.assertEqual(getrec('partner',p['id'])['nextDate'],'');self.assertEqual(len(records('partner_task_event',self.buyer['userId'],p['id'])),old_count)
        self.assertEqual(len(records('supplier_task_event',self.buyer['userId'],tasks[0]['id'])),1)

    def test_multi_tasks_history_pagination(self):
        p=self.partner();t=self.api(self.b,'supplier-tasks','POST',self.multi_task_body(p))['task']
        for i in range(21):t=self.api(self.b,'supplier-tasks','POST',{**t,'action':'update','reason':'Перепроверка '+str(i)})['task']
        first=self.api(self.b,'supplier-tasks?id='+t['id']);self.assertEqual(len(first['events']),20)
        last=self.api(self.b,'supplier-tasks?id='+t['id']+'&before='+str(first['before']));self.assertEqual(len(last['events']),2);self.assertIsNone(last['before'])

    def test_delivery_document_coa_scope_and_snapshot(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o,batchNumber='LOT-7'))['delivery']
        d=self.upload_partner_document(p,kind='coa',deliveryId=v['id'],deliveryRevision=str(v['revision']),batchNumber='LOT-7')['document']
        self.assertEqual(d['deliverySnapshot']['batchNumber'],'LOT-7');self.assertEqual(d['kind'],'coa')
        rows=self.api(self.b,'partner-documents?partnerId='+p['id']+'&deliveryId='+v['id'])['documents'];self.assertEqual([x['id'] for x in rows],[d['id']])
        self.api(self.b,'deliveries','POST',{**v,'action':'update','reference':'Новый номер','batchNumber':'LOT-8','reason':'Исправление партии'})
        updated=self.api(self.b,'partner-documents','PATCH',{**d,'note':'Прежний COA','archived':False})['document']
        self.assertEqual(updated['deliverySnapshot']['batchNumber'],'LOT-7')
        self.assertEqual(updated['deliverySnapshot']['reference'],v['reference'])
        self.api(self.b,'partner-documents','PATCH',{**updated,'deliveryId':'','archived':False},409)

    def test_delivery_document_validation_and_foreign_source(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o,batchNumber='LOT-7'))['delivery']
        self.upload_partner_document(p,kind='coa',expected=400)
        self.upload_partner_document(p,kind='invoice',expected=400)
        self.upload_partner_document(p,kind='coa',deliveryId=v['id'],deliveryRevision='1',expected=400)
        self.upload_partner_document(p,kind='coa',deliveryId=v['id'],deliveryRevision='1',batchNumber='OTHER',expected=400)
        self.upload_partner_document(p,kind='coa',deliveryId=v['id'],deliveryRevision='0',batchNumber='LOT-7',expected=409)
        other=self.api(self.x,'offers','POST',OFFER)['offer'];p2=self.partner(other)
        self.upload_partner_document(p2,kind='invoice',deliveryId=v['id'],deliveryRevision='1',expected=404)
        self.api(self.b,'partner-documents?partnerId='+p2['id']+'&deliveryId='+v['id'],expected=404)
        self.assertEqual(records('partner_document'),[])
        self.assertEqual(list((settings.DOCUMENT_ROOT/'partner-private').glob('*.pdf')),[])

    def test_delivery_document_privacy_archive_and_legacy_binding(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o))['delivery']
        d=self.upload_partner_document(p)['document'];self.assertEqual(d['deliveryId'],'')
        d=self.api(self.b,'partner-documents','PATCH',{**d,'kind':'acceptance','deliveryId':v['id'],'deliveryRevision':v['revision'],'archived':False})['document']
        for c in [self.s,self.x]:
            self.api(c,'partner-documents?partnerId='+p['id']+'&deliveryId='+v['id'],expected=404)
            self.assertEqual(c.get(d['downloadUrl']).status_code,404)
        old=d;d=self.api(self.b,'partner-documents','PATCH',{**d,'archived':True})['document']
        self.api(self.b,'partner-documents','PATCH',{**old,'archived':False},409)
        self.assertEqual(d['expiryState'],'archived')
        response=self.b.get(d['downloadUrl']);self.assertEqual(response.status_code,200);response.close()
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.upload_partner_document(p,kind='invoice',deliveryId=v['id'],deliveryRevision='1',expected=409)

    def test_delivery_document_binding_atomic_rollback(self):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o))['delivery']
        with patch('marketplace.partner_documents.putrec',side_effect=RuntimeError('storage failed')):
            self.upload_partner_document(p,kind='invoice',deliveryId=v['id'],deliveryRevision='1',expected=500)
        self.assertEqual(records('partner_document'),[])
        self.assertEqual(list((settings.DOCUMENT_ROOT/'partner-private').glob('*.pdf')),[])
        d=self.upload_partner_document(p,kind='coa',deliveryId=v['id'],deliveryRevision='1',batchNumber='NEW-LOT')['document']
        self.assertEqual(d['batchNumber'],'NEW-LOT');self.assertEqual(getrec('partner_delivery',v['id'])['batchNumber'],'')

    def receipt_fixture(self,**changes):
        o=self.offer();p=self.partner(o);v=self.api(self.b,'deliveries','POST',self.delivery_body(p,o,**changes))['delivery']
        v=self.api(self.b,'delivery-receipts','POST',{'action':'enable','deliveryId':v['id'],'deliveryRevision':v['revision'],'reason':'Раздельный учёт'})['delivery']
        return p,v

    def receipt_body(self,v,**changes):
        return {'action':'add','clientId':str(uuid.uuid4()),'deliveryId':v['id'],'deliveryRevision':v['revision'],'quantity':'100','date':'2026-10-01','batchNumber':v['batchNumber'],'note':'','reason':'Приёмка партии',**changes}

    def test_receipt_opening_and_exact_totals(self):
        p,v=self.receipt_fixture(status='partial',receivedQuantity='100.1',receivedDate='2026-10-01',quantity='500')
        data=self.api(self.b,'delivery-receipts?deliveryId='+v['id']);self.assertEqual(len(data['receipts']),1);self.assertTrue(data['receipts'][0]['opening'])
        body=self.receipt_body(v,quantity='0.2',date='2026-10-02');response=self.api(self.b,'delivery-receipts','POST',body);v=response['delivery']
        self.assertEqual(v['receivedQuantity'],'100.3');self.assertEqual(v['receivedDate'],'2026-10-02')
        self.assertTrue(self.api(self.b,'delivery-receipts','POST',body)['replayed'])
        self.api(self.b,'delivery-receipts','POST',{**body,'quantity':'3'},409)
        self.assertEqual(self.api(self.b,'delivery-receipts?deliveryId='+v['id'])['remainingQuantity'],'399.7')
        v=self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,quantity='400'))['delivery'];self.assertEqual(v['status'],'received')
        self.assertEqual(self.api(self.b,'delivery-receipts?deliveryId='+v['id'])['excessQuantity'],'0.3')

    def test_receipt_void_recomputes_without_deleting_history(self):
        p,v=self.receipt_fixture()
        response=self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,quantity='500'));v=response['delivery'];row=response['receipt']
        body={'action':'void','deliveryId':v['id'],'deliveryRevision':v['revision'],'id':row['id'],'revision':row['revision'],'reason':'Дублирующая запись'}
        v=self.api(self.b,'delivery-receipts','POST',body)['delivery'];self.assertEqual(v['status'],'planned');self.assertEqual(v['receivedQuantity'],'');self.assertEqual(v['receivedDate'],'')
        self.api(self.b,'delivery-receipts','POST',{**body,'deliveryRevision':v['revision']},409)
        data=self.api(self.b,'delivery-receipts?deliveryId='+v['id']);self.assertTrue(data['receipts'][0]['voided']);self.assertEqual(data['remainingQuantity'],'500')
        self.assertEqual(len(self.api(self.b,'deliveries?id='+v['id'])['events']),4)

    def test_receipt_privacy_archive_and_locked_aggregates(self):
        p,v=self.receipt_fixture(batchNumber='LOT')
        self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,batchNumber='OTHER'),400)
        self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,date='2099-01-01'),400)
        self.api(self.b,'deliveries','POST',{**v,'action':'update','quantity':'999','reason':'Изменение плана'},409)
        self.api(self.b,'deliveries','POST',{**v,'action':'update','status':'received','receivedQuantity':'100','receivedDate':'2026-10-01','reason':'Обход журнала'},409)
        for c in [self.s,self.x]:
            self.api(c,'delivery-receipts?deliveryId='+v['id'],expected=404);self.api(c,'delivery-receipts','POST',self.receipt_body(v),404)
        self.api(self.b,'partners','POST',self.partner_update(p,archived=True))
        self.api(self.b,'delivery-receipts','POST',self.receipt_body(v),409)
        self.assertEqual(self.api(self.b,'delivery-receipts?deliveryId='+v['id'])['receipts'],[])

    def test_receipt_atomicity_stale_revision_and_cancelled(self):
        p,v=self.receipt_fixture()
        from .receipts import save_delivery
        with patch('marketplace.receipts.save_delivery',side_effect=RuntimeError('audit failed')):
            self.api(self.b,'delivery-receipts','POST',self.receipt_body(v),500)
        self.assertEqual(records('delivery_receipt'),[]);self.assertEqual(getrec('partner_delivery',v['id'])['receivedQuantity'],'')
        self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,deliveryRevision=0),409)
        v=self.api(self.b,'deliveries','POST',{**v,'action':'update','status':'cancelled','reason':'Отмена заказа'})['delivery']
        self.api(self.b,'delivery-receipts','POST',self.receipt_body(v),409)
        self.assertEqual(records('delivery_receipt'),[])


    def receipt_document_fixture(self):
        p,v=self.receipt_fixture()
        result=self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,batchNumber='LOT-A'))
        return p,result['delivery'],result['receipt']

    def receipt_document_fields(self,v,r,**changes):
        return dict(kind='coa',deliveryId=v['id'],deliveryRevision=str(v['revision']),receiptId=r['id'],receiptRevision=str(r['revision']),batchNumber=r['batchNumber'],**changes)

    def test_receipt_document_snapshot_filter_and_multiple_batches(self):
        p,v,r=self.receipt_document_fixture()
        first=self.upload_partner_document(p,**self.receipt_document_fields(v,r))['document']
        result=self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,batchNumber='LOT-B'))
        second=self.upload_partner_document(p,**self.receipt_document_fields(result['delivery'],result['receipt']))['document']
        self.assertEqual(first['receiptSnapshot']['quantity'],'100')
        self.assertEqual(first['receiptSnapshot']['batchNumber'],'LOT-A')
        self.assertEqual(second['receiptSnapshot']['batchNumber'],'LOT-B')
        data=self.api(self.b,'partner-documents?partnerId='+p['id']+'&receiptId='+r['id'])
        self.assertEqual([d['id'] for d in data['documents']],[first['id']])
        self.assertEqual(len(data['receipts']),2)
        self.assertEqual(first['receiptState'],'active')

    def test_receipt_document_validation_and_privacy(self):
        p,v,r=self.receipt_document_fixture();fields=self.receipt_document_fields(v,r)
        self.upload_partner_document(p,**{**fields,'batchNumber':'WRONG'},expected=400)
        self.upload_partner_document(p,**{**fields,'receiptRevision':'0'},expected=409)
        self.upload_partner_document(p,**{**fields,'receiptId':str(uuid.uuid4())},expected=404)
        other=self.api(self.b,'deliveries','POST',self.delivery_body(p,{'id':v['source']['id']}))['delivery']
        self.upload_partner_document(p,**{**fields,'deliveryId':other['id'],'deliveryRevision':str(other['revision'])},expected=404)
        self.assertEqual(records('partner_document'),[])
        self.assertEqual(list((settings.DOCUMENT_ROOT/'partner-private').glob('*.pdf')),[])
        d=self.upload_partner_document(p,**fields)['document']
        for c in [self.s,self.x]:
            self.api(c,'partner-documents?partnerId='+p['id']+'&receiptId='+r['id'],expected=404)
            self.assertEqual(c.get(d['downloadUrl']).status_code,404)

    def test_receipt_document_void_preserves_pdf_and_binding(self):
        p,v,r=self.receipt_document_fixture();d=self.upload_partner_document(p,**self.receipt_document_fields(v,r))['document']
        result=self.api(self.b,'delivery-receipts','POST',{'action':'void','deliveryId':v['id'],'deliveryRevision':v['revision'],'id':r['id'],'revision':r['revision'],'reason':'Ошибочное поступление'})
        self.upload_partner_document(p,**self.receipt_document_fields(result['delivery'],result['receipt']),expected=409)
        updated=self.api(self.b,'partner-documents','PATCH',{**d,'archived':True,'note':'Исторический документ'})['document']
        self.assertEqual(updated['receiptState'],'voided');self.assertEqual(updated['receiptSnapshot'],d['receiptSnapshot'])
        self.api(self.b,'partner-documents','PATCH',{**updated,'receiptId':''},409)
        self.api(self.b,'partner-documents','PATCH',{**updated,'receiptId':str(uuid.uuid4())},409)
        response=self.b.get(d['downloadUrl']);self.assertEqual(response.status_code,200);response.close()

    def test_receipt_document_opening_rejected_and_legacy_binding(self):
        p,v=self.receipt_fixture(status='partial',receivedQuantity='100',receivedDate='2026-10-01')
        r=self.api(self.b,'delivery-receipts?deliveryId='+v['id'])['receipts'][0]
        self.upload_partner_document(p,**{**self.receipt_document_fields(v,r),'kind':'acceptance'},expected=400)
        result=self.api(self.b,'delivery-receipts','POST',self.receipt_body(v,batchNumber='LOT-A'));v=result['delivery'];r=result['receipt']
        d=self.upload_partner_document(p)['document']
        d=self.api(self.b,'partner-documents','PATCH',{**d,**self.receipt_document_fields(v,r),'archived':False})['document']
        self.assertEqual(d['receiptId'],r['id'])
        with patch('marketplace.partner_documents.putrec',side_effect=RuntimeError('storage failed')):
            self.upload_partner_document(p,**self.receipt_document_fields(v,r),expected=500)
        self.assertEqual(len(records('partner_document')),1)
        self.assertEqual(len(list((settings.DOCUMENT_ROOT/'partner-private').glob('*.pdf'))),1)
