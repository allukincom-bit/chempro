import logging
import mimetypes
import os
import secrets
import time
from functools import wraps
from html import escape
from pathlib import Path
from urllib.parse import parse_qs
import bcrypt
from django.conf import settings
from django.core.exceptions import RequestDataTooBig
from django.contrib.auth.hashers import make_password, check_password
from django.db import connection
from django.http import JsonResponse, HttpResponse, FileResponse, HttpResponseRedirect
from django.middleware.csrf import get_token, rotate_token
from .core import *
from .models import AuthLimit
from .market import profile_api, offers_api, favorites_api, requests_api, messages_api
from .administration import reference_api, verification_api, admin_api
from .laboratories import laboratories_api
from .partners import partners_api
from .partner_documents import partner_documents_api
from .deliveries import deliveries_api
from .delivery_issues import issues_api
from .tasks import tasks_api
from .receipts import receipts_api

logger=logging.getLogger(__name__)

def boundary(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        try: return fn(*args,**kwargs)
        except APIError as e: return JsonResponse({'error':e.message},status=e.status)
        except RequestDataTooBig: return JsonResponse({'error':'Запрос слишком большой.'},status=413)
        except Exception:
            logger.exception('ChemEx request failed')
            return JsonResponse({'error':'Сервис временно недоступен. Обратитесь к администратору.'},status=500)
    return wrapped

class ResponseHeaders:
    def __init__(self,get_response): self.get_response=get_response
    def __call__(self,request):
        request.get_host()  # Enforce ALLOWED_HOSTS on every request, including assets.
        response=self.get_response(request)
        response['Cache-Control']='private, no-store'
        return response

def csrf_failure(request,reason=''):
    return JsonResponse({'error':'Сессия устарела или источник запроса недопустим. Обновите страницу.'},status=403)

@boundary
def index(request):
    if request.method not in ['GET','HEAD']: fail(405,'Метод не поддерживается.')
    html=(settings.BASE_DIR/'frontend/index.html').read_text()
    bootstrap='<meta name="csrf-token" content="'+get_token(request)+'"><script src="/hosting.js"></script>'
    return HttpResponse(html.replace('</head>',bootstrap+'</head>').replace('</body>','<script src="/hosting-diagnostics.js"></script></body>'))

@boundary
def asset(request,filename):
    if request.method not in ['GET','HEAD']: fail(405,'Метод не поддерживается.')
    path=settings.BASE_DIR/'frontend'/filename
    if not path.is_file(): fail(404,'Файл не найден.')
    return FileResponse(path.open('rb'),content_type=mimetypes.guess_type(filename)[0] or 'application/octet-stream')

ROUTES={'profile':profile_api,'offers':offers_api,'favorites':favorites_api,'requests':requests_api,
    'messages':messages_api,'reference':reference_api,'verification':verification_api,'admin':admin_api,'laboratories':laboratories_api,'partners':partners_api,'deliveries':deliveries_api,'delivery-issues':issues_api,'supplier-tasks':tasks_api,'delivery-receipts':receipts_api}

def mutation_origin(req):
    if req.headers.get('Origin')!=settings.BASE_URL: fail(403,'Недопустимый источник запроса.')

@boundary
def api(request,name):
    if request.method not in ['GET','POST','PUT','PATCH','DELETE']: fail(405,'Метод не поддерживается.')
    if name=='health':
        if request.method!='GET': fail(405,'Метод не поддерживается.')
        with connection.cursor() as cursor: cursor.execute('SELECT 1'); cursor.fetchone()
        return JsonResponse({'ok':True,'runtime':'python-django','database':connection.vendor})
    if name=='diagnostics':
        admin(request)
        if request.method!='GET': fail(405,'Метод не поддерживается.')
        with connection.cursor() as cursor: cursor.execute('SELECT 1'); cursor.fetchone()
        checks=[{'id':'database','status':'pass' if connection.vendor=='postgresql' else 'warn','message':'База данных: '+connection.vendor},
            {'id':'documents','status':'pass' if os.access(settings.DOCUMENT_ROOT,os.W_OK) else 'fail','message':'Каталог PDF доступен для записи' if os.access(settings.DOCUMENT_ROOT,os.W_OK) else 'Каталог PDF недоступен для записи'},
            {'id':'https','status':'pass' if request.is_secure() else 'warn','message':'HTTPS включён' if request.is_secure() else 'Соединение без HTTPS: допустимо только локально'},
            {'id':'write_lock','status':'pass' if Counter.objects.filter(name='write_lock').exists() else 'fail','message':'Служебная блокировка записи'}]
        failures=sum(c['status']=='fail' for c in checks); warnings=sum(c['status']=='warn' for c in checks)
        return JsonResponse({'ok':failures==0,'runtime':'python-django','checks':checks,'failures':failures,'warnings':warnings,'generatedAt':stamp(),
            'notice':'Диагностика Python-версии. Отдельно проверяйте резервные копии и восстановление на тестовом сервере.'})
    if name=='document-files':
        if request.method!='GET': mutation_origin(request)
        return files_api(request)
    if name=='partner-documents':
        if request.method!='GET': mutation_origin(request)
        return partner_documents_api(request)
    fn=ROUTES.get(name)
    if not fn: fail(404,'Метод API не найден.')
    if request.method=='GET': return JsonResponse(fn(request,{}))
    mutation_origin(request)
    if request.content_type!='application/json': fail(415,'Ожидается JSON.')
    if len(request.body)>16000: fail(413,'Запрос слишком большой.')
    try: data=obj(json.loads(request.body,parse_constant=lambda _:fail(400,'Некорректный JSON.')))
    except (ValueError,UnicodeError,RecursionError): fail(400,'Некорректный JSON.')
    with write_transaction(): result=fn(request,data)
    return JsonResponse(result)

def files_api(req):
    if req.method=='POST':
        uid=user(req)['userId']; raw=req.POST.get('offerId','')
        if not re.fullmatch('[0-9]+',raw): fail(400,'Некорректное предложение.')
        i=positive(int(raw)); f=req.FILES.get('file')
        if not f or not 5<=f.size<=8*1024*1024 or f.read(5)!=b'%PDF-': fail(400,'Выберите PDF не более 8 МБ.')
        f.seek(0); file_id=str(uuid.uuid4()); destination=settings.DOCUMENT_ROOT/(file_id+'.pdf')
        try:
            with write_transaction():
                o=getrec('offer',i)
                if not o or o['userId']!=uid: fail(404,'Предложение не найдено.')
                if len(records('file',related=i))>=12: fail(409,'Лимит — 12 PDF на предложение.')
                settings.DOCUMENT_ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
                with destination.open('xb') as output:
                    os.chmod(destination,0o600)
                    for chunk in f.chunks(): output.write(chunk)
                filename=Path(f.name).name[:200]
                putrec('file',file_id,{'id':file_id,'offerId':i,'ownerId':uid,'filename':filename,'size':f.size,'createdAt':stamp()},uid,str(i))
        except Exception:
            destination.unlink(missing_ok=True); raise
        return JsonResponse({'url':settings.BASE_URL+'/api/document-files?id='+file_id},status=201)
    if req.method!='GET': fail(405,'Метод не поддерживается.')
    i=uuidfield(req.GET.dict(),'id'); f=getrec('file',i)
    if not f: fail(404,'Документ не найден.')
    o=getrec('offer',f['offerId']); u=user(req,False) or {}; attached=False
    for d in (o or {}).get('documents',[]):
        p=urlsplit(d['url'])
        if p.scheme+'://'+p.netloc==settings.BASE_URL and p.path=='/api/document-files' and parse_qs(p.query).get('id')==[i]: attached=True
    if not o or not (u.get('userId')==f['ownerId'] or u.get('admin') or attached and visible(o)): fail(404,'Документ не найден.')
    path=settings.DOCUMENT_ROOT/(i+'.pdf')
    if not path.is_file(): fail(404,'Файл недоступен.')
    response=FileResponse(path.open('rb'),as_attachment=True,filename=f['filename'],content_type='application/pdf')
    response['Content-Security-Policy']="sandbox; default-src 'none'"
    return response

def validate_password(value):
    if not isinstance(value,str) or len(value)<12 or len(value.encode())>72: fail(400,'Пароль: минимум 12 символов, максимум 72 байта.')
    return value

def verify_password(password,hashed):
    if hashed.startswith(('$2y$','$2b$','$2a$')):
        try: return bcrypt.checkpw(password.encode(),hashed.encode())
        except ValueError: return False
    return check_password(password,hashed)

def throttle(req,action,email):
    now=int(time.time()); ip=req.META.get('REMOTE_ADDR','')
    if getattr(settings,'SECURE_PROXY_SSL_HEADER',None): ip=req.META.get('HTTP_X_CHEMEX_CLIENT_IP',ip)
    with write_transaction():
        buckets=[hashlib.sha256((action+':'+x).encode()).hexdigest() for x in ['ip:'+ip,'email:'+email.lower()]]
        rows=[AuthLimit.objects.filter(bucket=b).first() for b in buckets]
        if any(r and r.expires>now and r.attempts>=(10 if action=='register' else 20) for r in rows): fail(429,'Слишком много попыток. Повторите через 15 минут.')
        for b,r in zip(buckets,rows):
            AuthLimit.objects.update_or_create(bucket=b,defaults={'attempts':r.attempts+1 if r and r.expires>now else 1,'expires':r.expires if r and r.expires>now else now+900})
        AuthLimit.objects.filter(expires__lt=now-86400).delete()

@boundary
def auth_page(req,mode):
    if req.method not in ['GET','POST']: fail(405,'Метод не поддерживается.')
    error=''; status=200
    if req.method=='POST':
        try:
            mutation_origin(req)
            if mode=='logout': req.session.flush(); rotate_token(req); return HttpResponseRedirect('/')
            d=req.POST.dict(); email=emailfield(d,'email').lower(); password=d.get('password','')
            if len(password.encode())>72: fail(400,'Пароль должен занимать не более 72 байт.')
            throttle(req,mode,email)
            if mode=='register':
                if not settings.REGISTRATION_ENABLED: fail(403,'Регистрация временно закрыта.')
                validate_password(password); name=textfield(d,'displayName',2,120)
                with write_transaction():
                    if Account.objects.filter(email=email).exists(): fail(409,'Адрес уже зарегистрирован. Попробуйте войти.')
                    Account.objects.create(email=email,display_name=name,password_hash=make_password(password),created_at=stamp())
            u=Account.objects.filter(email=email).first()
            hashed=u.password_hash if u else '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi'
            valid=verify_password(password,hashed)
            if not valid or not u: fail(401,'Неверный email или пароль.')
            # Atomic recheck prevents a concurrent password reset from being overwritten.
            with write_transaction():
                current=Account.objects.get(id=u.id)
                if current.password_hash!=hashed or current.session_version!=u.session_version: fail(409,'Аккаунт изменился. Повторите вход.')
                if hashed.startswith('$2'):
                    current.password_hash=make_password(password); current.save(update_fields=['password_hash'])
            req.session.flush(); req.session['uid']=str(u.id); req.session['version']=u.session_version; rotate_token(req)
            return HttpResponseRedirect('/')
        except APIError as e: error=e.message; status=e.status
    title={'login':'Вход в ChemEx.One','register':'Регистрация','logout':'Выход из аккаунта'}[mode]
    html='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><link rel="stylesheet" href="/styles.css"><body style="background:#eef3f7"><main style="max-width:480px;margin:8vh auto;padding:28px;background:white;border-radius:20px"><a href="/">← ChemEx.One</a><h1>'+title+'</h1><p role="alert" style="color:#b42318">'+escape(error)+'</p><form method="post"><input type="hidden" name="csrfmiddlewaretoken" value="'+get_token(req)+'">'
    if mode=='register': html+='<label class="profile-label">Ваше имя<input name="displayName" required minlength="2" maxlength="120" autocomplete="name"></label>'
    if mode!='logout': html+='<label class="profile-label">Email<input name="email" type="email" required maxlength="254" autocomplete="username"></label><label class="profile-label">Пароль<input name="password" type="password" required autocomplete="'+('new-password' if mode=='register' else 'current-password')+'"></label>'
    html+='<button class="primary" type="submit">'+('Создать аккаунт' if mode=='register' else 'Выйти' if mode=='logout' else 'Войти')+'</button></form>'
    if mode=='login': html+='<p><a href="/register">Создать аккаунт</a></p><p>Для восстановления доступа обратитесь к владельцу площадки. Автоматическая рассылка писем пока не подключена.</p>'
    if mode=='register': html+='<p>Пароль: минимум 12 символов, максимум 72 байта. Подтверждение email пока не подключено; регистрация не подтверждает компанию.</p><a href="/login">Уже зарегистрированы? Войти</a>'
    return HttpResponse(html+'</main></body></html>',status=status)
