#!/bin/sh
# Run from project root. Briefly stops application writes for a consistent DB+PDF backup.
set -eu
umask 077
backup_path="backups/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p backups
mkdir "$backup_path"
restart_web() { docker compose start web >/dev/null; }
trap restart_web EXIT HUP INT TERM
docker compose stop web
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$backup_path/database.dump"
docker compose run --rm --no-deps -T --user root web tar -C /data -czf - documents > "$backup_path/documents.tar.gz"
cp .env "$backup_path/config.env"
printf '%s\n' "Backup: $backup_path"
