#!/usr/bin/env python3
"""Create a private production .env without printing secrets. Never overwrites it."""
import argparse
import os
import re
import secrets
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('domain',help='DNS name only, e.g. chemex.example.com')
a=p.parse_args()
domain=a.domain.encode('idna').decode().lower()
if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}',domain):
    p.error('Specify a domain without scheme, port, or path.')
target=Path(__file__).resolve().parents[1]/'.env'
fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:
    f.write(f'DOMAIN={domain}\nSECRET_KEY={secrets.token_urlsafe(64)}\nPOSTGRES_DB=chemex\nPOSTGRES_USER=chemex\nPOSTGRES_PASSWORD={secrets.token_urlsafe(48)}\nREGISTRATION_ENABLED=1\n')
print('Создан .env с правами 0600. Секреты не выводятся в терминал.')
