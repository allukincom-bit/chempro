<?php
// Run only via CLI on the OLD server; stdout contains a confidential JSON export.
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$root = realpath($argv[1] ?? '');
if (!$root || !is_file($root.'/config.php')) { fwrite(STDERR,"Usage: php export_php.php /absolute/path/private > export.json\n"); exit(1); }
define('PRIVATE_ROOT',$root);
$GLOBALS['chemex_config'] = require $root.'/config.php';
require $root.'/src/core.php';
try {
 $result = transaction(function() use ($root) {
  $users=sql('SELECT id,email,display_name,password_hash,is_admin,session_version,created_at FROM users')->fetchAll();
  $rows=sql('SELECT kind,id,owner,related,status,payload FROM records')->fetchAll();
  $files=[];
  foreach($rows as &$r) {
   $r['payload']=json_decode($r['payload'],true,512,JSON_THROW_ON_ERROR);
   if($r['kind']==='file') {
    $id=$r['id']; if(!preg_match('/^[a-f0-9-]{36}$/D',$id))throw new RuntimeException('Invalid file ID');
    $path=$root.'/storage/documents/'.$id.'.pdf';
    if(!is_file($path))throw new RuntimeException('Missing document '.$id);
    $files[$id]=['sha256'=>hash_file('sha256',$path),'size'=>filesize($path)];
   }
  }
  unset($r);
  return ['format'=>'chemex-php-export-v1','exportedAt'=>stamp(),'baseUrl'=>cfg()['base_url'],
    'users'=>$users,'records'=>$rows,'counters'=>sql('SELECT name,value FROM counters')->fetchAll(),'files'=>(object)$files];
 });
 echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR|JSON_PRETTY_PRINT);
} catch(Throwable $e) { fwrite(STDERR,$e->getMessage()."\n"); exit(1); }
